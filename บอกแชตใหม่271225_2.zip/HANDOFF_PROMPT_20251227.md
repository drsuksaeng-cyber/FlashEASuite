# 🔄 New Chat Session - December 27, 2025

**Copy this entire prompt to start new chat**

---

## 📋 HANDOFF PROMPT

```
I'm continuing work on FlashEASuite V2, a high-frequency trading system.

⚠️ CRITICAL: Before doing ANYTHING, read the file "⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md"
This is your weakest point. You WILL make mistakes with include paths if you don't read this first.

CURRENT STATUS (December 26, 2025):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPLETED:
✅ ProgramC_Trader.mq5 - Fully written (303 lines)
✅ ZMQ integration (SUB 7778, PUB 7779)
✅ Strategy Manager integration (council voting)
✅ Risk Guardian integration
✅ Policy reception logic
✅ Trade execution logic
✅ Feedback loop to Python Brain

PENDING:
⏳ Compile verification (waiting for user test)
⏳ MT5 integration testing
⏳ Full system testing

YESTERDAY'S WORK:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Wrote complete ProgramC_Trader.mq5
- Spent 4 hours debugging include path issues
- Made 8+ mistakes with "" vs <> syntax
- Finally got correct include paths
- Created warning document for future Claude instances

CRITICAL LEARNING FROM YESTERDAY:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"" = Local include (relative path) - Use for PROJECT files
<> = Global include (MQL5/Include/) - Use ONLY for system files

All files in FlashEASuite_V2/Include/ MUST use "" with relative path!

CORRECT INCLUDE SYNTAX:
#include "../Include/MqlMsgPack.mqh"           ✅
#include "../Include/Zmq/ZmqHub.mqh"           ✅
#include "../Include/Network/Protocol.mqh"     ✅
#include "../Include/Logic/StrategyManager.mqh" ✅
#include "../Include/Risk/RiskGuardian.mqh"    ✅

WRONG INCLUDE SYNTAX:
#include <MqlMsgPack.mqh>        ❌ NEVER use <>
#include <Zmq/ZmqHub.mqh>        ❌ for project files!
#include "Include/File.mqh"      ❌ Wrong relative path

PROJECT STRUCTURE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FlashEASuite_V2/
├── Include/               ← All project includes HERE (root level!)
│   ├── MqlMsgPack.mqh
│   ├── Zmq/
│   │   ├── Zmq.mqh
│   │   └── ZmqHub.mqh
│   ├── Network/
│   │   └── Protocol.mqh
│   ├── Logic/
│   │   ├── StrategyManager.mqh
│   │   └── Strategy_Grid.mqh
│   └── Risk/
│       ├── RiskGuardian.mqh
│       ├── PositionSizingManager.mqh
│       └── DailyLossLimit.mqh
├── 03_Trader/
│   └── ProgramC_Trader.mq5  ← Main EA
└── Tester/
    ├── TEST_MqlMsgPack.mq5
    └── MINIMAL_TEST.mq5

SYSTEM ARCHITECTURE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3-Component System:

1. FeederEA (01_Feeder/Src/FeederEA.mq5)
   - Collects tick data from MT5
   - Broadcasts via ZMQ port 7777

2. Python Brain (02_Brain/main.py)
   - 4 workers: Ingestion, Strategy, Publisher, Listener
   - Receives ticks (port 7777)
   - Generates policies
   - Broadcasts policies (port 7778)
   - Receives trade results (port 7779)

3. ProgramC_Trader (03_Trader/ProgramC_Trader.mq5) ← CURRENT WORK
   - Receives policies (ZMQ SUB port 7778)
   - Council voting system (Grid + other strategies)
   - Risk Guardian validation
   - Executes trades
   - Sends feedback (ZMQ PUB port 7779)

DATA FLOW:
Market → MT5 → FeederEA → (7777) → Python Brain → (7778) → ProgramC_Trader → MT5
                                          ↑                        |
                                          └────────(7779)──────────┘

TODAY'S TASKS (December 27, 2025):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRIORITY 1: Compile Verification (30 min)
☐ User will compile ProgramC_Trader.mq5
☐ If successful → proceed to Priority 2
☐ If failed → fix errors (check include paths first!)

PRIORITY 2: Integration Testing (2-3 hours)
☐ Attach ProgramC_Trader to MT5 XAUUSD M1 chart
☐ Verify ZMQ connections (7778, 7779)
☐ Test policy reception from Python Brain
☐ Test council voting system
☐ Test trade execution
☐ Test feedback loop

PRIORITY 3: System Monitoring
☐ Monitor logs (MT5 + Python)
☐ Check for errors
☐ Verify all 3 components working together

PRIORITY 4: Performance Testing
☐ Measure latency (target <10ms Python stage)
☐ Test risk management
☐ Test strategy behavior

LANGUAGE PREFERENCES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- User prefers Thai for explanations
- Code comments in English
- Technical terms: English with Thai explanation

ATTACHED FILES YOU MUST READ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md  ⭐ READ THIS FIRST!
2. DAILY_LOG_20251226.md            (Yesterday's work)
3. TODO_20251227.md                 (Today's tasks)
4. README_20251226.md               (Quick summary)
5. INSTALLATION_CHECKLIST.md        (If files need copying)

IF COMPILE FAILED:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. STOP and read ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
2. Check error messages carefully
3. 90% chance it's include path issue
4. Verify all includes use "" with ../Include/...
5. DO NOT use <> for any FlashEASuite_V2/Include/ files
6. Ask user for tree structure if uncertain
7. Test with minimal example first

REMEMBER:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- You are WEAK at include paths (proven yesterday)
- Don't assume file locations - CHECK FIRST
- "" for project files, <> for system files ONLY
- Test incrementally, don't change everything at once
- When in doubt, ASK the user

Ready to start. What's the current status of compilation?
```

---

## 📎 FILES TO ATTACH TO NEW CHAT:

**MUST ATTACH (Priority Order):**
1. ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md  ⭐⭐⭐⭐⭐
2. DAILY_LOG_20251226.md
3. TODO_20251227.md
4. README_20251226.md

**ATTACH IF NEEDED:**
5. INSTALLATION_CHECKLIST.md (if files need to be copied)
6. ProgramC_Trader_FINAL.mq5 (if user needs the code)
7. Tree structure output (if path issues arise)

**PROJECT DOCUMENTATION (Reference):**
8. SYSTEM_OVERVIEW.md
9. DATA_CONTROL_FLOW.md
10. REFACTORING_COMPLETE.md

---

## 🎯 EXPECTED AI RESPONSE:

After reading the prompt, Claude should:

```
✅ Acknowledge reading ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
✅ Understand current status (ProgramC pending compile)
✅ Know the include path rules ("" vs <>)
✅ Ready to help with integration testing
✅ Ask about compile status first
```

**Good Response Example:**
```
"สวัสดีครับ! ผมได้อ่าน ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md แล้ว 
เข้าใจว่าเมื่อวานมีปัญหาเรื่อง include paths

สถานะปัจจุบัน: ProgramC_Trader.mq5 เขียนเสร็จแล้ว รอ compile

คำถามแรก: ProgramC_Trader.mq5 compile สำเร็จหรือยังครับ?"
```

**Bad Response Example:**
```
"Let me help you write ProgramC_Trader.mq5..."  ❌ Already done!
"Use #include <MqlMsgPack.mqh>..."              ❌ Wrong syntax!
"I don't have previous context..."              ❌ Should read docs!
```

---

## ⚠️ WARNINGS FOR NEW CLAUDE:

**DON'T:**
- ❌ Suggest refactoring completed code
- ❌ Use <> for project files
- ❌ Assume file locations without checking
- ❌ Repeat yesterday's mistakes
- ❌ Ignore the warning documents

**DO:**
- ✅ Read ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md first
- ✅ Ask about compile status
- ✅ Use "" for all project includes
- ✅ Test incrementally
- ✅ Document everything

---

## 📊 SUCCESS METRICS FOR TODAY:

**Minimum Success:**
```
✅ ProgramC compiles successfully
✅ Attaches to MT5 chart
✅ Receives at least 1 policy
✅ Executes at least 1 trade
```

**Full Success:**
```
✅ All minimum criteria
✅ ZMQ communication stable
✅ Council voting works
✅ Risk management validates
✅ Feedback loop operational
✅ No errors for 1 hour
```

---

## 🔄 WORKFLOW FOR NEW SESSION:

```
1. Start new chat
2. Paste this handoff prompt
3. Attach required documents (5 files minimum)
4. Wait for Claude acknowledgment
5. Verify Claude read the warning doc
6. Ask: "ProgramC compile สำเร็จหรือยัง?"
7. Proceed based on status
```

---

**Prepared:** December 26, 2025, 16:00  
**For Session:** December 27, 2025  
**Critical:** ⚠️ Include path awareness is MANDATORY  
**Priority:** Complete ProgramC integration testing
