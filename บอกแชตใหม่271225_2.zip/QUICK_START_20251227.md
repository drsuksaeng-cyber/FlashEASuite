# 🎯 QUICK START GUIDE - December 27, 2025

**Use this to start new chat session quickly**

---

## ⚡ SUPER QUICK VERSION (30 seconds)

**Copy to new chat:**
```
Continuing FlashEASuite V2. Status: ProgramC_Trader.mq5 written, pending compile test.

⚠️ CRITICAL: Read "⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md" FIRST!
Yesterday spent 4 hours on include path mistakes.

Include rules:
"" = project files (use "../Include/...")
<> = system files only (MQL5/Include/)

Today: Test compile, integrate with Python Brain, verify ZMQ communication.

Question: ProgramC compile สำเร็จหรือยัง?
```

---

## 📋 MEDIUM VERSION (2 minutes)

**Yesterday (Dec 26):**
- ✅ Wrote ProgramC_Trader.mq5 (303 lines)
- ❌ Spent 4h debugging include paths
- ❌ Made 8+ mistakes with "" vs <>
- ✅ Finally got correct paths
- ✅ Created warning doc

**Today (Dec 27):**
1. Verify compile success
2. Attach to MT5 chart
3. Test ZMQ communication
4. Test strategy execution
5. Monitor system

**Critical Files:**
1. ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md (READ FIRST!)
2. DAILY_LOG_20251226.md
3. TODO_20251227.md
4. HANDOFF_PROMPT_20251227.md

**Include Syntax:**
```mql5
✅ #include "../Include/MqlMsgPack.mqh"
✅ #include "../Include/Zmq/ZmqHub.mqh"
❌ #include <MqlMsgPack.mqh>  // WRONG!
```

---

## 📚 FULL VERSION (5 minutes)

Use **HANDOFF_PROMPT_20251227.md** - paste entire content to new chat

**Attach these files:**
1. ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md ⭐
2. DAILY_LOG_20251226.md
3. TODO_20251227.md
4. README_20251226.md
5. INSTALLATION_CHECKLIST.md

---

## 🎯 WHAT CLAUDE NEEDS TO KNOW

### **Project:**
FlashEASuite V2 - High-frequency trading system

### **Architecture:**
```
FeederEA (MQL5) → (7777) → Python Brain → (7778) → ProgramC (MQL5)
                                ↑                        |
                                └──────(7779)────────────┘
```

### **Current Status:**
```
FeederEA:        ✅ Working
Python Brain:    ✅ Working
ProgramC_Trader: ⏳ Pending test (code complete)
```

### **Yesterday's Issue:**
Include path confusion - wasted 4 hours

### **Today's Goal:**
Complete ProgramC integration and testing

---

## ⚠️ CRITICAL WARNINGS

### **For Claude:**
```
YOU WILL MAKE INCLUDE PATH MISTAKES!
This is proven. Read the warning doc FIRST.

Rules (memorize):
"" = Local/Project files
<> = System files (MQL5/Include/) ONLY

FlashEASuite_V2/Include/ files → ALL use ""
```

### **For User:**
```
- Give tree structure if path issues occur
- Emphasize "" vs <> clearly
- Check includes before compile
- Test incrementally
```

---

## 📁 FILE CHECKLIST

**Must Have:**
```
☐ ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
☐ DAILY_LOG_20251226.md
☐ TODO_20251227.md
☐ HANDOFF_PROMPT_20251227.md
☐ README_20251226.md
```

**Code Files:**
```
☐ ProgramC_Trader_FINAL.mq5
☐ MqlMsgPack.mqh
☐ TEST_MqlMsgPack.mq5
☐ MINIMAL_TEST.mq5
```

**Reference:**
```
☐ SYSTEM_OVERVIEW.md
☐ DATA_CONTROL_FLOW.md
☐ INSTALLATION_CHECKLIST.md
```

---

## 🚀 SESSION START CHECKLIST

```
☐ 1. Start new chat
☐ 2. Choose prompt version (Quick/Medium/Full)
☐ 3. Attach required files
☐ 4. Wait for Claude acknowledgment
☐ 5. Verify Claude read warning doc
☐ 6. Start with compile status question
```

---

## 💬 FIRST QUESTION TEMPLATES

**Thai:**
```
"ProgramC_Trader.mq5 compile สำเร็จหรือยังครับ?"
```

**English:**
```
"Did ProgramC_Trader.mq5 compile successfully?"
```

**Expected Response:**
```
Claude should acknowledge:
✅ Read warning doc
✅ Understand current status
✅ Know include path rules
✅ Ready to help based on compile result
```

---

## 🎯 SUCCESS CRITERIA

**Today:**
```
Minimum: ProgramC compiles + attaches to MT5
Target:  Full system integration working
Stretch: 1 hour stable operation
```

**This Week:**
```
Mon (Dec 27): Integration complete
Tue-Wed:      Performance tuning
Thu-Fri:      Live testing preparation
```

---

## 📊 TIME ESTIMATES

```
Compile fix (if needed):    30 min - 2 hours
Integration testing:        2-3 hours
Performance testing:        1-2 hours
Bug fixes:                  1-2 hours
Documentation:              1 hour
─────────────────────────────────────
Total:                      5-10 hours
```

---

## 🔧 QUICK TROUBLESHOOTING

**Compile Error:**
```
→ Read ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
→ Check all includes use ""
→ Verify ../Include/... paths
```

**ZMQ Error:**
```
→ Check Python Brain running
→ Verify ports 7777, 7778, 7779
→ Check MT5 "Allow DLL imports"
```

**No Policy Received:**
```
→ Check Python sending (port 7778)
→ Verify symbol match (XAUUSD)
→ Check ZMQ connection logs
```

---

## 📱 CONTACT POINTS

**If Stuck:**
1. Read warning doc again
2. Check daily log for similar issues
3. Review TODO list
4. Ask user for clarification
5. Test with minimal example

**Don't:**
- Assume anything
- Repeat yesterday's mistakes
- Skip reading documentation
- Change multiple things at once

---

## ✅ FINAL REMINDERS

**For Claude:**
```
⚠️ Include paths are your weakness
📚 Read docs before suggesting fixes
🧪 Test incrementally
📝 Document everything
❓ Ask when uncertain
```

**For User:**
```
📂 Provide tree structure early
✅ Verify includes before compile
🔍 Check logs carefully
⏱️ Test one thing at a time
📋 Keep daily log updated
```

---

**Created:** December 26, 2025  
**For:** December 27, 2025  
**Status:** Ready for handoff  
**Priority:** Complete ProgramC integration

---

## 🎯 ONE-LINER SUMMARY

**Yesterday:** Wrote ProgramC, fought include paths, won eventually  
**Today:** Test compile, integrate system, make it work  
**Critical:** Read warning doc, use "" not <>, test carefully
