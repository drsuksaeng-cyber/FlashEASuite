# 🔄 FlashEASuite V2 - Handoff Prompt (Next Session)

**Date Prepared:** December 27, 2025, 19:00
**For:** Next AI assistant session
**Project:** FlashEASuite V2 HFT System

---

## 🎯 **CRITICAL: Read This First**

### **🔥 IRON RULES - NEVER BREAK:**

```
1. ❌ NEVER GUESS - ALWAYS ASK
   - Don't assume files exist
   - Don't assume APIs work
   - Don't assume protocols match
   
2. ❌ NEVER CODE WITHOUT FILES
   - Request actual files FIRST
   - Read and understand
   - THEN write code
   
3. ❌ NEVER PROVIDE PARTIAL SOLUTIONS
   - Check dependencies
   - Grep for imports/usages
   - Provide ALL affected files
   
4. ❌ NEVER FORGET present_files()
   - After create_file()
   - Call present_files() IMMEDIATELY
   - No exceptions
   
5. ❌ NEVER GIVE MULTIPLE OPTIONS
   - Analyze situation
   - Recommend ONE best solution
   - Explain WHY
```

---

## 📊 **Current System Status**

### **✅ What's WORKING:**

```
1. ZMQ Communication (3 ports):
   ✅ Port 7777: FeederEA → Python (tick data)
   ✅ Port 7778: Python → ProgramC (policies)
   ✅ Port 7779: ProgramC → Python (feedback)

2. Message Deserialization:
   ✅ Python sends Custom Protocol (79 bytes)
   ✅ MQL5 reads Custom Protocol
   ✅ Deserialize success rate: 100%
   ✅ Poll success: 75+ policies received

3. System Components:
   ✅ FeederEA broadcasts tick data
   ✅ Python Brain receives ticks (0 currently, market closed)
   ✅ Python sends policies every 5 seconds
   ✅ ProgramC receives and deserializes
   ✅ Feedback loop operational

4. Recent Fixes:
   ✅ ZMQ setSubscribe() bug fixed (Zmq.mqh)
   ✅ Protocol alignment (Custom Protocol both sides)
   ✅ policy.py using pack_custom_protocol()
   ✅ engine.py using publish_policy_custom()
```

### **❌ What's NOT Working:**

```
1. Trade Execution:
   ❌ Entry price: 0.0 (hardcoded)
   ❌ Stop loss: 0.0 (hardcoded)
   ❌ Take profit: 0.0 (hardcoded)
   ❌ Risk Guardian rejects trades
   
2. Price Calculation:
   ❌ Python doesn't calculate real prices
   ❌ Needs market price integration
   ❌ Needs SL/TP calculation logic
   
3. Strategy Logic:
   ❌ Currently sends dummy BUY signals
   ❌ No Grid strategy implementation
   ❌ No market analysis integration
```

---

## 📁 **Important Files (Attached)**

### **Core Documentation:**
```
1. SYSTEM_OVERVIEW.md
   - Complete system architecture
   - Data flow diagrams
   - Component descriptions
   
2. REFACTORING_COMPLETE.md
   - Code structure (refactored)
   - Module organization
   
3. DATA_CONTROL_FLOW.md
   - Detailed flow diagrams
   - Timing analysis
   
4. FEEDER_EA_TECHNICAL_DOC.md
   - FeederEA deep dive
```

### **Working Code (Already Deployed):**
```
1. policy_CUSTOM_PROTOCOL.py
   - Located: 02_Brain/core/strategy/policy.py
   - Contains: pack_custom_protocol() function
   - Contains: publish_policy_custom() function
   
2. engine_FIXED.py
   - Located: 02_Brain/core/strategy/engine.py
   - Uses: publish_policy_custom() (not array!)
   
3. Serialization.mqh
   - Located: Include/Network/Protocol/Serialization.mqh
   - Uses: Custom Protocol (not MessagePack!)
   - Works: DeserializePolicyMessage() operational
```

### **Session Logs:**
```
1. SESSION_REVIEW.md
   - What went wrong
   - Performance analysis
   
2. LOGBOOK_DETAILED.md
   - Mistakes made
   - Prevention strategies
   - Iron Rules
```

---

## 🔍 **Critical Technical Details**

### **Protocol Format (MUST UNDERSTAND):**

**Python Sends (Custom Protocol):**
```python
def pack_custom_protocol(...):
    data = bytearray()
    data.extend(struct.pack('>i', msg_type))    # int32: 2
    data.extend(struct.pack('>i', len(symbol))) # int32: length
    data.extend(symbol.encode('utf-8'))         # string bytes
    data.extend(struct.pack('>i', action))      # int32: 1=BUY
    data.extend(struct.pack('>d', confidence))  # double: 0.8
    # ... more fields
    return bytes(data)
```

**MQL5 Receives (Serialization.mqh):**
```cpp
bool DeserializePolicyMessage(const uchar &buffer[], PolicyMessage &msg)
{
    int offset = 0;
    int msg_type;
    ReadInt32(buffer, offset, msg_type);  // Read int32
    ReadString(buffer, offset, msg.symbol); // Read string
    ReadInt32(buffer, offset, msg.action);  // Read int32
    ReadDouble(buffer, offset, msg.confidence); // Read double
    // ... more fields
}
```

**Format Matches:** Big-endian, Custom Protocol (NOT MessagePack!)

---

### **Current Python Policy Logic:**

```python
# In engine.py line ~188:
if current_time - last_grid_policy_time >= GRID_POLICY_INTERVAL:
    from .policy import publish_policy_custom
    publish_policy_custom('XAUUSD', self.pub_socket)

# In policy.py:
def publish_policy_custom(symbol, pub_socket):
    packed = pack_custom_protocol(
        msg_type=2,           # POLICY
        symbol=symbol,        # "XAUUSD"
        action=1,             # BUY (hardcoded!)
        confidence=0.8,       # Fixed!
        entry_price=0.0,      # ❌ Problem: needs real price
        stop_loss=0.0,        # ❌ Problem: needs calculation
        take_profit=0.0,      # ❌ Problem: needs calculation
        position_size=0.01,   # ❌ Problem: fixed lot
        timestamp_ms=int(time.time() * 1000),
        model_version="CUSTOM_V1"
    )
    pub_socket.send(packed)
```

---

## 🎯 **Next Steps (Priority Order)**

### **1. Fix Price Calculation (HIGH PRIORITY):**

```python
# Current: Hardcoded 0.0
entry_price=0.0,
stop_loss=0.0,
take_profit=0.0,

# Needed: Real prices
entry_price = get_current_market_price(symbol)  # From tick data
stop_loss = entry_price - (atr * 2.0)           # ATR-based
take_profit = entry_price + (atr * 3.0)         # Risk:Reward 1:1.5
```

**How to get current price:**
```python
# Option 1: From tick data (in tick_buffer)
latest_tick = self.tick_buffer[-1]
current_bid = latest_tick.get('bid')
current_ask = latest_tick.get('ask')

# Option 2: Store in market state
self.latest_prices[symbol] = {'bid': bid, 'ask': ask}

# For BUY: Use ask price
entry_price = current_ask
```

### **2. Implement Risk Calculation:**

```python
# Calculate lot size based on risk
account_balance = 100000  # Get from account info
risk_percent = 0.01  # 1%
sl_distance = abs(entry_price - stop_loss)
pip_value = get_pip_value(symbol)
lot_size = (account_balance * risk_percent) / (sl_distance / pip_value)
```

### **3. Add Market Analysis:**

```python
# Use existing MarketAnalyzer
signal = self.market_analyzer.analyze_market(
    tick_data,
    self.tick_buffer,
    self.feedback_processor.is_in_cooldown()
)

# Generate action based on signal
if signal == 'BUY':
    action = 1
elif signal == 'SELL':
    action = 2
else:
    action = 0  # HOLD
```

### **4. Integrate Grid Strategy:**

Currently policy has Grid-specific fields:
```python
# In publish_policy_with_grid_data():
'risk_multiplier': stats['risk_multiplier'],
'is_in_cooldown': stats['is_in_cooldown'],
'csm': csm_data,
```

But Custom Protocol doesn't support these yet.

**Two options:**
1. Extend Custom Protocol to include Grid fields
2. Keep simple for now, add later

---

## ⚠️ **Critical Warnings**

### **1. Protocol Format is Fixed:**
```
⚠️ DO NOT change protocol format without updating BOTH sides
⚠️ Python and MQL5 must match EXACTLY
⚠️ Big-endian encoding required
⚠️ String format: int32 length + UTF-8 bytes
```

### **2. Function Names Matter:**
```
⚠️ publish_policy_custom() in policy.py
⚠️ engine.py imports it
⚠️ If you rename, update BOTH files
⚠️ Grep for usages first!
```

### **3. Market is Closed:**
```
⚠️ Ticks processed: 0 (no market data)
⚠️ Can still test with hardcoded data
⚠️ Real testing needs market open
```

### **4. Files vs Reality:**
```
⚠️ Documentation may be outdated
⚠️ ALWAYS ask user for current files
⚠️ DON'T assume based on docs
⚠️ Verify with actual code
```

---

## 🔥 **Mandatory Process Checklist**

### **Before Writing ANY Code:**

```
☐ 1. Understand the problem clearly
☐ 2. Ask: "What files exist currently?"
☐ 3. Request: "Please upload relevant files"
☐ 4. Read and understand uploaded files
☐ 5. Verify dependencies (imports, usages)
☐ 6. Plan complete solution
☐ 7. THEN write code
☐ 8. Immediately present_files()
```

### **When Suggesting Solutions:**

```
☐ 1. Analyze all approaches
☐ 2. Choose BEST one
☐ 3. Recommend ONLY that one
☐ 4. Explain clearly WHY
☐ 5. Provide step-by-step instructions
☐ 6. Include verification steps
```

### **When Modifying Existing Code:**

```
☐ 1. Grep for imports: grep "from .* import function_name"
☐ 2. Grep for usages: grep "function_name("
☐ 3. List ALL affected files
☐ 4. Update ALL files
☐ 5. Present ALL files together
☐ 6. Test imports work
```

---

## 📚 **Context You Should Know**

### **User Preferences:**
- Language: Thai for explanations, English for code
- Style: Direct solutions, not lengthy explanations
- Experience: PhD in Computer Education, advanced technical knowledge
- Working hours: Flexible, may start new session daily

### **Project Goal:**
- Build HFT system achieving >1% daily return
- Maintain max drawdown <20%
- Integrate AI analysis with automated trading
- 5 trading strategies with separate Magic Numbers

### **Current Phase:**
- ✅ Phase 1: System architecture (DONE)
- ✅ Phase 2: ZMQ communication (DONE)
- ✅ Phase 3: Protocol alignment (DONE)
- 🔄 Phase 4: Trading logic (IN PROGRESS)
- ⏳ Phase 5: Grid strategy (NEXT)

---

## 🎯 **Success Criteria for Next Session**

### **Expected Outcomes:**
```
1. ✅ Trades execute successfully (not rejected)
2. ✅ Real prices calculated from market data
3. ✅ SL/TP calculated properly
4. ✅ Risk management working
5. ✅ No "Invalid prices" errors
```

### **Testing Checklist:**
```
☐ Python sends real prices (not 0.0)
☐ ProgramC accepts policy
☐ Risk Guardian approves
☐ Order placed successfully
☐ Feedback sent back to Python
☐ Performance metrics updated
```

---

## 📁 **Files to Attach to Next Session**

### **Required:**
```
1. SYSTEM_OVERVIEW.md       (architecture)
2. This HANDOFF_PROMPT.md   (current status)
3. LOGBOOK_DETAILED.md      (mistakes to avoid)
```

### **Optional (if needed):**
```
4. policy_CUSTOM_PROTOCOL.py  (current Python code)
5. engine_FIXED.py            (current engine code)
6. Serialization.mqh          (current MQL5 code)
```

### **For Reference:**
```
7. SESSION_REVIEW.md     (what went wrong)
8. REFACTORING_COMPLETE.md  (code structure)
```

---

## 🎓 **Learning from Previous Session**

### **What Went Wrong:**
1. ❌ Provided code without verifying files exist
2. ❌ Suggested MessagePack when system uses Custom Protocol
3. ❌ Forgot to present_files() after creation
4. ❌ Changed function name but forgot caller
5. ❌ Gave 3 options instead of 1 recommendation

### **What Worked:**
1. ✅ Found root cause (setSubscribe bug)
2. ✅ Systematic debugging approach
3. ✅ Clear Thai explanations
4. ✅ Eventually correct solution
5. ✅ Persistence

---

## 💬 **Sample Opening Message for Next Session**

```
สวัสดีครับ ผมต่อจาก session ที่แล้ว

ระบบตอนนี้:
✅ ZMQ communication ทำงาน
✅ Deserialize สำเร็จ 100%
✅ Feedback loop operational

แต่ยังมีปัญหา:
❌ Entry/SL/TP = 0.0 (hardcoded)
❌ Risk Guardian rejects trades

ผมต้องการความช่วยเหลือในการ:
1. คำนวณราคาจริงจาก market data
2. คำนวณ SL/TP ตาม ATR
3. คำนวณ lot size ตาม risk

กรุณาอ่าน HANDOFF_PROMPT.md และ LOGBOOK_DETAILED.md ก่อนครับ
โดยเฉพาะ "Iron Rules" section

⚠️ ข้อสำคัญ: ห้ามเดา! ถ้าไม่แน่ใจให้ถามขอไฟล์เสมอ
```

---

## 🎯 **Final Checklist for Next AI**

```
☐ Read HANDOFF_PROMPT.md completely
☐ Read LOGBOOK_DETAILED.md (Iron Rules)
☐ Read SYSTEM_OVERVIEW.md (architecture)
☐ Understand current status (what works, what doesn't)
☐ Follow Iron Rules strictly
☐ ASK for files before coding
☐ Provide complete solutions only
☐ present_files() immediately
☐ One clear recommendation

Ready to continue!
```

---

**Prepared by:** Claude (Session Dec 27, 2025)
**For:** Next AI Assistant
**User:** Dr. Suksaeng Kukanok
**Project:** FlashEASuite V2 HFT System
