# 🏗️ Architecture Review & Improvement Suggestions

## 📋 **บทวิเคราะห์จาก Senior Architect**

---

## 1️⃣ **Concurrency Analysis** 

### **คำถาม:** `mp.Queue` เร็วพอสำหรับ HFT Feedback หรือไม่? ควรใช้ Pipes แทนไหม?

### **คำตอบ: mp.Queue เหมาะสมสำหรับ use case นี้**

---

### **🔍 การวิเคราะห์:**

#### **A. Performance Comparison:**

| Feature | mp.Queue | mp.Pipe | Shared Memory |
|---------|----------|---------|---------------|
| **Latency** | ~100-500 µs | ~50-200 µs | ~10-50 µs |
| **Throughput** | 10k-50k msg/s | 50k-100k msg/s | 100k+ msg/s |
| **Safety** | ✅ Thread-safe | ⚠️ Requires lock | ⚠️ Complex |
| **Multi-producer** | ✅ Yes | ❌ No (1-to-1) | ⚠️ Requires sync |
| **Ease of use** | ✅ Simple | ✅ Simple | ❌ Complex |

#### **B. HFT Requirements Analysis:**

**ความเร็วที่ต้องการ:**
- Trade execution: 1-10 ms (MT5 → Open position)
- Feedback latency: 10-50 ms (Acceptable)
- Total loop: < 100 ms (Good)

**ความถี่ของ Feedback:**
- HFT: 10-100 trades/minute
- Feedback messages: 10-100 msg/minute
- Peak load: ~2 msg/second

**คำนวณ:**
```
Current: mp.Queue = ~100 µs = 0.1 ms
Required: < 50 ms
Margin: 50 / 0.1 = 500x headroom
```

**สรุป:** ✅ **mp.Queue มี performance มากเกินพอ**

---

### **💡 Recommendations:**

#### **Option 1: Keep mp.Queue (แนะนำ)**

**เหมาะกับ:**
- ✅ HFT feedback (< 100 msg/s)
- ✅ Multiple producers (future expansion)
- ✅ Need for safety & reliability

**Pros:**
- Thread-safe by default
- No data corruption risk
- Easy to debug
- Proven in production

**Cons:**
- ~100 µs latency (negligible for HFT feedback)
- Memory overhead (~1 MB per queue)

**Use When:**
- ความถี่ feedback < 1000 msg/s
- Need multi-producer capability
- Reliability > absolute speed

---

#### **Option 2: Upgrade to mp.Pipe (ถ้าจำเป็น)**

**เหมาะกับ:**
- Ultra-low latency (< 100 µs)
- 1-to-1 communication only
- Single producer → Single consumer

**Implementation:**
```python
# In main.py
feedback_pipe_recv, feedback_pipe_send = mp.Pipe(duplex=False)

# ExecutionListener
def run(self):
    # Send feedback
    self.feedback_pipe.send(result)

# StrategyEngine
def run(self):
    # Receive feedback (blocking)
    if self.feedback_pipe.poll(timeout=0.1):
        feedback = self.feedback_pipe.recv()
```

**Pros:**
- ~50 µs latency (2x faster)
- Lower memory usage
- Simpler internals

**Cons:**
- ❌ 1-to-1 only (can't scale to multiple listeners)
- ❌ No built-in queue (must handle buffering)
- ❌ Less flexible

**Use When:**
- Need < 100 µs latency
- Architecture is 1-to-1 only
- No future scaling needs

---

#### **Option 3: Shared Memory (overkill)**

**ใช้เมื่อ:**
- Need < 10 µs latency
- Ultra-high throughput (> 100k msg/s)
- Willing to handle complexity

**ไม่แนะนำเพราะ:**
- ❌ Complexity สูง (manual locking)
- ❌ Risk of race conditions
- ❌ Harder to debug
- ❌ Overkill for feedback use case

---

### **✅ Final Recommendation:**

**สำหรับ FlashEASuite V2:**
```
🎯 Keep mp.Queue
```

**เหตุผล:**
1. ✅ Performance พอสำหรับ HFT feedback
2. ✅ Safe & reliable
3. ✅ Easy to maintain
4. ✅ Scales to multiple producers (future-proof)
5. ✅ Industry standard (proven)

**เมื่อไหร่ควร upgrade:**
- ถ้า latency > 50 ms consistently
- ถ้า throughput > 10k msg/s
- ถ้า profiling แสดงว่า queue เป็น bottleneck

---

## 2️⃣ **Data Integrity & Persistence**

### **คำถาม:** ถ้า MT5 ส่ง result แต่ Python restart กำลัง จะทำอย่างไร?

### **คำตอบ: ต้องมี Persistence Strategy**

---

### **🔍 ปัญหาที่เป็นไปได้:**

#### **Scenario 1: Python Crash ขณะรับข้อมูล**
```
MT5 → Send Result (Ticket 123, +15.75)
        ↓
Python → [CRASH] ← ข้อมูลหาย!
        ↓
Restart → ไม่รู้ว่า Ticket 123 เกิดอะไร
```

#### **Scenario 2: Network Timeout**
```
MT5 → Send Result
        ↓ [network delay]
Python → [TIMEOUT] → Skip message
```

#### **Scenario 3: Deliberate Restart**
```
User → Restart Python (update code)
MT5 → Send 5 results during restart
Python → [MISSED 5 messages]
```

---

### **💡 Solutions:**

#### **Solution 1: ZMQ High Water Mark (HWM) - พื้นฐาน**

**Implementation:**
```python
# In execution_listener.py
self.pull_socket.setsockopt(zmq.RCVHWM, 1000)  # Buffer 1000 messages

# In MT5 ProgramC_Trader.mq5
g_PushSocket.setSendHighWaterMark(1000);  // Buffer 1000 messages
```

**Pros:**
- ✅ ง่าย (1 line)
- ✅ Buffer messages during downtime
- ✅ No disk I/O

**Cons:**
- ❌ Limited to memory (lost if restart)
- ❌ Fixed buffer size

**Use When:**
- Short downtimes (< 30s)
- Restart frequency < 1/day

---

#### **Solution 2: Disk-based Queue (SQLite) - แนะนำ**

**Implementation:**
```python
import sqlite3
from datetime import datetime

class PersistentFeedbackQueue:
    def __init__(self, db_path='data/feedback_queue.db'):
        self.conn = sqlite3.connect(db_path)
        self._create_table()
    
    def _create_table(self):
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS feedback_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                ticket INTEGER,
                symbol TEXT,
                profit REAL,
                data BLOB,
                processed INTEGER DEFAULT 0,
                created_at TEXT
            )
        ''')
        self.conn.commit()
    
    def enqueue(self, result):
        """Store feedback to disk."""
        self.conn.execute('''
            INSERT INTO feedback_queue 
            (timestamp, ticket, symbol, profit, data, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            result['timestamp'],
            result['ticket'],
            result['symbol'],
            result['profit'],
            msgpack.packb(result),
            datetime.now().isoformat()
        ))
        self.conn.commit()
    
    def dequeue(self):
        """Get next unprocessed feedback."""
        cursor = self.conn.execute('''
            SELECT id, data FROM feedback_queue
            WHERE processed = 0
            ORDER BY timestamp ASC
            LIMIT 1
        ''')
        row = cursor.fetchone()
        
        if row:
            id_, data = row
            result = msgpack.unpackb(data, raw=False)
            
            # Mark as processed
            self.conn.execute('''
                UPDATE feedback_queue
                SET processed = 1
                WHERE id = ?
            ''', (id_,))
            self.conn.commit()
            
            return result
        return None
    
    def get_pending_count(self):
        """Count unprocessed messages."""
        cursor = self.conn.execute('''
            SELECT COUNT(*) FROM feedback_queue
            WHERE processed = 0
        ''')
        return cursor.fetchone()[0]

# Usage in ExecutionListener:
class ExecutionListener(mp.Process):
    def __init__(self, ...):
        # ...
        self.persistent_queue = PersistentFeedbackQueue()
    
    def run(self):
        # On startup - process backlog
        pending = self.persistent_queue.get_pending_count()
        if pending > 0:
            print(f"📦 Processing {pending} pending feedbacks...")
            while True:
                result = self.persistent_queue.dequeue()
                if not result:
                    break
                self.feedback_queue.put(result)
        
        # Normal operation
        while not self.shutdown_event.is_set():
            raw_data = self.pull_socket.recv()
            result = self._parse_trade_result(raw_data)
            
            # Store to disk first
            self.persistent_queue.enqueue(result)
            
            # Then forward to queue
            self.feedback_queue.put(result)
```

**Pros:**
- ✅ Survives restarts
- ✅ No message loss
- ✅ Can replay history
- ✅ Audit trail

**Cons:**
- ❌ Disk I/O overhead (~1-5 ms per message)
- ❌ Need cleanup (old messages)

**Use When:**
- Critical feedback (money involved)
- Need audit trail
- Restart frequency > 1/day

---

#### **Solution 3: Redis Queue - Production Grade**

**Implementation:**
```python
import redis

class RedisFeedbackQueue:
    def __init__(self, host='localhost', port=6379):
        self.redis = redis.Redis(host=host, port=port)
        self.queue_key = 'flashea:feedback_queue'
    
    def enqueue(self, result):
        """Push to Redis list."""
        packed = msgpack.packb(result)
        self.redis.rpush(self.queue_key, packed)
    
    def dequeue(self, timeout=1):
        """Pop from Redis list (blocking)."""
        data = self.redis.blpop(self.queue_key, timeout=timeout)
        if data:
            _, packed = data
            return msgpack.unpackb(packed, raw=False)
        return None
    
    def get_queue_length(self):
        """Get queue size."""
        return self.redis.llen(self.queue_key)
```

**Pros:**
- ✅ Fast (~0.1 ms latency)
- ✅ Persistent
- ✅ Distributed (multiple servers)
- ✅ Production-proven

**Cons:**
- ❌ Need Redis server
- ❌ Additional dependency
- ❌ More complex setup

**Use When:**
- Production environment
- Multiple Brain instances
- Need high availability

---

### **✅ Recommendation:**

**ระยะสั้น (Development):**
```
🎯 Solution 1: ZMQ HWM
```
- เพียงพอสำหรับ development
- ไม่มี complexity

**ระยะยาว (Production):**
```
🎯 Solution 2: SQLite Queue
```
- Persistent
- No external dependencies
- Good enough for single instance

**Enterprise:**
```
🎯 Solution 3: Redis
```
- Scalable
- High availability
- Multi-instance support

---

## 3️⃣ **Expansion Advice - Before Elastic Grid**

### **สิ่งที่ควรเตรียม:**

---

### **A. Strategy Interface Standardization**

**ปัญหา:**
- ตอนนี้ Strategy logic อยู่ใน `strategy.py` แบบ hardcode
- เพิ่ม strategy ใหม่ = แก้ code

**แนะนำ: Strategy Pattern**

```python
# Create: core/strategy_base.py

from abc import ABC, abstractmethod

class StrategyBase(ABC):
    """Base class for all trading strategies."""
    
    def __init__(self, name: str, config: dict):
        self.name = name
        self.config = config
        self.risk_multiplier = 1.0
        self.is_in_cooldown = False
    
    @abstractmethod
    def analyze(self, tick_data: dict) -> Optional[str]:
        """
        Analyze market and return signal.
        
        Returns:
            'BUY', 'SELL', or None
        """
        pass
    
    @abstractmethod
    def process_feedback(self, feedback: dict) -> None:
        """Process trade result feedback."""
        pass
    
    def set_cooldown(self, duration: float) -> None:
        """Set cooldown period."""
        self.is_in_cooldown = True
        self.cooldown_until = time.time() + duration
    
    def check_cooldown(self) -> bool:
        """Check if in cooldown."""
        if not self.is_in_cooldown:
            return False
        
        if time.time() >= self.cooldown_until:
            self.is_in_cooldown = False
            return False
        
        return True

# Implement strategies:

class SpikeStrategy(StrategyBase):
    """Spike hunting strategy."""
    
    def analyze(self, tick_data):
        if self.check_cooldown():
            return None
        
        # Original spike logic here
        return signal

class GridStrategy(StrategyBase):
    """Elastic grid strategy."""
    
    def analyze(self, tick_data):
        # Grid logic here
        pass

# In main strategy engine:

class StrategyEngine:
    def __init__(self, ...):
        self.strategies = [
            SpikeStrategy('spike', config.SPIKE_CONFIG),
            GridStrategy('grid', config.GRID_CONFIG),
        ]
    
    def run(self):
        for strategy in self.strategies:
            signal = strategy.analyze(tick_data)
            if signal:
                self.execute_signal(signal, strategy)
```

**Benefits:**
- ✅ Add new strategies easily
- ✅ Enable/disable strategies dynamically
- ✅ Test strategies independently
- ✅ Shared feedback mechanism

---

### **B. Configuration Management**

**ปัญหา:**
- Parameters hardcoded ใน `strategy.py`
- ต้อง restart เพื่อเปลี่ยนค่า

**แนะนำ: Hot-reload Config**

```python
# config/strategies.yaml

spike:
  enabled: true
  velocity_threshold: 0.5
  cooldown_seconds: 30
  emergency_cooldown: 300
  max_consecutive_losses: 3

grid:
  enabled: true
  grid_size: 5
  atr_multiplier: 1.5
  max_orders: 10
```

```python
# core/config_manager.py

import yaml
import threading
import time

class ConfigManager:
    """Hot-reload configuration manager."""
    
    def __init__(self, config_file='config/strategies.yaml'):
        self.config_file = config_file
        self.config = {}
        self.load_config()
        
        # Start watcher thread
        self.watcher_thread = threading.Thread(target=self._watch_config)
        self.watcher_thread.daemon = True
        self.watcher_thread.start()
    
    def load_config(self):
        """Load config from file."""
        with open(self.config_file, 'r') as f:
            self.config = yaml.safe_load(f)
        print(f"✅ Config loaded from {self.config_file}")
    
    def get(self, key, default=None):
        """Get config value."""
        keys = key.split('.')
        value = self.config
        for k in keys:
            value = value.get(k)
            if value is None:
                return default
        return value
    
    def _watch_config(self):
        """Watch config file for changes."""
        last_mtime = os.path.getmtime(self.config_file)
        
        while True:
            time.sleep(5)  # Check every 5 seconds
            
            try:
                current_mtime = os.path.getmtime(self.config_file)
                if current_mtime > last_mtime:
                    print("📝 Config file changed, reloading...")
                    self.load_config()
                    last_mtime = current_mtime
            except Exception as e:
                print(f"⚠️ Config watch error: {e}")
```

**Benefits:**
- ✅ Change parameters without restart
- ✅ A/B testing strategies
- ✅ Easy parameter tuning

---

### **C. Performance Monitoring**

**แนะนำ: Metrics Collection**

```python
# core/metrics.py

import time
from collections import defaultdict, deque

class MetricsCollector:
    """Collect and report performance metrics."""
    
    def __init__(self):
        self.counters = defaultdict(int)
        self.timers = {}
        self.latencies = defaultdict(lambda: deque(maxlen=1000))
    
    def increment(self, metric: str, value: int = 1):
        """Increment counter."""
        self.counters[metric] += value
    
    def time_start(self, operation: str):
        """Start timing operation."""
        self.timers[operation] = time.time()
    
    def time_end(self, operation: str):
        """End timing and record latency."""
        if operation in self.timers:
            latency = (time.time() - self.timers[operation]) * 1000  # ms
            self.latencies[operation].append(latency)
            del self.timers[operation]
    
    def get_stats(self):
        """Get all statistics."""
        stats = {}
        
        # Counters
        stats['counters'] = dict(self.counters)
        
        # Latencies (p50, p95, p99)
        stats['latencies'] = {}
        for op, lats in self.latencies.items():
            if lats:
                sorted_lats = sorted(lats)
                stats['latencies'][op] = {
                    'count': len(lats),
                    'p50': sorted_lats[len(lats)//2],
                    'p95': sorted_lats[int(len(lats)*0.95)],
                    'p99': sorted_lats[int(len(lats)*0.99)],
                }
        
        return stats

# Usage:

metrics = MetricsCollector()

# In ExecutionListener
metrics.time_start('feedback_receive')
raw_data = self.pull_socket.recv()
metrics.time_end('feedback_receive')
metrics.increment('feedback_received')

# In StrategyEngine
metrics.time_start('feedback_process')
self._process_feedback(feedback)
metrics.time_end('feedback_process')

# Report every 60s
if time.time() - last_report > 60:
    stats = metrics.get_stats()
    print(f"📊 Performance Stats:")
    print(f"   Feedback received: {stats['counters']['feedback_received']}")
    print(f"   Receive latency p95: {stats['latencies']['feedback_receive']['p95']:.2f} ms")
    print(f"   Process latency p95: {stats['latencies']['feedback_process']['p95']:.2f} ms")
```

**Benefits:**
- ✅ Identify bottlenecks
- ✅ Monitor performance degradation
- ✅ Capacity planning

---

### **D. Error Recovery Strategy**

**แนะนำ: Circuit Breaker Pattern**

```python
class CircuitBreaker:
    """Prevent cascade failures."""
    
    def __init__(self, max_failures=5, timeout=60):
        self.max_failures = max_failures
        self.timeout = timeout
        self.failures = 0
        self.last_failure_time = 0
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
    
    def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker."""
        
        # Check if circuit is open
        if self.state == 'OPEN':
            if time.time() - self.last_failure_time > self.timeout:
                self.state = 'HALF_OPEN'
                print("🔌 Circuit breaker: HALF_OPEN (testing)")
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = func(*args, **kwargs)
            
            # Success - reset
            if self.state == 'HALF_OPEN':
                self.state = 'CLOSED'
                self.failures = 0
                print("✅ Circuit breaker: CLOSED (recovered)")
            
            return result
            
        except Exception as e:
            self.failures += 1
            self.last_failure_time = time.time()
            
            if self.failures >= self.max_failures:
                self.state = 'OPEN'
                print(f"🚨 Circuit breaker: OPEN (failures: {self.failures})")
            
            raise
```

**Benefits:**
- ✅ Prevent cascade failures
- ✅ Auto-recovery
- ✅ System stability

---

## 4️⃣ **Summary & Checklist**

### **✅ Current Status:**
- [x] mp.Queue: ✅ Good enough for HFT feedback
- [x] ZMQ HWM: ✅ Basic persistence
- [x] Feedback Loop: ✅ Working

### **📋 Before Elastic Grid:**

**Must Have:**
- [ ] Strategy interface (`StrategyBase`)
- [ ] Config file for parameters
- [ ] Basic metrics (counters)

**Nice to Have:**
- [ ] SQLite persistence queue
- [ ] Hot-reload config
- [ ] Circuit breaker
- [ ] Performance dashboard

**Can Wait:**
- [ ] Redis queue (production only)
- [ ] Distributed metrics
- [ ] Advanced monitoring

---

## 🎯 **Final Recommendations:**

### **ทำตอนนี้:**
1. ✅ **Keep mp.Queue** - performance เพียงพอ
2. ✅ **Add SQLite persistence** - reliability สำคัญ
3. ✅ **Create StrategyBase** - ง่ายต่อ expansion

### **ทำก่อน Production:**
4. ⭐ **Config file** - hot-reload parameters
5. ⭐ **Metrics** - monitor performance
6. ⭐ **Circuit breaker** - error recovery

### **ทำใน Production:**
7. 🚀 **Redis queue** (optional) - scalability
8. 🚀 **Distributed logging** - debugging
9. 🚀 **Alerting system** - monitoring

---

**พร้อมไป Task 2: Elastic Grid แล้วครับ!** 🎯📊

**หากต้องการ implement improvement ใด บอกได้เลยครับ!** 💬✨
