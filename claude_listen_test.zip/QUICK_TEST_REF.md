# ⚡ Quick Test Reference - One Page

## 🚀 **วิธีทดสอบแบบเร็ว (5 นาที):**

### **Step 1: Start Brain** (Terminal 1)
```bash
cd 02_ProgramB_Brain_Py
python main.py
```
**รอเห็น:** `✅ All workers started successfully (3 processes)`

---

### **Step 2: Run Test** (Terminal 2)
```bash
cd 02_ProgramB_Brain_Py
python test_feedback_loop.py
```
**เลือก:** `1` (Automated Test Suite)
**กด:** `Enter` เมื่อพร้อม

---

### **Step 3: Verify** (Terminal 1)

**ควรเห็น:**

✅ **Win Message:**
```
💚 FEEDBACK: WIN | Ticket 16373001 | Profit: +15.75
📊 Stats: 1W / 0L / +15.75 Total
```

✅ **Hot Streak (after 3 wins):**
```
🔥 HOT STREAK! 3 consecutive wins!
📈 Risk multiplier increased to 1.33x
```

✅ **Loss & Cooldown:**
```
💔 FEEDBACK: LOSS | Ticket 16373004 | Loss: -12.50
⚠️ COOLDOWN ACTIVATED for 30 seconds
📉 Risk multiplier reduced to 1.20x
```

✅ **Emergency (after 3 losses):**
```
🚨 EMERGENCY COOLDOWN! 3 consecutive losses!
🛑 Trading paused for 300 seconds
📉 Risk multiplier reduced to 0.50x
```

---

## ✅ **Checklist:**

- [ ] Brain start ได้ 3 workers
- [ ] Test script connect สำเร็จ
- [ ] เห็น 💚 WIN message
- [ ] เห็น 💔 LOSS message
- [ ] เห็น 🔥 HOT STREAK (3 wins)
- [ ] เห็น ⚠️ COOLDOWN (loss)
- [ ] เห็น 🚨 EMERGENCY (3 losses)
- [ ] Statistics ถูกต้อง (W/L count)
- [ ] Risk multiplier เปลี่ยน (0.5x-1.5x)

---

## 🐛 **ถ้ามีปัญหา:**

### **Test script ไม่ connect:**
```bash
# Check if main.py running
ps aux | grep python | grep main.py

# Check ports
netstat -ano | findstr 7779  # Windows
lsof -i :7779               # Linux/Mac
```

### **ไม่เห็น feedback message:**
```bash
# Check logs
tail -f logs/flashea_brain.log | grep FEEDBACK
```

### **Worker died:**
```bash
# Restart
Ctrl+C  # Stop main.py
python main.py  # Start again
```

---

## 📊 **Expected Performance:**

| Metric | Value |
|--------|-------|
| Workers | 3 (Ingestion, Strategy, Execution) |
| Latency | < 10 ms |
| Message rate | 100+ msg/s |
| Memory | ~150-200 MB |

---

## 🎯 **Pass Criteria:**

**PASS if:**
- ✅ All 5 scenarios complete
- ✅ No crashes or errors
- ✅ Statistics accurate
- ✅ Cooldown works
- ✅ Risk adapts correctly

**FAIL if:**
- ❌ Worker crashes
- ❌ No feedback messages
- ❌ Stats incorrect
- ❌ Cooldown doesn't work

---

## 📝 **Files:**

**Test:**
- `test_feedback_loop.py` - Test script

**Docs:**
- `INSTALLATION_TESTING_GUIDE.md` - Full guide
- `ARCHITECTURE_REVIEW.md` - Architecture review
- `QA_SUMMARY.md` - Complete summary

---

**พร้อมทดสอบแล้วครับ!** 🚀

**ใช้เวลาประมาณ 5 นาที** ⏱️
