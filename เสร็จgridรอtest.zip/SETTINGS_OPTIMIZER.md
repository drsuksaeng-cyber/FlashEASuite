# ⚙️ Settings Optimizer Guide

**Fine-tune FlashEASuite V2.10 for Maximum Performance**

---

## 🎯 Understanding Risk Parameters

### InpRiskPerTrade (Risk per Trade %)

**What it does:**
- Controls lot size for each trade
- Higher % = Larger positions
- Lower % = Smaller positions

**Example:**
```
Account: $10,000
InpRiskPerTrade: 1.0%
Entry: 2625.43
SL: 2624.43 (100 points)

Risk Amount: $10,000 × 1.0% = $100
Lot Calculation: $100 / 100 points = 0.98 lots
```

**Recommended Values:**
```
Conservative:  0.3% - 0.5%  (Micro accounts, beginners)
Moderate:      0.5% - 1.0%  (Most traders)
Balanced:      1.0% - 1.5%  (Experienced traders)
Aggressive:    1.5% - 2.5%  (High risk tolerance)
Extreme:       2.5%+        (NOT recommended)
```

**Impact on Performance:**
```
0.5% Risk:
- Smaller drawdowns
- Slower growth
- More conservative
- Lower stress

2.0% Risk:
- Larger drawdowns
- Faster growth (if winning)
- More aggressive
- Higher stress
```

---

### InpDailyLossLimit (Daily Loss Limit %)

**What it does:**
- Maximum loss allowed per day
- Trading stops when reached
- Resets next trading day

**Example:**
```
Account: $10,000
InpDailyLossLimit: 4.0%

Max Daily Loss: $10,000 × 4.0% = $400

If Daily P&L reaches -$400:
→ Trading STOPS
→ Resumes next day
```

**Recommended Values:**
```
Ultra-Conservative: 1.0% - 2.0%
Conservative:       2.0% - 3.0%
Moderate:           3.0% - 5.0%  ⭐ Recommended
Aggressive:         5.0% - 8.0%
Very Aggressive:    8.0%+        (Risky!)
```

**Relationship with Risk Per Trade:**
```
If InpRiskPerTrade = 1.0%
Then InpDailyLossLimit should be 4.0% - 5.0%

Why? Allows 4-5 losing trades before stop
```

**Best Practices:**
```
Rule: DailyLimit = RiskPerTrade × 4 to 6

Examples:
RiskPerTrade 0.5% → DailyLimit 2.0% - 3.0%
RiskPerTrade 1.0% → DailyLimit 4.0% - 6.0%
RiskPerTrade 2.0% → DailyLimit 8.0% - 12.0%
```

---

## 📊 Grid Strategy Optimization

### InpGridMaxOrders (Maximum Grid Orders)

**What it does:**
- Controls how many grid levels
- More orders = More exposure
- Fewer orders = Less risk

**Recommended Values:**
```
Conservative:  3 orders
Moderate:      5 orders  ⭐ Default
Aggressive:    7-10 orders
```

**Impact:**
```
3 Orders:
- Lower risk
- Less capital required
- Fewer opportunities
- Easier to manage

10 Orders:
- Higher risk
- More capital required
- More opportunities
- Complex management
```

---

### InpGridBaseStep (Grid Spacing in Points)

**What it does:**
- Distance between grid levels
- Wider spacing = Fewer triggers
- Tighter spacing = More triggers

**Calculation:**
```
For XAUUSD:
1 point = $0.01 price movement

100 points = $1.00
200 points = $2.00
300 points = $3.00
```

**Recommended Values:**
```
XAUUSD:
- Scalping:    50-100 points
- Normal:      150-250 points  ⭐ Recommended
- Swing:       300-500 points

EURUSD:
- Scalping:    10-20 points
- Normal:      30-50 points
- Swing:       50-100 points
```

**Market Condition Adjustment:**
```
High Volatility (ATR > 3.0):
→ Use WIDER spacing (250-400 points)
→ Prevents overtrading

Low Volatility (ATR < 1.5):
→ Use TIGHTER spacing (100-150 points)
→ More opportunities
```

---

### InpGridLotMult (Lot Size Multiplier)

**What it does:**
- How much to increase lot on each level
- Martingale factor
- Higher = More aggressive

**Values:**
```
No Scaling:     1.0x  (0.01, 0.01, 0.01...)
Conservative:   1.2x  (0.01, 0.012, 0.014...)
Moderate:       1.5x  (0.01, 0.015, 0.022...)  ⭐ Default
Aggressive:     2.0x  (0.01, 0.02, 0.04...)
Very Aggressive: 3.0x  (0.01, 0.03, 0.09...)
```

**Risk Analysis:**
```
1.5x Multiplier, 5 levels:
Level 1: 0.01 lots
Level 2: 0.015 lots
Level 3: 0.022 lots
Level 4: 0.033 lots
Level 5: 0.050 lots
Total: 0.13 lots

2.0x Multiplier, 5 levels:
Level 1: 0.01 lots
Level 2: 0.02 lots
Level 3: 0.04 lots
Level 4: 0.08 lots
Level 5: 0.16 lots
Total: 0.31 lots ← 2.4x more exposure!
```

**Recommendations:**
```
Small Account (<$5,000):   1.2x - 1.3x
Medium Account ($5-20k):   1.3x - 1.5x
Large Account (>$20k):     1.5x - 2.0x

NEVER exceed 2.5x unless you know what you're doing!
```

---

## 🎮 Configuration Profiles

### Profile 1: Ultra-Safe Tester

**Best for:**
- First-time users
- Very small accounts
- Learning the system
- Testing new strategies

```cpp
InpRiskPerTrade:      0.3%
InpDailyLossLimit:    1.5%
InpUseRiskBasedLots:  true
InpUserMaxRisk:       1.0%

InpGridMaxOrders:     3
InpGridBaseStep:      300.0
InpGridLotMult:       1.2
InpGridBaseLot:       0.01
```

**Expected:**
- Very low risk
- Slow growth
- Learning experience
- $5-15/day on $10k account

---

### Profile 2: Conservative Growth

**Best for:**
- Beginners
- Small to medium accounts
- Risk-averse traders
- Long-term compounding

```cpp
InpRiskPerTrade:      0.5%
InpDailyLossLimit:    2.5%
InpUseRiskBasedLots:  true
InpUserMaxRisk:       1.5%

InpGridMaxOrders:     4
InpGridBaseStep:      250.0
InpGridLotMult:       1.3
InpGridBaseLot:       0.01
```

**Expected:**
- Low-moderate risk
- Steady growth
- Manageable drawdowns
- $20-40/day on $10k account

---

### Profile 3: Balanced Performance ⭐

**Best for:**
- Most traders
- Medium accounts
- Balanced approach
- Good risk/reward

```cpp
InpRiskPerTrade:      1.0%
InpDailyLossLimit:    4.0%
InpUseRiskBasedLots:  true
InpUserMaxRisk:       2.0%

InpGridMaxOrders:     5
InpGridBaseStep:      200.0
InpGridLotMult:       1.5
InpGridBaseLot:       0.01
```

**Expected:**
- Moderate risk
- Good growth potential
- Acceptable drawdowns
- $50-100/day on $10k account

---

### Profile 4: Aggressive Growth

**Best for:**
- Experienced traders
- Larger accounts
- Higher risk tolerance
- Short-term gains

```cpp
InpRiskPerTrade:      1.5%
InpDailyLossLimit:    6.0%
InpUseRiskBasedLots:  true
InpUserMaxRisk:       2.5%

InpGridMaxOrders:     6
InpGridBaseStep:      150.0
InpGridLotMult:       1.8
InpGridBaseLot:       0.01
```

**Expected:**
- Higher risk
- Fast growth potential
- Larger drawdowns
- $100-200/day on $10k account

---

### Profile 5: Maximum Performance

**Best for:**
- Expert traders only
- Large accounts
- Very high risk tolerance
- Professional use

```cpp
InpRiskPerTrade:      2.0%
InpDailyLossLimit:    8.0%
InpUseRiskBasedLots:  true
InpUserMaxRisk:       3.0%

InpGridMaxOrders:     7
InpGridBaseStep:      120.0
InpGridLotMult:       2.0
InpGridBaseLot:       0.01
```

**Expected:**
- Very high risk
- Maximum growth potential
- Significant drawdowns possible
- $150-300/day on $10k account

**⚠️ WARNING:** Only for experienced traders!

---

## 📈 Optimization Strategy

### Step 1: Start Conservative

**Week 1:**
```
Use Profile 1 (Ultra-Safe Tester)
Goal: Learn system behavior
Monitor: All trades closely
Adjust: Nothing yet
```

### Step 2: Gradual Increase

**Week 2-3:**
```
Move to Profile 2 (Conservative Growth)
Goal: Build confidence
Monitor: Daily performance
Adjust: Small tweaks only
```

### Step 3: Find Your Sweet Spot

**Week 4-8:**
```
Try Profile 3 (Balanced)
Goal: Find optimal settings
Monitor: Win rate, drawdown
Adjust: Based on results
```

### Step 4: Optimize

**Month 2+:**
```
Fine-tune based on data
Goal: Maximize risk-adjusted returns
Monitor: Monthly performance
Adjust: Data-driven changes
```

---

## 🎯 Account Size Adjustments

### Micro Account ($500 - $1,000)

```cpp
InpRiskPerTrade:      0.3% - 0.5%
InpDailyLossLimit:    1.5% - 2.0%
InpGridMaxOrders:     3
InpGridBaseStep:      300.0 - 400.0
InpGridLotMult:       1.2 - 1.3
```

**Rationale:**
- Small buffer for losses
- Must be very conservative
- Focus on capital preservation

---

### Mini Account ($1,000 - $5,000)

```cpp
InpRiskPerTrade:      0.5% - 0.75%
InpDailyLossLimit:    2.5% - 3.5%
InpGridMaxOrders:     4 - 5
InpGridBaseStep:      250.0 - 300.0
InpGridLotMult:       1.3 - 1.5
```

**Rationale:**
- More room for drawdowns
- Can be slightly aggressive
- Balance growth and safety

---

### Standard Account ($5,000 - $20,000)

```cpp
InpRiskPerTrade:      0.75% - 1.5%
InpDailyLossLimit:    3.0% - 6.0%
InpGridMaxOrders:     5 - 6
InpGridBaseStep:      200.0 - 250.0
InpGridLotMult:       1.5 - 1.8
```

**Rationale:**
- Comfortable buffer
- Can optimize for growth
- Manageable risk levels

---

### Large Account ($20,000+)

```cpp
InpRiskPerTrade:      1.0% - 2.0%
InpDailyLossLimit:    4.0% - 8.0%
InpGridMaxOrders:     5 - 7
InpGridBaseStep:      150.0 - 250.0
InpGridLotMult:       1.5 - 2.0
```

**Rationale:**
- Large buffer available
- Can take calculated risks
- Focus on absolute returns

---

## 🔬 A/B Testing Method

### Method:
```
1. Run Profile A for 2 weeks
   Record: Trades, P&L, Drawdown, Win Rate

2. Run Profile B for 2 weeks
   Record: Same metrics

3. Compare results

4. Choose better profile

5. Optimize further
```

### Metrics to Track:
```
✅ Total Trades
✅ Win Rate %
✅ Average Win
✅ Average Loss
✅ Profit Factor
✅ Max Drawdown
✅ Max Daily Loss
✅ Recovery Time
✅ Sharpe Ratio (if possible)
```

---

## ⚠️ Common Mistakes

### 1. Increasing Risk Too Fast
```
❌ Week 1: 0.5%
❌ Week 2: 2.0% ← Too fast!

✅ Week 1: 0.5%
✅ Week 2: 0.6%
✅ Week 3: 0.8%
✅ Week 4: 1.0% ← Gradual
```

### 2. Not Respecting Daily Limit
```
❌ Limit reached → Trade anyway
❌ Increase limit to keep trading

✅ Limit reached → STOP
✅ Analyze what went wrong
✅ Resume next day
```

### 3. Changing Settings Too Often
```
❌ Change settings daily
❌ Chase best performance

✅ Test settings for 2+ weeks
✅ Make data-driven changes
✅ One change at a time
```

### 4. Ignoring Market Conditions
```
❌ Same settings all the time

✅ Adjust for volatility
✅ Adjust for trending vs ranging
✅ Adjust for news events
```

---

## 📊 Performance Benchmarks

### Daily Targets (on $10,000 account)

```
Conservative:
- Target: $20-40 (0.2% - 0.4%)
- Max Loss: $150 (1.5%)

Moderate:
- Target: $50-100 (0.5% - 1.0%)
- Max Loss: $400 (4.0%)

Aggressive:
- Target: $100-200 (1.0% - 2.0%)
- Max Loss: $800 (8.0%)
```

### Monthly Targets

```
Conservative: 5% - 10%
Moderate: 10% - 20%
Aggressive: 20% - 40%
```

**Note:** Past performance ≠ Future results

---

## ✅ Optimization Checklist

```
☐ Started with conservative settings
☐ Tracked performance for 2+ weeks
☐ Analyzed win rate and drawdown
☐ Made one change at a time
☐ Tested new settings for 2 weeks
☐ Documented all changes
☐ Compared before/after results
☐ Chose optimal settings
☐ Created backup of settings
☐ Ready for live trading
```

---

**Remember:** The goal is consistent, sustainable profits, not maximum returns!

**Date:** December 25, 2025  
**Version:** 2.10  
**For:** FlashEASuite Risk Enhanced
