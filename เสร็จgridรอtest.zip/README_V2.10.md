# 📘 FlashEASuite V2.10 - Risk Enhanced

**Professional Algorithmic Trading System with Advanced Risk Management**

---

## 🎯 Overview

FlashEASuite V2.10 is a production-ready high-frequency trading system featuring:

- ✅ **Automated Position Sizing** - Risk-based lot calculation
- ✅ **Daily Loss Protection** - Emergency stop at preset limits  
- ✅ **Real-time P&L Tracking** - Monitor performance live
- ✅ **Multi-Strategy System** - Grid + Spike strategies
- ✅ **AI-Powered Analysis** - Python brain with 4-worker architecture
- ✅ **Sub-10ms Latency** - High-frequency trading capable

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────┐
│              FlashEASuite V2.10                     │
│         High-Frequency Trading System               │
└─────────────────────────────────────────────────────┘
                      │
    ┌─────────────────┼─────────────────┐
    │                 │                 │
    ▼                 ▼                 ▼
┌─────────┐    ┌─────────┐     ┌─────────┐
│FeederEA │    │  Brain  │     │ Trader  │
│ (MQL5)  │    │(Python) │     │ (MQL5)  │
└─────────┘    └─────────┘     └─────────┘
    │               │                │
    │ Port 7777     │ Port 7778      │ Port 7779
    └───────────────┴────────────────┘
            ZeroMQ + MessagePack
```

### Components:

1. **FeederEA** (MQL5)
   - Collects tick data from MT5
   - Broadcasts via ZMQ port 7777
   - 50ms update interval

2. **Brain** (Python)
   - 4-worker multiprocessing
   - AI market analysis
   - Policy generation
   - Feedback loop

3. **Trader** (MQL5) - **v2.10 Enhanced**
   - Receives policies via ZMQ port 7778
   - **NEW: Position Sizing Manager**
   - **NEW: Daily Loss Limit**
   - Executes trades automatically
   - Sends results via ZMQ port 7779

---

## 🆕 What's New in V2.10

### Risk Management Integration:

#### 1. Position Sizing Manager
```
✅ Automatic lot calculation based on risk %
✅ Accounts for stop loss distance
✅ Adjusts for account balance
✅ Respects broker lot limits
```

**How it works:**
```
Entry: 2625.43
SL: 2624.43 (100 points)
Risk: 1.0% of $10,000 = $100
→ Calculated Lot: 0.98
```

#### 2. Daily Loss Limit
```
✅ Tracks P&L in real-time
✅ Stops trading when limit reached
✅ Resets daily automatically
✅ Prevents catastrophic losses
```

**How it works:**
```
Daily Limit: 4.0% of $10,000 = $400
Current P&L: $-350 → Trading continues
Current P&L: $-410 → Trading STOPPED
Next day → Limit resets
```

#### 3. Real-time Monitoring
```
✅ Win/Loss count
✅ Win rate calculation
✅ Daily P&L tracking
✅ Performance statistics
```

---

## 📊 Performance Metrics

### Target Performance:
```
Daily Return:    0.5% - 1.5%
Win Rate:        45% - 55%
Max Drawdown:    <10% (with 4% daily limit)
Avg Drawdown:    <5%
Risk/Reward:     1:1.5
```

### System Performance:
```
Latency (Python):     3-7 ms
Latency (End-to-End): 25-160 ms
Tick Processing:      ~80 ticks/second
Policy Generation:    ~20 policies/second
```

---

## ⚙️ Configuration

### Quick Settings:

#### Conservative (Recommended for beginners):
```
InpRiskPerTrade:      0.5%
InpDailyLossLimit:    2.0%
InpUseRiskBasedLots:  true
```

#### Moderate (Recommended for most):
```
InpRiskPerTrade:      1.0%
InpDailyLossLimit:    4.0%
InpUseRiskBasedLots:  true
```

#### Aggressive (Experienced only):
```
InpRiskPerTrade:      2.0%
InpDailyLossLimit:    8.0%
InpUseRiskBasedLots:  true
```

**See:** `PRE_DEPLOYMENT_GUIDE.md` for complete settings

---

## 🚀 Quick Start

### 1. Install Files:
```bash
# Copy files to correct locations
ProgramC_Trader_v2.10.mq5 → 03_Trader/
StrategyManager.mqh → Include/Logic/
```

### 2. Compile:
```bash
# Open in MetaEditor and compile
F7 → Should show 0 errors
```

### 3. Start System:
```bash
# Start Python Brain
cd 02_Brain
python main.py

# Attach FeederEA to chart (XAUUSD M1)
# Attach Trader to same chart
```

### 4. Monitor:
```bash
# Watch logs for:
✅ Position Sizing Manager initialized
✅ Daily Loss Limit initialized
✅ System Ready
```

---

## 📚 Documentation

### Core Documents:
- `PRE_DEPLOYMENT_GUIDE.md` - Setup and configuration
- `CHANGELOG.md` - Version history
- `SETTINGS_OPTIMIZER.md` - Optimize settings
- `TROUBLESHOOTING.md` - Common issues

### Technical Documents:
- `SYSTEM_OVERVIEW.md` - Complete architecture
- `REFACTORING_COMPLETE.md` - Code structure
- `DATA_CONTROL_FLOW.md` - System flow
- `FEEDER_EA_TECHNICAL_DOC.md` - FeederEA details

---

## 🔒 Risk Management Features

### Position Sizing:
```cpp
CalculateLotSize(entry, sl, risk_percent)
→ Returns: Calculated lot size based on risk
```

### Daily Limit Protection:
```cpp
CanOpenNewTrade()
→ Returns: true if can trade, false if limit reached
```

### P&L Tracking:
```cpp
UpdateDailyLimiter()
→ Automatically tracks all trades
```

---

## 📊 Expected Logs

### On Initialization:
```
========================================
  SKN V 2.10 - Risk Enhanced
  25 December 2025, 13:30
========================================
✅ ZMQ initialized: tcp://127.0.0.1:7778
✅ Risk Guardian initialized (2.0%)
✅ Position Sizing Manager initialized
   → Default Risk: 1.0%
   → Risk-Based Lots: ENABLED
✅ Daily Loss Limit initialized
   → Limit: 4.0%
   → Max Loss: $400.00
✅ System Ready: Waiting for Brain Policy...
```

### During Trading:
```
Lot Calculation:
  Entry: 2625.43
  SL: 2624.43
  Risk: 1.0%
  → Lot: 0.98

POSITION OPENED: BUY
  Lot: 0.98 (CALCULATED)
  Entry: 2625.43
  SL: 2624.43

POSITION CLOSED:
  P&L: $45.20
  Daily P&L: $45.20
```

### When Limit Reached:
```
🚨 DAILY LOSS LIMIT REACHED!
   Daily P&L: $-413.06
   Limit: $-400.00
   Time: 2025.12.26 14:30
   Trading STOPPED for today!
```

### On Shutdown:
```
📊 Daily Summary:
   Daily P&L: $-245.00
   Trades: 15
   Wins: 7
   Losses: 8
   Win Rate: 46.7%
   Status: ⚠️ LIMIT REACHED
```

---

## ⚠️ Important Notes

### Risk Disclaimer:
```
⚠️ Trading involves substantial risk of loss
⚠️ Past performance is not indicative of future results
⚠️ Start with demo account
⚠️ Never risk more than you can afford to lose
⚠️ Understand all settings before live trading
```

### System Requirements:
```
✅ MT5 Build 3770+
✅ Python 3.8+
✅ Windows 10/11 recommended
✅ Minimum 4GB RAM
✅ Stable internet connection
```

### Supported Symbols:
```
Primary: XAUUSD (Gold)
Also: EURUSD, GBPUSD, USDJPY
Others: Test carefully before use
```

---

## 🐛 Troubleshooting

### Common Issues:

**1. "Daily Loss Limit initialized" not showing:**
```
→ Check PositionSizingManager.mqh installed
→ Check DailyLossLimit.mqh installed
→ Recompile EA
```

**2. Lot size always 0.01:**
```
→ Check InpUseRiskBasedLots = true
→ Verify PositionSizingManager initialized
→ Check logs for calculation details
```

**3. Trading doesn't stop at limit:**
```
→ Verify DailyLossLimit.Initialize() called
→ Check IsLimitReached() logic
→ Review UpdateDailyLimiter() calls
```

**See:** `TROUBLESHOOTING.md` for more

---

## 📈 Performance Optimization

### To Increase Returns:
```
1. Increase InpRiskPerTrade (careful!)
2. Optimize Grid settings
3. Add more strategies
4. Improve AI analysis
```

### To Decrease Risk:
```
1. Decrease InpRiskPerTrade
2. Decrease InpDailyLossLimit
3. Use wider Grid spacing
4. Trade fewer symbols
```

**See:** `SETTINGS_OPTIMIZER.md` for details

---

## 🔄 Backup & Recovery

### Before Each Session:
```bash
# Backup code
cp -r FlashEASuite_V2 FlashEASuite_V2_BACKUP_$(date +%y%m%d)

# Backup MT5 settings
Export EA settings → Save as .set file
```

### Recovery:
```bash
# Restore code
cp -r FlashEASuite_V2_BACKUP_XXXXXX FlashEASuite_V2

# Restore settings
Import .set file in EA properties
```

---

## 📞 Support

### Getting Help:
```
1. Check TROUBLESHOOTING.md
2. Review logs in 02_Brain/logs/
3. Check MT5 Journal and Experts tabs
4. Verify all components running
```

### Reporting Issues:
```
Include:
- Error messages
- MT5 logs
- Python logs
- Settings used
- Account type (demo/live)
```

---

## 📝 Version History

### V2.10 (December 25, 2025)
```
✅ Added Position Sizing Manager
✅ Added Daily Loss Limit
✅ Added real-time P&L tracking
✅ Enhanced risk management
✅ Updated documentation
```

### V2.03 (Previous)
```
- Basic risk management
- Grid + Spike strategies
- ZMQ communication
- Python Brain integration
```

**See:** `CHANGELOG.md` for complete history

---

## 🎯 Goals & Targets

### Short-term (1 month):
```
☐ Achieve 1% daily average
☐ Maintain <10% drawdown
☐ Optimize settings for account
☐ Build trading history
```

### Long-term (3-6 months):
```
☐ Scale to larger account
☐ Add more strategies
☐ Improve AI analysis
☐ Achieve consistent profitability
```

---

## ✅ Status

```
Version:    2.10 (Risk Enhanced)
Status:     ✅ Production Ready
Tested:     ✅ Yes (Strategy Tester + Manual)
Documented: ✅ Complete
Ready:      ✅ Deploy 26 Dec 2025
```

---

**Built by:** Dr. Suksaeng Kukanok (SKN)  
**Version:** 2.10  
**Date:** December 25, 2025  
**License:** Proprietary

**🚀 Ready to trade smarter, not harder!**
