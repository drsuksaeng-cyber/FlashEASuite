# 🔧 Troubleshooting Guide - FlashEASuite V2.10

**Complete Problem-Solution Reference**

---

## 🚨 Critical Issues

### Issue 1: Daily Loss Limit Not Initializing

**Symptoms:**
```
❌ Log doesn't show "Daily Loss Limit initialized"
❌ Trading continues past limit
❌ No daily summary on shutdown
```

**Causes:**
1. Missing DailyLossLimit.mqh file
2. Missing PositionSizingManager.mqh file
3. Incorrect include path
4. Compilation errors

**Solutions:**

**Step 1: Check Files Exist**
```
FlashEASuite_V2/Include/Risk/
├── DailyLossLimit.mqh        ← Must exist
└── PositionSizingManager.mqh ← Must exist
```

**Step 2: Check Includes in ProgramC_Trader.mq5**
```cpp
// These lines should exist near top:
#include "../Include/Risk/PositionSizingManager.mqh"
#include "../Include/Risk/DailyLossLimit.mqh"
```

**Step 3: Check OnInit() Code**
```cpp
int OnInit()
{
   // These lines must exist:
   g_position_sizer.Initialize();
   g_daily_limiter.Initialize(InpDailyLossLimit);
   
   // Check initialization logs
   return INIT_SUCCEEDED;
}
```

**Step 4: Recompile**
```
1. Open ProgramC_Trader.mq5
2. Press F7 (Compile)
3. Check for 0 errors
4. Restart EA
```

---

### Issue 2: Lot Size Always 0.01

**Symptoms:**
```
❌ All trades use 0.01 lot
❌ Risk-based sizing not working
❌ Log shows "Lot: 0.01 (FIXED)"
```

**Causes:**
1. InpUseRiskBasedLots = false
2. PositionSizingManager not initialized
3. CalculateLotSize() not being called
4. Strategy using hardcoded lots

**Solutions:**

**Step 1: Check Input Parameter**
```cpp
Input settings:
InpUseRiskBasedLots: true  ← Must be true!
```

**Step 2: Check Initialization**
```cpp
Look for log:
"✅ Position Sizing Manager initialized"
"   → Risk-Based Lots: ENABLED"

If not shown → Check OnInit()
```

**Step 3: Check Function Calls**
```cpp
// In strategy code, should call:
double lot = CalculateLotSize(entry, sl, InpRiskPerTrade);

// NOT hardcoded:
double lot = 0.01; ← Wrong!
```

**Step 4: Enable Debug Logging**
```cpp
Add to CalculateLotSize():
Print("DEBUG: Entry=", entry, " SL=", sl, " Risk=", risk_percent);
Print("DEBUG: Calculated lot=", calculated_lot);
```

---

### Issue 3: Compilation Errors

**Error: "function 'GetRiskBasedLotSize' must have a body"**

**Cause:**
StrategyManager.mqh has forward declaration but no implementation

**Solution:**
Use the fixed StrategyManager.mqh (removed forward declarations)

```
Download: StrategyManager.mqh (from outputs)
Copy to: Include/Logic/StrategyManager.mqh
Compile: F7
```

---

**Error: "no #import declaration"**

**Cause:**
MQL5 syntax difference (no #import in newer builds)

**Solution:**
Remove #import statements if any

---

**Error: "possible loss of data due to type conversion"**

**Cause:**
Normal warning, not error

**Solution:**
Ignore (7 warnings is normal)

---

### Issue 4: Trading Doesn't Stop at Daily Limit

**Symptoms:**
```
❌ Daily P&L shows -$500
❌ Daily limit is -$400
❌ Trading continues
```

**Causes:**
1. CanOpenNewTrade() not being called
2. Daily limiter not updating
3. Logic error in strategy

**Solutions:**

**Step 1: Check OnTick() Logic**
```cpp
void OnTick()
{
   // This MUST be at the very start:
   if(!CanOpenNewTrade())
   {
      static datetime last_warn = 0;
      if(TimeCurrent() - last_warn > 300)
      {
         Print("⚠️ Daily Loss Limit Reached - No new trades");
         last_warn = TimeCurrent();
      }
      return; ← MUST return here!
   }
   
   // Rest of trading logic...
}
```

**Step 2: Check UpdateDailyLimiter() Calls**
```cpp
// Should be called in OnTick():
UpdateDailyLimiter();

// Or after each trade closes
```

**Step 3: Manual Check**
```cpp
Add debug prints:
Print("Can trade: ", CanOpenNewTrade());
Print("Daily P&L: ", g_daily_limiter.GetDailyPnL());
Print("Limit: ", g_daily_limiter.GetMaxLoss());
```

---

## ⚠️ Common Issues

### Issue 5: Python Brain Not Receiving Ticks

**Symptoms:**
```
Python: "Ticks processed: 0"
FeederEA: Shows "Ticks sent"
```

**Causes:**
1. Wrong ZMQ port
2. Python not subscribed correctly
3. Firewall blocking

**Solutions:**

**Step 1: Check Ports**
```
FeederEA: tcp://127.0.0.1:7777 (PUB)
Python:   tcp://127.0.0.1:7777 (SUB)

Must match!
```

**Step 2: Check Python Subscription**
```python
# In ingestion.py:
zmq_sub.setsockopt(zmq.SUBSCRIBE, b"")  ← Must subscribe!
```

**Step 3: Test Connection**
```bash
# Terminal 1: Start Python
python main.py

# Terminal 2: Check if listening
netstat -an | findstr 7777
```

**Step 4: Firewall**
```
Add exception for ports 7777, 7778, 7779
Or disable firewall for localhost (testing only)
```

---

### Issue 6: No Trades Executing

**Symptoms:**
```
✅ Ticks received
✅ Policies generated
❌ No trades executed
```

**Causes:**
1. Risk Guardian blocking
2. Insufficient margin
3. Trading not allowed
4. Strategy not voting

**Solutions:**

**Step 1: Check Risk Guardian**
```cpp
Look for logs:
"❌ Order blocked by Risk Guardian"

If seen:
→ Check InpUserMaxRisk setting
→ Check account exposure
→ Check max orders limit
```

**Step 2: Check Account**
```
Free Margin: Must be > required
Account: Must allow trading
Connection: Must be active
```

**Step 3: Check Strategy Votes**
```
Look for:
">> COUNCIL VOTE BUY! Score: XX"

If not seen:
→ Strategies not generating signals
→ Check vote threshold
→ Check strategy weights
```

---

### Issue 7: Grid Orders Not Opening

**Symptoms:**
```
✅ First order opens
❌ No grid levels added
```

**Causes:**
1. Grid spacing too wide
2. ATR calculation issue
3. Max orders reached
4. Price not moving enough

**Solutions:**

**Step 1: Check Grid Settings**
```cpp
InpGridMaxOrders: 5 ← Check value
InpGridBaseStep: 200.0 ← Check spacing
```

**Step 2: Check ATR**
```cpp
Look for log:
"ATR: X.XX, Elastic Step: XXX points"

If ATR = 0:
→ Indicator not initialized
→ Not enough data
```

**Step 3: Reduce Spacing**
```
Try smaller InpGridBaseStep
Example: 200 → 150
```

---

### Issue 8: Huge Drawdown

**Symptoms:**
```
❌ Account down 20%+
❌ Multiple losing trades
```

**Immediate Actions:**

**Step 1: STOP TRADING**
```
1. Close EA immediately
2. Close all positions manually
3. Stop Python Brain
```

**Step 2: Analyze**
```
Check:
☐ What went wrong?
☐ Risk settings too high?
☐ Daily limit not working?
☐ Market conditions unusual?
```

**Step 3: Review Settings**
```
Reduce:
InpRiskPerTrade: 1.0% → 0.5%
InpDailyLossLimit: 4.0% → 2.0%
InpGridMaxOrders: 5 → 3
```

**Step 4: Test on Demo**
```
Never go back to live until:
✅ Settings tested on demo
✅ Risk limits verified
✅ Daily limit working
✅ Confident in system
```

---

## 🐛 System Errors

### Issue 9: "ZMQ connection failed"

**Cause:**
ZMQ not initialized or ports busy

**Solution:**
```cpp
1. Check ZMQ library installed
2. Check ports not in use by other apps
3. Restart MT5
4. Restart Python Brain
```

---

### Issue 10: "Memory allocation error"

**Cause:**
Too many objects or memory leak

**Solution:**
```cpp
1. Restart MT5
2. Check for memory leaks in code
3. Reduce number of active orders
4. Close other applications
```

---

### Issue 11: "Invalid lot size"

**Symptoms:**
```
"OrderSend error: Invalid volume"
```

**Causes:**
1. Lot too small (< broker minimum)
2. Lot too large (> broker maximum)
3. Lot not multiple of step

**Solutions:**

**Step 1: Check Broker Limits**
```cpp
double min_lot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double max_lot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
double lot_step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

Print("Min: ", min_lot);  // Usually 0.01
Print("Max: ", max_lot);  // Varies
Print("Step: ", lot_step); // Usually 0.01
```

**Step 2: Fix Lot Calculation**
```cpp
// Add to CalculateLotSize():
double min_lot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double max_lot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
double lot_step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

if(lot < min_lot) lot = min_lot;
if(lot > max_lot) lot = max_lot;

lot = MathFloor(lot / lot_step) * lot_step;
```

---

## 📊 Performance Issues

### Issue 12: Low Win Rate (<40%)

**Possible Causes:**
1. Market conditions unfavorable
2. Settings too aggressive
3. Strategies not suited for symbol
4. Stop loss too tight

**Solutions:**

**Analyze Trades:**
```
Check:
☐ What's the average loss?
☐ What's the average win?
☐ Are stops being hit too early?
☐ Is profit target too far?
```

**Adjust Settings:**
```
Try:
- Wider grid spacing
- Smaller lot multiplier
- Different symbols
- Different timeframes
```

---

### Issue 13: Too Many Trades

**Symptoms:**
```
Trades: 50+ per day
Commission eating profits
```

**Solutions:**

**Reduce Trade Frequency:**
```
Increase:
InpGridBaseStep: 200 → 300
Vote threshold: 40 → 60

Decrease:
Number of strategies active
```

---

### Issue 14: Too Few Trades

**Symptoms:**
```
Trades: <5 per day
Missing opportunities
```

**Solutions:**

**Increase Trade Frequency:**
```
Decrease:
InpGridBaseStep: 200 → 150
Vote threshold: 40 → 30

Add:
More strategies
More symbols
```

---

## 🔍 Debugging Tools

### Enable Verbose Logging

**In ProgramC_Trader.mq5:**
```cpp
#define DEBUG_MODE  // Add at top

// Then use:
#ifdef DEBUG_MODE
   Print("DEBUG: Variable = ", value);
#endif
```

### Check System Status

**Run Diagnostic:**
```cpp
void PrintDiagnostics()
{
   Print("=== SYSTEM DIAGNOSTIC ===");
   Print("Position Sizer Initialized: ", 
         CheckPointer(g_position_sizer) != POINTER_INVALID);
   Print("Daily Limiter Initialized: ", 
         CheckPointer(g_daily_limiter) != POINTER_INVALID);
   Print("Can Trade: ", CanOpenNewTrade());
   Print("Daily P&L: ", g_daily_limiter.GetDailyPnL());
   Print("Risk Per Trade: ", InpRiskPerTrade, "%");
   Print("Daily Limit: ", InpDailyLossLimit, "%");
   Print("========================");
}

// Call in OnInit() and periodically
```

### Monitor Performance

**Track Key Metrics:**
```cpp
void PrintPerformance()
{
   Print("=== PERFORMANCE ===");
   Print("Total Trades: ", g_daily_limiter.GetTotalTrades());
   Print("Wins: ", g_daily_limiter.GetWinCount());
   Print("Losses: ", g_daily_limiter.GetLossCount());
   Print("Win Rate: ", g_daily_limiter.GetWinRate(), "%");
   Print("Daily P&L: $", g_daily_limiter.GetDailyPnL());
   Print("==================");
}
```

---

## 📞 Getting Help

### Information to Collect:

```
Before asking for help, collect:

☐ MT5 version and build number
☐ Account type (demo/live)
☐ Account balance
☐ Symbol trading
☐ All input settings
☐ Complete error messages
☐ MT5 Journal log
☐ MT5 Experts log
☐ Python Brain log (if applicable)
☐ Steps to reproduce issue
☐ When issue started
☐ Recent changes made
```

### Where to Look:

**MT5 Logs:**
```
1. Journal tab (bottom of MT5)
2. Experts tab (bottom of MT5)
3. Right-click → Copy all
```

**Python Logs:**
```
02_Brain/logs/
├── ingestion.log
├── strategy.log
├── execution.log
└── main.log
```

---

## ✅ Prevention Checklist

**Before Each Session:**
```
☐ Backup settings (.set file)
☐ Check account balance
☐ Verify risk limits appropriate
☐ Check market conditions
☐ Start on demo first
☐ Monitor first 30 minutes
```

**Weekly:**
```
☐ Review performance
☐ Check for errors in logs
☐ Verify settings still appropriate
☐ Backup code and data
```

**Monthly:**
```
☐ Full system audit
☐ Optimize settings
☐ Review and update documentation
☐ Test new strategies on demo
```

---

## 🚨 Emergency Procedures

### If System Goes Crazy:

**Immediate Actions:**
```
1. Close EA (remove from chart)
2. Stop Python Brain (Ctrl+C)
3. Close all positions manually
4. Analyze logs
5. Find root cause
6. Fix before restarting
```

### If Account Blown:

**Post-Mortem:**
```
1. STOP everything
2. Analyze what happened
3. Review ALL logs
4. Identify failures:
   - Settings too aggressive?
   - Risk limits not working?
   - Strategy flawed?
   - Market conditions unusual?
5. Start fresh on DEMO
6. Never repeat mistakes
```

---

**Remember:** 
- Start small
- Test thoroughly
- Monitor constantly
- Respect risk limits
- Learn from mistakes

**Date:** December 25, 2025  
**Version:** 2.10  
**For:** FlashEASuite Risk Enhanced
