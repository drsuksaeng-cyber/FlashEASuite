# 🎯 Pre-Deployment Checklist & Configuration Guide

**SKN FlashEASuite V2.10 - Risk Enhanced**  
**Date:** December 25, 2025  
**Status:** Production Ready

---

## ✅ PRE-DEPLOYMENT CHECKLIST

### 1️⃣ Code Backup
```
☐ Backup entire FlashEASuite_V2 folder
☐ Save to: FlashEASuite_V2_BACKUP_251225
☐ Verify backup can be restored
☐ Save current MT5 settings
```

### 2️⃣ File Installation Verification
```
☐ ProgramC_Trader.mq5 (v2.10) installed
   Location: 03_Trader/ProgramC_Trader.mq5
   Header: "SKN V 2.10 - Risk Enhanced 251225 13:30"
   
☐ StrategyManager.mqh (fixed) installed
   Location: Include/Logic/StrategyManager.mqh
   Header: "SKN V 2.10 - Manager 251225 13:45"
   
☐ Risk Management modules present:
   ✅ Include/Risk/PositionSizingManager.mqh
   ✅ Include/Risk/DailyLossLimit.mqh
   
☐ All files compiled successfully:
   ✅ 0 errors
   ✅ 7 warnings (normal)
```

### 3️⃣ Account Preparation
```
☐ Demo account ready for testing
   Account Number: ______________
   Balance: $10,000 (recommended minimum)
   Leverage: 1:100 (recommended)
   
☐ Live account (after testing):
   Account Number: ______________
   Balance: $________
   Leverage: 1:____
```

### 4️⃣ System Components
```
☐ Python Brain (02_Brain/main.py)
   ✅ Python 3.8+ installed
   ✅ Dependencies installed (requirements.txt)
   ✅ ZMQ working
   
☐ FeederEA (01_Feeder/FeederEA.mq5)
   ✅ Compiled successfully
   ✅ Ready to attach to chart
   
☐ Trader (03_Trader/ProgramC_Trader.mq5)
   ✅ v2.10 compiled
   ✅ Risk Management integrated
   ✅ Ready to attach to chart
```

---

## ⚙️ RECOMMENDED CONFIGURATION

### 🟢 Conservative Settings (Low Risk)

**For:** Beginners, small accounts, risk-averse traders

```cpp
=== Advanced Risk Management ===
InpUseRiskBasedLots:  true
InpRiskPerTrade:      0.5%      // Small positions
InpDailyLossLimit:    2.0%      // Stop early

=== Trading Configuration ===
InpUserMaxRisk:       1.0%      // Very conservative

=== Grid Strategy ===
InpGridMaxOrders:     3         // Fewer orders
InpGridBaseStep:      300.0     // Wider spacing
InpGridLotMult:       1.3       // Gentle scaling
InpGridBaseLot:       0.01      // Minimum lot
```

**Expected Performance:**
- Daily Trades: 5-10
- Win Rate: 50-60%
- Max Drawdown: <5%
- Daily Target: 0.3-0.5%

---

### 🟡 Moderate Settings (Balanced) ⭐ RECOMMENDED

**For:** Most traders, balanced risk/reward

```cpp
=== Advanced Risk Management ===
InpUseRiskBasedLots:  true
InpRiskPerTrade:      1.0%      // Standard positions
InpDailyLossLimit:    4.0%      // Reasonable limit

=== Trading Configuration ===
InpUserMaxRisk:       2.0%      // Balanced

=== Grid Strategy ===
InpGridMaxOrders:     5         // Standard grid
InpGridBaseStep:      200.0     // Normal spacing
InpGridLotMult:       1.5       // Standard scaling
InpGridBaseLot:       0.01      // Starting lot
```

**Expected Performance:**
- Daily Trades: 10-20
- Win Rate: 45-55%
- Max Drawdown: <10%
- Daily Target: 0.5-1.0%

---

### 🔴 Aggressive Settings (High Risk)

**For:** Experienced traders, larger accounts, higher risk tolerance

```cpp
=== Advanced Risk Management ===
InpUseRiskBasedLots:  true
InpRiskPerTrade:      2.0%      // Large positions
InpDailyLossLimit:    8.0%      // Higher tolerance

=== Trading Configuration ===
InpUserMaxRisk:       3.0%      // Aggressive

=== Grid Strategy ===
InpGridMaxOrders:     7         // More orders
InpGridBaseStep:      150.0     // Tighter spacing
InpGridLotMult:       2.0       // Aggressive scaling
InpGridBaseLot:       0.01      // Starting lot
```

**Expected Performance:**
- Daily Trades: 20-40
- Win Rate: 40-50%
- Max Drawdown: <20%
- Daily Target: 1.0-2.0%

**⚠️ Warning:** Higher returns = higher risk!

---

## 🎮 ACCOUNT SIZE SPECIFIC SETTINGS

### Micro Account ($500 - $1,000)
```
Balance: $500
InpRiskPerTrade: 0.5%
InpDailyLossLimit: 2.0%
InpGridBaseLot: 0.01
Max Risk: $10/day
```

### Mini Account ($1,000 - $5,000)
```
Balance: $2,500
InpRiskPerTrade: 0.75%
InpDailyLossLimit: 3.0%
InpGridBaseLot: 0.01
Max Risk: $75/day
```

### Standard Account ($5,000 - $10,000)
```
Balance: $10,000
InpRiskPerTrade: 1.0%
InpDailyLossLimit: 4.0%
InpGridBaseLot: 0.01
Max Risk: $400/day
```

### Large Account ($10,000+)
```
Balance: $50,000
InpRiskPerTrade: 1.0%
InpDailyLossLimit: 5.0%
InpGridBaseLot: 0.01
Max Risk: $2,500/day
```

---

## 📊 MONITORING CHECKLIST

### Daily Checks:
```
☐ Check Daily P&L
☐ Verify daily limit not reached
☐ Check win rate
☐ Monitor position sizes
☐ Review trade history
☐ Check Python Brain logs
☐ Verify ZMQ connections
```

### Weekly Checks:
```
☐ Review weekly performance
☐ Analyze win/loss patterns
☐ Check equity curve
☐ Optimize settings if needed
☐ Backup system data
☐ Review Python Brain performance
```

### Monthly Checks:
```
☐ Calculate monthly ROI
☐ Compare to goals
☐ Full system audit
☐ Update documentation
☐ Optimize strategies
```

---

## 🚨 EMERGENCY PROCEDURES

### If Daily Limit Reached:
```
1. System will stop automatically
2. Review trades that caused limit
3. Analyze what went wrong
4. Adjust settings if needed
5. Resume next trading day
```

### If Multiple Losses:
```
1. Check Python Brain analysis
2. Review market conditions
3. Consider reducing risk
4. Verify strategy signals
5. May need to pause trading
```

### If System Error:
```
1. Check logs immediately
2. Verify all connections (ZMQ)
3. Restart Python Brain if needed
4. Check MT5 terminal
5. Contact support if persistent
```

---

## 🎯 FIRST DAY DEPLOYMENT PLAN

### Morning (Before Market Open):
```
Time: 1 hour before market open

☐ Start Python Brain
   cd 02_Brain
   python main.py
   → Verify: All 4 workers started

☐ Attach FeederEA
   Symbol: XAUUSD (or your choice)
   Timeframe: M1
   → Verify: "Feeder Ready" in logs

☐ Attach ProgramC_Trader v2.10
   Symbol: XAUUSD (same as FeederEA)
   Timeframe: M1
   Settings: Conservative (first day)
   → Verify initialization logs
```

### Market Open:
```
☐ Monitor first 30 minutes closely
☐ Check if ticks are received
☐ Check if policies are generated
☐ Watch for first trade
☐ Verify lot size is calculated correctly
```

### End of Day:
```
☐ Review daily summary
☐ Check Daily P&L
☐ Note win rate
☐ Review logs for errors
☐ Save performance data
```

---

## 📝 SETTINGS TEMPLATE

**Copy this to your notes:**

```
=== MY SETTINGS (Date: __________) ===

Account Balance: $_________
Risk Profile: [Conservative / Moderate / Aggressive]

InpRiskPerTrade:      ____%
InpDailyLossLimit:    ____%
InpUseRiskBasedLots:  [true / false]
InpUserMaxRisk:       ____%

InpGridMaxOrders:     ____
InpGridBaseStep:      ____ points
InpGridLotMult:       ____
InpGridBaseLot:       ____

Expected Daily Trades: ____
Expected Win Rate: ____%
Max Daily Risk: $_____

Notes:
_________________________________
_________________________________
```

---

## ✅ FINAL PRE-LAUNCH CHECKLIST

```
☐ All files installed and compiled
☐ Settings configured for account size
☐ Backup completed
☐ Demo account ready
☐ Python Brain tested
☐ FeederEA tested
☐ ZMQ connections verified
☐ Risk limits set appropriately
☐ Monitoring plan ready
☐ Emergency procedures understood
☐ First day plan prepared
```

---

**When all checkboxes are ✅, you're ready to deploy!**

**Date Prepared:** _____________  
**Ready to Deploy:** [ ] Yes [ ] No  
**Target Launch Date:** December 26, 2025
