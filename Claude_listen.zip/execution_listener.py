"""
FlashEASuite V2 - Program B (The Brain)
Execution Listener - Trade Result Receiver

รับข้อมูล Trade Results จาก MT5 Trader (Program C) ผ่าน ZMQ PULL
แล้วส่งต่อไปยัง Strategy Engine ผ่าน feedback_queue

Author: Dr. Suksaeng Kukanok
Version: 2.0.0
"""

import multiprocessing as mp
import zmq
import msgpack
import time
import logging
from datetime import datetime
from typing import Dict, Any, Optional


class ExecutionListener(mp.Process):
    """
    Execution Listener Process
    
    รับข้อมูล Trade Results จาก MT5 via ZMQ PULL socket (Port 7779)
    และส่งต่อไปยัง Strategy Engine ผ่าน feedback_queue
    
    Message Format (MessagePack Array):
    [0]  msg_type      : int (100 = TRADE_RESULT)
    [1]  timestamp     : int (milliseconds)
    [2]  ticket        : int (position ticket)
    [3]  symbol        : str (e.g., "XAUUSD")
    [4]  type          : int (0=BUY, 1=SELL)
    [5]  volume        : float (lot size)
    [6]  open_price    : float
    [7]  sl            : float (stop loss)
    [8]  tp            : float (take profit)
    [9]  profit        : float (current profit/loss)
    [10] magic         : int (magic number)
    [11] comment       : str (order comment)
    """
    
    def __init__(
        self,
        feedback_queue: mp.Queue,
        shutdown_event: mp.Event,
        zmq_address: str = "tcp://127.0.0.1:7779",
        name: str = "ExecutionListener"
    ):
        """
        Initialize Execution Listener.
        
        Args:
            feedback_queue: Queue to send parsed trade results to Strategy Engine
            shutdown_event: Event to signal shutdown
            zmq_address: ZMQ PULL socket address
            name: Process name
        """
        super().__init__(name=name)
        self.feedback_queue = feedback_queue
        self.shutdown_event = shutdown_event
        self.zmq_address = zmq_address
        
        # Logging
        self.logger = logging.getLogger(f"ExecutionListener.{name}")
        
        # ZMQ components (initialized in run())
        self.context: Optional[zmq.Context] = None
        self.pull_socket: Optional[zmq.Socket] = None
        
        # Statistics
        self.message_count = 0
        self.error_count = 0
        self.last_message_time = 0
    
    def _setup_zmq(self) -> bool:
        """
        Setup ZMQ PULL socket.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.context = zmq.Context()
            self.pull_socket = self.context.socket(zmq.PULL)
            
            # Bind to address
            self.pull_socket.bind(self.zmq_address)
            
            # Set timeout (1 second) for non-blocking receive
            self.pull_socket.setsockopt(zmq.RCVTIMEO, 1000)
            
            self.logger.info(f"✅ ZMQ PULL socket bound to {self.zmq_address}")
            print(f"📥 EXECUTION LISTENER: Ready to receive trade results on {self.zmq_address}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Failed to setup ZMQ: {e}", exc_info=True)
            return False
    
    def _parse_trade_result(self, raw_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Parse trade result from MessagePack binary data.
        
        Args:
            raw_data: Raw MessagePack binary data
            
        Returns:
            Parsed trade result dictionary or None if invalid
        """
        try:
            # Unpack MessagePack
            data = msgpack.unpackb(raw_data, raw=False)
            
            # Validate format
            if not isinstance(data, (list, tuple)) or len(data) < 12:
                self.logger.warning(f"⚠️ Invalid data format (length={len(data)})")
                return None
            
            # Parse fields
            msg_type = int(data[0])
            timestamp_ms = int(data[1])
            ticket = int(data[2])
            symbol = str(data[3])
            trade_type = int(data[4])
            volume = float(data[5])
            open_price = float(data[6])
            sl = float(data[7])
            tp = float(data[8])
            profit = float(data[9])
            magic = int(data[10])
            comment = str(data[11])
            
            # Convert timestamp to datetime
            dt = datetime.fromtimestamp(timestamp_ms / 1000.0)
            
            # Create result dictionary
            result = {
                'msg_type': msg_type,
                'timestamp': timestamp_ms,
                'timestamp_dt': dt,
                'ticket': ticket,
                'symbol': symbol,
                'type': 'BUY' if trade_type == 0 else 'SELL',
                'type_code': trade_type,
                'volume': volume,
                'open_price': open_price,
                'sl': sl,
                'tp': tp,
                'profit': profit,
                'magic': magic,
                'comment': comment,
                'is_win': profit > 0,
                'is_loss': profit < 0,
            }
            
            return result
            
        except Exception as e:
            self.logger.error(f"❌ Error parsing trade result: {e}", exc_info=True)
            return None
    
    def _log_trade_result(self, result: Dict[str, Any]) -> None:
        """
        Log trade result to console.
        
        Args:
            result: Parsed trade result dictionary
        """
        try:
            # Determine emoji based on profit
            if result['is_win']:
                status_emoji = "💚"
                status_text = "WIN"
            elif result['is_loss']:
                status_emoji = "💔"
                status_text = "LOSS"
            else:
                status_emoji = "⚪"
                status_text = "BREAKEVEN"
            
            print(f"\n{'='*70}")
            print(f"{status_emoji} [Message #{self.message_count}] TRADE RESULT: {status_text}")
            print(f"{'='*70}")
            print(f"   🕐 Time:       {result['timestamp_dt'].strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
            print(f"   🎫 Ticket:     {result['ticket']}")
            print(f"   📊 Symbol:     {result['symbol']}")
            print(f"   📈 Type:       {result['type']}")
            print(f"   📦 Volume:     {result['volume']}")
            print(f"   💰 Entry:      {result['open_price']}")
            print(f"   🛑 SL:         {result['sl']}")
            print(f"   🎯 TP:         {result['tp']}")
            print(f"   💵 Profit:     {result['profit']:.2f} {status_text}")
            print(f"   🔮 Magic:      {result['magic']}")
            print(f"   💬 Comment:    {result['comment']}")
            print(f"{'='*70}\n")
            
        except Exception as e:
            self.logger.error(f"Error logging trade result: {e}")
    
    def _shutdown_zmq(self) -> None:
        """Cleanup ZMQ resources."""
        try:
            if self.pull_socket:
                self.pull_socket.close()
                self.logger.info("ZMQ PULL socket closed")
            
            if self.context:
                self.context.term()
                self.logger.info("ZMQ context terminated")
                
        except Exception as e:
            self.logger.error(f"Error during ZMQ cleanup: {e}")
    
    def run(self) -> None:
        """
        Main execution loop.
        
        Continuously receives trade results from MT5 and forwards to feedback_queue.
        """
        self.logger.info(f"🚀 Starting Execution Listener on {self.zmq_address}")
        
        # Setup ZMQ
        if not self._setup_zmq():
            self.logger.error("❌ Failed to setup ZMQ, exiting")
            return
        
        try:
            while not self.shutdown_event.is_set():
                try:
                    # Receive data (with timeout)
                    raw_data = self.pull_socket.recv()
                    
                    self.message_count += 1
                    self.last_message_time = time.time()
                    
                    # Parse trade result
                    result = self._parse_trade_result(raw_data)
                    
                    if result:
                        # Log to console
                        self._log_trade_result(result)
                        
                        # Send to feedback queue (non-blocking)
                        try:
                            self.feedback_queue.put_nowait(result)
                            self.logger.info(
                                f"📤 Trade result forwarded to Strategy Engine "
                                f"(Ticket: {result['ticket']}, Profit: {result['profit']:.2f})"
                            )
                        except mp.queues.Full:
                            self.logger.warning("⚠️ Feedback queue is full! Dropping message.")
                            self.error_count += 1
                    else:
                        self.error_count += 1
                    
                except zmq.Again:
                    # Timeout - no data received
                    # Print heartbeat dot every 5 seconds
                    current_time = time.time()
                    if self.last_message_time == 0 or current_time - self.last_message_time > 5:
                        print(".", end="", flush=True)
                    continue
                    
                except Exception as e:
                    self.logger.error(f"❌ Error in receive loop: {e}", exc_info=True)
                    self.error_count += 1
                    time.sleep(1)  # Brief pause on error
                    
        except KeyboardInterrupt:
            self.logger.info("⚠️ Interrupted by user")
            
        finally:
            # Cleanup
            self._shutdown_zmq()
            
            # Log statistics
            self.logger.info(f"📊 Execution Listener Statistics:")
            self.logger.info(f"   Messages received: {self.message_count}")
            self.logger.info(f"   Errors: {self.error_count}")
            self.logger.info("✅ Execution Listener shutdown complete")


def create_execution_listener(
    feedback_queue: mp.Queue,
    shutdown_event: mp.Event,
    zmq_address: str = "tcp://127.0.0.1:7779"
) -> ExecutionListener:
    """
    Factory function to create ExecutionListener process.
    
    Args:
        feedback_queue: Queue to send trade results
        shutdown_event: Event to signal shutdown
        zmq_address: ZMQ PULL socket address
        
    Returns:
        ExecutionListener instance
    """
    return ExecutionListener(
        feedback_queue=feedback_queue,
        shutdown_event=shutdown_event,
        zmq_address=zmq_address
    )
