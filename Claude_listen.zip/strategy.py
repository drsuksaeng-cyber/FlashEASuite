"""
FlashEASuite V2 - Program B (The Brain)
Strategy Engine - WITH FEEDBACK LOOP 🔄

Version: 2.1.0 - Integrated Trade Result Feedback
"""

import multiprocessing as mp
import zmq
import msgpack
import time
import logging
import config
from collections import deque
from typing import Dict, Any, Optional
from modules.tick_analyzer import TickFlowAnalyzer
from modules.currency_meter import CurrencyStrengthMeter


class StrategyEngine(mp.Process):
    """
    Strategy Engine with Feedback Loop Integration.
    
    Receives:
    - Tick data from ingestion_queue
    - Trade results from feedback_queue ⭐ NEW!
    
    Outputs:
    - Trading policies to MT5 via ZMQ PUB
    """
    
    def __init__(
        self,
        input_queue: mp.Queue,
        output_queue: mp.Queue,
        feedback_queue: mp.Queue,  # ⭐ NEW: Feedback from Execution Listener
        shutdown_event: mp.Event,
        name: str = "StrategyEngine"
    ):
        super().__init__(name=name)
        self.input_queue = input_queue
        self.output_queue = output_queue
        self.feedback_queue = feedback_queue  # ⭐ NEW!
        self.shutdown_event = shutdown_event
        self.logger = logging.getLogger(f"StrategyEngine.{name}")
        self.logger.setLevel(getattr(logging, config.LOG_LEVEL))
        
        self.context = None
        self.pub_socket = None
        
        # --- Memory & Analyzer ---
        self.tick_history = {} 
        self.tick_analyzer = TickFlowAnalyzer(window_short_sec=1.0, window_long_sec=900.0)
        self.csm = CurrencyStrengthMeter() 
        
        # --- Strategy Parameters ---
        self.TIME_WINDOW = 2.0      
        self.VELOCITY_THRESHOLD = 0.5 
        self.TICK_RATIO_THRESHOLD = 5.0    
        self.SPREAD_DEVIATION_LIMIT = 5.0
        
        self.COOLDOWN = 5.0         
        self.last_trade_time = {}   
        self.last_heartbeat_time = 0
        self.last_csm_print_time = 0 
        self.HEARTBEAT_INTERVAL = 60
        
        # ⭐ NEW: Feedback Loop State
        self.consecutive_wins = 0
        self.consecutive_losses = 0
        self.total_trades = 0
        self.total_wins = 0
        self.total_losses = 0
        self.total_profit = 0.0
        self.cooldown_until = 0  # Timestamp when cooldown ends
        self.is_in_cooldown = False
        self.risk_multiplier = 1.0  # Dynamic risk adjustment
        
        # Cooldown configuration
        self.LOSS_COOLDOWN_SECONDS = 30.0  # 30 seconds cooldown after loss
        self.MAX_CONSECUTIVE_LOSSES = 3    # Enter emergency cooldown after 3 losses
        self.EMERGENCY_COOLDOWN_SECONDS = 300.0  # 5 minutes emergency cooldown

    def _setup_zmq(self):
        """ตั้งค่า ZMQ สำหรับส่งข้อมูลออก"""
        self.context = zmq.Context()
        self.pub_socket = self.context.socket(zmq.PUB)
        self.pub_socket.bind(config.ZMQ_EXECUTION_ADDRESS)
        print(f"🧠 STRATEGY: System Ready on {config.ZMQ_EXECUTION_ADDRESS}")

    def _process_feedback(self, feedback: Dict[str, Any]) -> None:
        """
        ⭐ NEW: Process trade result feedback and adapt strategy.
        
        Args:
            feedback: Trade result dictionary from ExecutionListener
        """
        try:
            ticket = feedback['ticket']
            symbol = feedback['symbol']
            profit = feedback['profit']
            is_win = feedback['is_win']
            is_loss = feedback['is_loss']
            
            # Update statistics
            self.total_trades += 1
            self.total_profit += profit
            
            current_time = time.time()
            
            if is_win:
                # ✅ WIN Logic
                self.total_wins += 1
                self.consecutive_wins += 1
                self.consecutive_losses = 0  # Reset loss streak
                
                # Increase confidence (reduce cooldown)
                if self.consecutive_wins >= 3:
                    self.risk_multiplier = min(1.5, self.risk_multiplier * 1.1)  # Max 1.5x
                    print(f"🔥 HOT STREAK! {self.consecutive_wins} consecutive wins!")
                    print(f"📈 Risk multiplier increased to {self.risk_multiplier:.2f}x")
                
                # Cancel cooldown if in cooldown
                if self.is_in_cooldown:
                    self.is_in_cooldown = False
                    self.cooldown_until = 0
                    print(f"✅ WIN! Cooldown cancelled.")
                
                print(f"💚 FEEDBACK: WIN | Ticket {ticket} | Profit: +{profit:.2f}")
                print(f"📊 Stats: {self.total_wins}W / {self.total_losses}L / {self.total_profit:.2f} Total")
                
            elif is_loss:
                # ❌ LOSS Logic
                self.total_losses += 1
                self.consecutive_losses += 1
                self.consecutive_wins = 0  # Reset win streak
                
                # Reduce risk after loss
                self.risk_multiplier = max(0.5, self.risk_multiplier * 0.9)  # Min 0.5x
                
                # Trigger cooldown
                if self.consecutive_losses >= self.MAX_CONSECUTIVE_LOSSES:
                    # Emergency cooldown
                    self.cooldown_until = current_time + self.EMERGENCY_COOLDOWN_SECONDS
                    self.is_in_cooldown = True
                    print(f"🚨 EMERGENCY COOLDOWN! {self.consecutive_losses} consecutive losses!")
                    print(f"🛑 Trading paused for {self.EMERGENCY_COOLDOWN_SECONDS:.0f} seconds")
                    print(f"📉 Risk multiplier reduced to {self.risk_multiplier:.2f}x")
                else:
                    # Normal cooldown
                    self.cooldown_until = current_time + self.LOSS_COOLDOWN_SECONDS
                    self.is_in_cooldown = True
                    print(f"⚠️ COOLDOWN ACTIVATED for {self.LOSS_COOLDOWN_SECONDS:.0f} seconds")
                
                print(f"💔 FEEDBACK: LOSS | Ticket {ticket} | Loss: {profit:.2f}")
                print(f"📊 Stats: {self.total_wins}W / {self.total_losses}L / {self.total_profit:.2f} Total")
            
            else:
                # Breakeven
                print(f"⚪ FEEDBACK: BREAKEVEN | Ticket {ticket}")
            
            # Log to file
            self.logger.info(
                f"FEEDBACK: {ticket} | {symbol} | "
                f"{'WIN' if is_win else 'LOSS' if is_loss else 'BE'} | "
                f"Profit: {profit:.2f} | "
                f"Streak: {self.consecutive_wins}W/{self.consecutive_losses}L | "
                f"Total: {self.total_wins}W/{self.total_losses}L"
            )
            
        except Exception as e:
            self.logger.error(f"❌ Error processing feedback: {e}", exc_info=True)
    
    def _check_cooldown(self) -> bool:
        """
        ⭐ NEW: Check if currently in cooldown period.
        
        Returns:
            True if in cooldown (should not trade), False otherwise
        """
        if not self.is_in_cooldown:
            return False
        
        current_time = time.time()
        
        if current_time >= self.cooldown_until:
            # Cooldown expired
            self.is_in_cooldown = False
            self.cooldown_until = 0
            print(f"✅ COOLDOWN ENDED - Trading resumed")
            self.logger.info("Cooldown period ended")
            return False
        else:
            # Still in cooldown
            remaining = self.cooldown_until - current_time
            if int(remaining) % 10 == 0:  # Print every 10 seconds
                print(f"⏳ COOLDOWN: {remaining:.0f}s remaining...")
            return True

    def _analyze_market(self, symbol, current_time, current_bid, current_ask):
        """วิเคราะห์กราฟหาจังหวะ Spike"""
        
        # ⭐ NEW: Check cooldown first
        if self._check_cooldown():
            return None  # Skip trading during cooldown
        
        metrics = self.tick_analyzer.on_tick(current_bid, current_ask)
        tick_ratio = metrics['tick_ratio']
        spread_ratio = metrics['spread_ratio']
        
        # Filter Spread
        if spread_ratio > self.SPREAD_DEVIATION_LIMIT:
            return None

        is_high_activity = tick_ratio > self.TICK_RATIO_THRESHOLD
        
        # Init History ถ้ายังไม่มี
        if symbol not in self.tick_history:
            self.tick_history[symbol] = deque()
            self.last_trade_time[symbol] = 0
            
        history = self.tick_history[symbol]
        history.append((current_time, current_bid, current_ask))
        
        # Clean old history
        while history and history[0][0] < current_time - self.TIME_WINDOW:
            history.popleft()
            
        if len(history) < 2: return None
        
        # Calculate Velocity
        old_time, old_bid, old_ask = history[0]
        price_change_bid = current_bid - old_bid
        
        action = "HOLD"
        
        # ⭐ MODIFIED: Apply dynamic cooldown based on risk
        adjusted_cooldown = self.COOLDOWN / self.risk_multiplier
        if current_time - self.last_trade_time[symbol] < adjusted_cooldown:
            return None

        # --- Decision Logic ---
        if price_change_bid > self.VELOCITY_THRESHOLD and is_high_activity:
            action = "SELL"
        elif price_change_bid < -self.VELOCITY_THRESHOLD and is_high_activity:
            action = "BUY"
            
        if action != "HOLD":
            self.last_trade_time[symbol] = current_time
            return action
            
        return None

    def _get_csm_confirmation(self, symbol, action):
        """ขอคำยืนยันจาก CSM"""
        base = symbol[:3]
        quote = symbol[3:]
        score_base = self.csm.scores_fast.get(base, 5.0) 
        score_quote = self.csm.scores_fast.get(quote, 5.0)
        confidence = 0.5
        
        if action == "BUY":
            if score_base > score_quote: confidence = 0.99 
            elif score_base < score_quote: confidence = 0.20
        elif action == "SELL":
            if score_base < score_quote: confidence = 0.99 
            elif score_base > score_quote: confidence = 0.20
        
        # ⭐ NEW: Adjust confidence based on feedback
        confidence *= self.risk_multiplier
        
        return confidence, score_base, score_quote

    def run(self):
        """ลูปหลักของการทำงาน"""
        self._setup_zmq()
        print(f"🧠 LOGIC: Starting Engine with FEEDBACK LOOP... Waiting for Data...")
        
        while not self.shutdown_event.is_set():
            try:
                current_time = time.time()
                
                # --- 1. รับข้อมูล Tick (Non-blocking) ---
                try:
                    tick_data = self.input_queue.get(timeout=0.1)
                except mp.queues.Empty:
                    tick_data = None
                
                # ⭐ NEW: 1.5 รับข้อมูล Feedback (Non-blocking) ---
                try:
                    feedback = self.feedback_queue.get_nowait()
                    self._process_feedback(feedback)
                except mp.queues.Empty:
                    feedback = None

                # --- 2. อัปเดตข้อมูล ---
                if tick_data:
                    symbol = tick_data.get('symbol')
                    bid = float(tick_data.get('bid', 0))
                    ask = float(tick_data.get('ask', 0))
                    timestamp_ms = int(current_time * 1000)
                    
                    # 2.1 ป้อนข้อมูลให้ CSM
                    mid_price = (bid + ask) / 2.0
                    self.csm.update_tick(symbol, mid_price, timestamp_ms)
                    self.csm.calculate_strengths()
                    
                    # 2.2 วิเคราะห์ Spike (ตรวจสอบ cooldown ข้างใน)
                    signal = self._analyze_market(symbol, current_time, bid, ask)
                    
                    # 2.3 ถ้ามีสัญญาณ -> ส่ง Order
                    if signal:
                        confidence, s_base, s_quote = self._get_csm_confirmation(symbol, signal)
                        
                        policy = {
                            "type": "POLICY",
                            "symbol": symbol,
                            "action": 1 if signal == "BUY" else 2,
                            "confidence": confidence,
                            "entry_price": ask if signal == "BUY" else bid,
                            "timestamp": timestamp_ms,
                            "model_version": "DYN_V6_FEEDBACK",  # ⭐ Updated version
                            "debug_info": f"CSM[{symbol[:3]}:{s_base:.1f}/{symbol[3:]}:{s_quote:.1f}] Risk:{self.risk_multiplier:.2f}x"  # ⭐ Show risk
                        }
                        self.pub_socket.send(msgpack.packb(policy))
                        print(f"🚀 ACTION: {signal} {symbol} | Conf: {confidence*100:.0f}% | {policy['debug_info']}")

                # --- 3. รายงานตัวทุก 5 วินาที ---
                if current_time - self.last_csm_print_time > 5.0:
                    try:
                        # Dashboard
                        debug_str = self.csm.get_dashboard_string()
                        
                        # ⭐ NEW: Add feedback stats to dashboard
                        stats_str = (
                            f"📊 FEEDBACK: {self.total_wins}W/{self.total_losses}L "
                            f"({self.total_trades} trades) | "
                            f"Profit: {self.total_profit:+.2f} | "
                            f"Risk: {self.risk_multiplier:.2f}x"
                        )
                        
                        if self.is_in_cooldown:
                            remaining = self.cooldown_until - current_time
                            stats_str += f" | ⏳ COOLDOWN: {remaining:.0f}s"
                        
                        print(f"\n{'='*15} HYBRID CSM DASHBOARD {'='*15}")
                        print(f"{debug_str}")
                        print(f"{stats_str}")  # ⭐ NEW!
                        print(f"{'='*55}\n")
                        
                        # ส่งไปบอก MT5
                        debug_msg = {
                            "type": "POLICY",       
                            "symbol": "CSM_MONITOR", 
                            "action": 0,            
                            "confidence": 0.0,
                            "entry_price": 0.0,
                            "timestamp": int(current_time * 1000),
                            "model_version": "DEBUG_LINK_V6",
                            "debug_info": f"{debug_str}\n{stats_str}"  # ⭐ Include stats
                        }
                        self.pub_socket.send(msgpack.packb(debug_msg))
                        print(f"📡 ZMQ SENT: CSM Update sent to MT5")
                        
                        self.last_csm_print_time = current_time
                    except Exception as e:
                        print(f"⚠️ Dashboard Error: {e}")

                # --- 4. Heartbeat ---
                if current_time - self.last_heartbeat_time > self.HEARTBEAT_INTERVAL:
                    hb_msg = {
                        "type": "HEARTBEAT",
                        "timestamp": int(current_time * 1000),
                        "status": "OK",
                        "stats": {  # ⭐ NEW: Include stats in heartbeat
                            "trades": self.total_trades,
                            "wins": self.total_wins,
                            "losses": self.total_losses,
                            "profit": self.total_profit,
                            "risk_multiplier": self.risk_multiplier,
                            "in_cooldown": self.is_in_cooldown
                        }
                    }
                    self.pub_socket.send(msgpack.packb(hb_msg))
                    self.last_heartbeat_time = current_time

            except Exception as e:
                print(f"ERROR Strategy: {e}")
                self.logger.error(f"Error in strategy loop: {e}", exc_info=True)
                time.sleep(1)


def create_strategy_engine(
    input_queue,
    output_queue,
    feedback_queue,  # ⭐ NEW parameter
    shutdown_event
):
    """
    Factory function with feedback_queue support.
    """
    return StrategyEngine(
        input_queue,
        output_queue,
        feedback_queue,  # ⭐ NEW
        shutdown_event
    )
