#!/usr/bin/env python3
"""
FlashEASuite V2 - Program B Test Script
Tests the infrastructure without requiring MQL5 Feeder connection
"""

import zmq
import msgpack
import time
import random
from datetime import datetime


def simulate_feeder():
    """
    Simulate MQL5 Feeder by publishing test tick data.
    Run this in a separate terminal before running main.py
    """
    print("=" * 80)
    print("FlashEA Test Feeder Simulator")
    print("=" * 80)
    
    # Setup ZMQ publisher
    context = zmq.Context()
    socket = context.socket(zmq.PUB)
    socket.bind("tcp://*:7777")
    
    print("ZMQ Publisher bound to tcp://*:7777")
    print("Waiting 2 seconds for subscribers to connect...")
    time.sleep(2)  # Allow time for subscribers to connect
    
    symbols = ["EURUSD", "GBPUSD", "USDJPY"]
    spread_zones = ["NORMAL", "HIGH", "EXTREME"]
    
    print("Starting to publish test tick data...")
    print("Press Ctrl+C to stop")
    print("-" * 80)
    
    msg_count = 0
    
    try:
        while True:
            # Generate realistic tick data
            symbol = random.choice(symbols)
            
            # Base prices for each symbol
            base_prices = {
                "EURUSD": 1.0850,
                "GBPUSD": 1.2650,
                "USDJPY": 149.50
            }
            
            base_price = base_prices[symbol]
            variation = random.uniform(-0.0020, 0.0020)
            bid = base_price + variation
            
            # Spread in points
            spread = random.randint(1, 5)
            ask = bid + (spread * 0.00001)  # For 5-digit pricing
            
            # Create tick data
            tick_data = {
                'symbol': symbol,
                'bid': round(bid, 5),
                'ask': round(ask, 5),
                'spread': spread,
                'time': int(time.time()),
                'datetime': datetime.now().isoformat(),
                'spread_zone': random.choice(spread_zones),
                'volume': random.randint(1, 100)
            }
            
            # Encode with MessagePack
            packed_data = msgpack.packb(tick_data)
            
            # Publish
            socket.send(packed_data)
            
            msg_count += 1
            
            # Log every 100 messages
            if msg_count % 100 == 0:
                print(f"Published {msg_count} messages | "
                      f"Latest: {symbol} Bid={tick_data['bid']} Ask={tick_data['ask']}")
            
            # Simulate tick frequency (adjust as needed)
            # High frequency: 0.001 (1000 ticks/sec)
            # Medium frequency: 0.01 (100 ticks/sec)
            # Low frequency: 0.1 (10 ticks/sec)
            time.sleep(0.01)  # 100 ticks/sec
            
    except KeyboardInterrupt:
        print(f"\n\nStopping feeder... (Published {msg_count} total messages)")
    
    finally:
        socket.close()
        context.term()
        print("Feeder stopped cleanly")


if __name__ == "__main__":
    simulate_feeder()
