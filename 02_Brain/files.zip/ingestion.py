"""
FlashEASuite V2 - Program B (The Brain)
Data Ingestion Worker Module

Implements high-performance tick data ingestion from MQL5 Feeder
using ZMQ SUB socket and multiprocessing for parallel processing.
"""

import zmq
import msgpack
import multiprocessing as mp
import logging
import time
from typing import Dict, Any, Optional
from datetime import datetime

import config


class IngestionWorker(mp.Process):
    """
    Multiprocessing worker that subscribes to tick data from MQL5 Feeder.
    
    This worker runs in a separate process and continuously receives
    MessagePack-encoded tick data + spread zone information via ZMQ,
    decodes it, and pushes it into a queue for consumption by the
    Strategy Engine.
    
    Architecture:
    - Runs as independent process (multiprocessing.Process)
    - Non-blocking ZMQ operations with timeout
    - Automatic reconnection on disconnection
    - Graceful shutdown via Event
    """
    
    def __init__(
        self,
        output_queue: mp.Queue,
        shutdown_event: mp.Event,
        name: str = "IngestionWorker"
    ):
        """
        Initialize the Ingestion Worker.
        
        Args:
            output_queue: Multiprocessing queue to push decoded tick data
            shutdown_event: Event to signal graceful shutdown
            name: Process name for identification
        """
        super().__init__(name=name)
        self.output_queue = output_queue
        self.shutdown_event = shutdown_event
        
        # Performance tracking
        self.messages_received = 0
        self.messages_processed = 0
        self.errors_count = 0
        self.last_log_time = time.time()
        
        # ZMQ socket will be initialized in run() method
        # (must be done in the child process, not parent)
        self.context = None
        self.socket = None
        
        # Setup logging
        self.logger = logging.getLogger(f"IngestionWorker.{name}")
        self.logger.setLevel(getattr(logging, config.LOG_LEVEL))
    
    def _setup_zmq(self) -> None:
        """
        Setup ZMQ context and SUB socket with proper configuration.
        
        Must be called within the child process (in run() method).
        """
        try:
            self.logger.info("Setting up ZMQ connection...")
            
            # Create ZMQ context
            self.context = zmq.Context()
            
            # Create SUB socket
            self.socket = self.context.socket(zmq.SUB)
            
            # Configure socket options for high-performance
            self.socket.setsockopt(zmq.RCVHWM, config.ZMQ_SUB_HWM)
            self.socket.setsockopt(zmq.LINGER, config.ZMQ_LINGER_MS)
            self.socket.setsockopt(zmq.RCVTIMEO, config.ZMQ_RCVTIMEO_MS)
            
            # Reconnection settings for robustness
            self.socket.setsockopt(zmq.RECONNECT_IVL, config.ZMQ_RECONNECT_IVL_MS)
            self.socket.setsockopt(zmq.RECONNECT_IVL_MAX, config.ZMQ_RECONNECT_IVL_MAX_MS)
            
            # Subscribe to all messages (empty filter = subscribe to everything)
            self.socket.setsockopt_string(zmq.SUBSCRIBE, "")
            
            # Connect to MQL5 Feeder
            self.socket.connect(config.ZMQ_FEEDER_ADDRESS)
            
            self.logger.info(f"Connected to MQL5 Feeder at {config.ZMQ_FEEDER_ADDRESS}")
            self.logger.info(f"ZMQ SUB HWM: {config.ZMQ_SUB_HWM}, RCV Timeout: {config.ZMQ_RCVTIMEO_MS}ms")
            
        except Exception as e:
            self.logger.error(f"Failed to setup ZMQ: {e}")
            raise
    
    def _decode_message(self, raw_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Decode MessagePack binary data into Python dictionary.
        
        Args:
            raw_data: Raw MessagePack binary data
            
        Returns:
            Decoded dictionary or None if decoding fails
        """
        try:
            # Unpack MessagePack data
            data = msgpack.unpackb(raw_data, raw=False)
            
            # Validate essential fields
            if not isinstance(data, dict):
                self.logger.warning(f"Received non-dict data: {type(data)}")
                return None
            
            # Add reception timestamp
            data['recv_timestamp'] = time.time()
            data['recv_datetime'] = datetime.now().isoformat()
            
            return data
            
        except msgpack.exceptions.ExtraData as e:
            self.logger.error(f"MessagePack extra data error: {e}")
            self.errors_count += 1
            return None
            
        except msgpack.exceptions.UnpackException as e:
            self.logger.error(f"MessagePack unpack error: {e}")
            self.errors_count += 1
            return None
            
        except Exception as e:
            self.logger.error(f"Unexpected decoding error: {e}")
            self.errors_count += 1
            return None
    
    def _log_performance(self) -> None:
        """
        Log performance metrics periodically.
        """
        current_time = time.time()
        elapsed = current_time - self.last_log_time
        
        if elapsed >= config.PERFORMANCE_LOG_INTERVAL:
            msg_rate = self.messages_received / elapsed if elapsed > 0 else 0
            success_rate = (self.messages_processed / self.messages_received * 100) if self.messages_received > 0 else 0
            
            self.logger.info(
                f"Performance: {msg_rate:.2f} msg/s | "
                f"Processed: {self.messages_processed} | "
                f"Errors: {self.errors_count} | "
                f"Success Rate: {success_rate:.2f}% | "
                f"Queue Size: {self.output_queue.qsize()}"
            )
            
            # Reset counters
            self.messages_received = 0
            self.messages_processed = 0
            self.errors_count = 0
            self.last_log_time = current_time
    
    def run(self) -> None:
        """
        Main worker loop - runs in separate process.
        
        Continuously receives tick data from ZMQ, decodes it,
        and pushes to output queue until shutdown event is set.
        """
        self.logger.info(f"Starting {self.name} (PID: {mp.current_process().pid})")
        
        try:
            # Setup ZMQ in child process
            self._setup_zmq()
            
            # Main ingestion loop
            while not self.shutdown_event.is_set():
                try:
                    # Non-blocking receive with timeout
                    raw_data = self.socket.recv(flags=zmq.NOBLOCK)
                    self.messages_received += 1
                    
                    # Decode MessagePack data
                    decoded_data = self._decode_message(raw_data)
                    
                    if decoded_data is not None:
                        # Push to output queue (non-blocking with timeout)
                        try:
                            self.output_queue.put(decoded_data, block=True, timeout=0.1)
                            self.messages_processed += 1
                            
                        except mp.queues.Full:
                            self.logger.warning("Output queue full, dropping message")
                            self.errors_count += 1
                    
                except zmq.Again:
                    # No message available (timeout), continue
                    time.sleep(0.001)  # Small sleep to prevent CPU spinning
                    
                except zmq.ZMQError as e:
                    if e.errno == zmq.ETERM:
                        # Context terminated, graceful shutdown
                        self.logger.info("ZMQ context terminated")
                        break
                    else:
                        self.logger.error(f"ZMQ error: {e}")
                        self.errors_count += 1
                        time.sleep(1)  # Back off on error
                
                except Exception as e:
                    self.logger.error(f"Unexpected error in ingestion loop: {e}")
                    self.errors_count += 1
                    time.sleep(0.1)
                
                # Log performance periodically
                if config.ENABLE_PERFORMANCE_TRACKING:
                    self._log_performance()
            
            self.logger.info("Shutdown event received, stopping ingestion loop")
            
        except KeyboardInterrupt:
            self.logger.info("KeyboardInterrupt received in worker")
            
        except Exception as e:
            self.logger.error(f"Fatal error in worker: {e}", exc_info=True)
            
        finally:
            self._cleanup()
    
    def _cleanup(self) -> None:
        """
        Clean up ZMQ resources.
        """
        self.logger.info("Cleaning up ZMQ resources...")
        
        try:
            if self.socket:
                self.socket.close(linger=0)
                self.logger.info("ZMQ socket closed")
                
            if self.context:
                self.context.term()
                self.logger.info("ZMQ context terminated")
                
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")
        
        self.logger.info(f"{self.name} stopped cleanly")


def create_ingestion_worker(
    output_queue: mp.Queue,
    shutdown_event: mp.Event
) -> IngestionWorker:
    """
    Factory function to create an IngestionWorker instance.
    
    Args:
        output_queue: Queue to push decoded tick data
        shutdown_event: Event to signal shutdown
        
    Returns:
        Configured IngestionWorker instance
    """
    return IngestionWorker(
        output_queue=output_queue,
        shutdown_event=shutdown_event,
        name="IngestionWorker-1"
    )
