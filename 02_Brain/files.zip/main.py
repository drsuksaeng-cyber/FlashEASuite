#!/usr/bin/env python3
"""
FlashEASuite V2 - Program B (The Brain)
Main Entry Point

High-Frequency Hybrid Trading System - Python Server
Orchestrates multiprocessing workers for data ingestion and strategy execution.

Author: Dr. Suksaeng Kukanok
Version: 2.0.0
"""

import multiprocessing as mp
import signal
import sys
import logging
import time
from typing import List, Optional

import config
from core.ingestion import create_ingestion_worker
from core.strategy import create_strategy_engine


class FlashEABrain:
    """
    Main orchestrator for FlashEA Suite V2 Brain component.
    
    Manages multiprocessing workers:
    - Ingestion Worker: Receives tick data from MQL5 Feeder via ZMQ
    - Strategy Engine: Processes ticks and generates trading signals
    
    Handles graceful shutdown and resource cleanup.
    """
    
    def __init__(self):
        """Initialize the FlashEA Brain system."""
        self.logger = self._setup_logging()
        
        # Multiprocessing primitives
        self.shutdown_event = mp.Event()
        self.ingestion_queue = mp.Queue(maxsize=config.INGESTION_QUEUE_SIZE)
        self.signal_queue = mp.Queue(maxsize=config.SIGNAL_QUEUE_SIZE)
        
        # Worker processes
        self.workers: List[mp.Process] = []
        
        # Signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.logger.info("=" * 80)
        self.logger.info("FlashEASuite V2 - Program B (The Brain)")
        self.logger.info("High-Frequency Hybrid Trading System")
        self.logger.info("=" * 80)
    
    def _setup_logging(self) -> logging.Logger:
        """
        Setup logging configuration.
        
        Returns:
            Configured logger instance
        """
        # Create logs directory if not exists
        import os
        os.makedirs('logs', exist_ok=True)
        
        # Configure logging
        logging.basicConfig(
            level=getattr(logging, config.LOG_LEVEL),
            format=config.LOG_FORMAT,
            handlers=[
                logging.FileHandler(config.LOG_FILE),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        return logging.getLogger("FlashEABrain")
    
    def _signal_handler(self, signum: int, frame) -> None:
        """
        Handle shutdown signals (SIGINT, SIGTERM).
        
        Args:
            signum: Signal number
            frame: Current stack frame
        """
        signal_name = signal.Signals(signum).name
        self.logger.warning(f"Received {signal_name}, initiating graceful shutdown...")
        self.shutdown_event.set()
    
    def _start_workers(self) -> None:
        """
        Start all multiprocessing workers.
        """
        self.logger.info("Starting multiprocessing workers...")
        
        # Start Ingestion Worker
        self.logger.info("Initializing Ingestion Worker...")
        ingestion_worker = create_ingestion_worker(
            output_queue=self.ingestion_queue,
            shutdown_event=self.shutdown_event
        )
        ingestion_worker.start()
        self.workers.append(ingestion_worker)
        self.logger.info(f"Ingestion Worker started (PID: {ingestion_worker.pid})")
        
        # Start Strategy Engine Worker
        self.logger.info("Initializing Strategy Engine Worker...")
        strategy_worker = create_strategy_engine(
            input_queue=self.ingestion_queue,
            output_queue=self.signal_queue,
            shutdown_event=self.shutdown_event
        )
        strategy_worker.start()
        self.workers.append(strategy_worker)
        self.logger.info(f"Strategy Engine started (PID: {strategy_worker.pid})")
        
        self.logger.info(f"All workers started successfully ({len(self.workers)} processes)")
    
    def _wait_for_workers(self) -> None:
        """
        Wait for all workers to complete.
        
        Monitors worker health and handles unexpected terminations.
        """
        self.logger.info("Monitoring worker processes...")
        
        try:
            while not self.shutdown_event.is_set():
                # Check if any worker has died unexpectedly
                for worker in self.workers:
                    if not worker.is_alive():
                        self.logger.error(
                            f"Worker {worker.name} (PID: {worker.pid}) died unexpectedly! "
                            f"Exit code: {worker.exitcode}"
                        )
                        self.shutdown_event.set()
                        break
                
                # Sleep briefly to avoid CPU spinning
                time.sleep(1)
                
        except KeyboardInterrupt:
            self.logger.warning("KeyboardInterrupt in main loop")
            self.shutdown_event.set()
    
    def _shutdown_workers(self) -> None:
        """
        Gracefully shutdown all worker processes.
        """
        self.logger.info("Shutting down workers...")
        
        # Set shutdown event (if not already set)
        self.shutdown_event.set()
        
        # Wait for workers to finish gracefully
        shutdown_start = time.time()
        for worker in self.workers:
            remaining_time = config.GRACEFUL_SHUTDOWN_TIMEOUT - (time.time() - shutdown_start)
            
            if remaining_time > 0:
                self.logger.info(f"Waiting for {worker.name} to finish (timeout: {remaining_time:.1f}s)...")
                worker.join(timeout=remaining_time)
                
                if worker.is_alive():
                    self.logger.warning(f"{worker.name} did not finish in time, terminating...")
                    worker.terminate()
                    worker.join(timeout=1)
                else:
                    self.logger.info(f"{worker.name} stopped cleanly")
            else:
                self.logger.warning(f"Timeout expired, terminating {worker.name}...")
                worker.terminate()
                worker.join(timeout=1)
        
        # Force kill if still alive
        for worker in self.workers:
            if worker.is_alive():
                self.logger.error(f"Force killing {worker.name}...")
                worker.kill()
                worker.join()
        
        self.logger.info("All workers stopped")
    
    def _cleanup_resources(self) -> None:
        """
        Clean up system resources (queues, etc.).
        """
        self.logger.info("Cleaning up resources...")
        
        try:
            # Clear queues
            while not self.ingestion_queue.empty():
                try:
                    self.ingestion_queue.get_nowait()
                except:
                    break
            
            while not self.signal_queue.empty():
                try:
                    self.signal_queue.get_nowait()
                except:
                    break
            
            # Close queues
            self.ingestion_queue.close()
            self.signal_queue.close()
            
            self.logger.info("Resource cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Error during resource cleanup: {e}")
    
    def run(self) -> int:
        """
        Main execution method.
        
        Returns:
            Exit code (0 for success, 1 for error)
        """
        try:
            self.logger.info("Starting FlashEA Brain...")
            self.logger.info(f"Configuration: ZMQ Feeder={config.ZMQ_FEEDER_ADDRESS}")
            self.logger.info(f"Queue Sizes: Ingestion={config.INGESTION_QUEUE_SIZE}, "
                           f"Signal={config.SIGNAL_QUEUE_SIZE}")
            
            # Start all workers
            self._start_workers()
            
            self.logger.info("System is running. Press Ctrl+C to stop.")
            
            # Monitor workers
            self._wait_for_workers()
            
            return 0
            
        except Exception as e:
            self.logger.error(f"Fatal error in main execution: {e}", exc_info=True)
            return 1
            
        finally:
            # Always cleanup
            self._shutdown_workers()
            self._cleanup_resources()
            self.logger.info("FlashEA Brain shutdown complete")
            self.logger.info("=" * 80)


def main() -> int:
    """
    Entry point for FlashEA Brain.
    
    Returns:
        Exit code
    """
    # Set multiprocessing start method (important for cross-platform compatibility)
    try:
        mp.set_start_method('spawn')
    except RuntimeError:
        # Already set
        pass
    
    # Create and run the brain
    brain = FlashEABrain()
    return brain.run()


if __name__ == "__main__":
    sys.exit(main())
