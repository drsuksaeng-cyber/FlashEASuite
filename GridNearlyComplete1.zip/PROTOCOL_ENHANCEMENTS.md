# 🔌 **Protocol Enhancements for Risk Management**

**Version:** 2.1  
**Date:** December 22, 2025  
**Purpose:** Enhanced message protocol for new risk management features

---

## 📊 **New Message Types**

### **Current Messages (V2.0):**
```
1. TICK_MESSAGE (Type 1)
2. POLICY_MESSAGE (Type 2)
3. TRADE_RESULT (Type 3)
4. HEARTBEAT (Type 4)
```

### **New Messages (V2.1):**
```
5. RISK_STATUS (Type 5)      - Risk management state
6. DD_WARNING (Type 6)        - Drawdown warnings
7. CORRELATION_UPDATE (Type 7) - Correlation matrix
8. HEDGE_SIGNAL (Type 8)      - Hedging instructions
```

---

## 🔧 **Message Format Updates**

### **Enhanced POLICY_MESSAGE (Type 2):**

**Before (V2.0):**
```python
PolicyMessage {
    type: 2
    timestamp: int64
    symbol: string
    strategy: string
    action: string  # BUY/SELL
    confidence: float
    direction: float
    bias: int
    params: dict
}
```

**After (V2.1) - With Risk Management:**
```python
PolicyMessage {
    type: 2
    timestamp: int64
    symbol: string
    strategy: string
    action: string
    confidence: float
    direction: float
    bias: int
    
    # NEW: Risk Management Parameters
    risk_params: {
        base_lot: float           # Base lot size
        risk_pct: float          # Risk percentage (1%)
        max_lot: float           # Maximum lot allowed
        atr_multiplier: float    # ATR multiplier for SL
        stop_loss: float         # Calculated SL price
        take_profit: float       # Calculated TP price
        volatility_adj: float    # Volatility adjustment (0.5-1.5)
        dd_multiplier: float     # DD reduction multiplier (0-1)
        correlation_adj: float   # Correlation adjustment
    }
    
    # NEW: Scaling Parameters
    scaling: {
        enabled: bool
        num_scales: int          # Number of scale entries
        lot_per_scale: float
        spacing_pips: float
        scale_mode: string       # PYRAMID or AVERAGE_DOWN
    }
    
    params: dict
}
```

**MessagePack Structure:**
```python
[
    2,                    # type
    1703261815234,        # timestamp
    "EURUSD",            # symbol
    "Grid",              # strategy
    "BUY",               # action
    0.75,                # confidence
    45.5,                # direction
    1,                   # bias
    {                    # risk_params (NEW)
        "base_lot": 0.10,
        "risk_pct": 1.0,
        "max_lot": 0.10,
        "atr_multiplier": 2.0,
        "stop_loss": 1.0450,
        "take_profit": 1.0550,
        "volatility_adj": 0.85,
        "dd_multiplier": 0.80,
        "correlation_adj": 1.0
    },
    {                    # scaling (NEW)
        "enabled": true,
        "num_scales": 4,
        "lot_per_scale": 0.025,
        "spacing_pips": 20,
        "scale_mode": "PYRAMID"
    },
    {...}                # params
]
```

---

### **New Message: RISK_STATUS (Type 5)**

**Purpose:** Real-time risk management status from Client to Server

**Structure:**
```python
RiskStatusMessage {
    type: 5
    timestamp: int64
    
    # Account Status
    balance: float
    equity: float
    margin: float
    margin_level: float
    
    # Drawdown Metrics
    peak_balance: float
    current_dd: float           # Current DD %
    max_dd_today: float        # Max DD today %
    
    # Daily Metrics
    daily_pnl: float
    daily_trades: int
    daily_wins: int
    daily_losses: int
    daily_limit_remaining: float  # How much left before DLL
    
    # Position Metrics
    open_positions: int
    total_exposure: float       # Total risk %
    exposure_remaining: float   # How much left before max
    
    # Risk State
    risk_multiplier: float      # Current DD multiplier (0-1)
    is_hedged: bool
    is_critical: bool           # DD > 10%
    is_stopped: bool            # Trading stopped
    
    # Correlation
    max_correlation: float      # Highest pair correlation
    correlated_pairs: int       # Number of high-corr pairs
}
```

**MessagePack:**
```python
[
    5,                   # type
    1703261815234,       # timestamp
    10000.0,            # balance
    9850.0,             # equity
    500.0,              # margin
    1970.0,             # margin_level
    10200.0,            # peak_balance
    3.43,               # current_dd
    4.15,               # max_dd_today
    -150.0,             # daily_pnl
    15,                 # daily_trades
    9,                  # daily_wins
    6,                  # daily_losses
    250.0,              # daily_limit_remaining (out of 400)
    8,                  # open_positions
    12.5,               # total_exposure (%)
    2.5,                # exposure_remaining (%)
    0.85,               # risk_multiplier
    false,              # is_hedged
    false,              # is_critical
    false,              # is_stopped
    0.82,               # max_correlation
    2                   # correlated_pairs
]
```

---

### **New Message: DD_WARNING (Type 6)**

**Purpose:** Drawdown warnings from Client to Server

**Structure:**
```python
DDWarningMessage {
    type: 6
    timestamp: int64
    severity: string    # INFO, WARNING, CRITICAL
    current_dd: float
    threshold: float
    action_taken: string
    message: string
}
```

**Severity Levels:**
```python
INFO:     DD < 5%     # Normal operation
WARNING:  DD 5-8%     # Reduced position sizing
CRITICAL: DD 8-10%    # Severe reduction, consider hedging
EMERGENCY: DD >= 10%  # Trading stopped
```

**MessagePack:**
```python
[
    6,                          # type
    1703261815234,              # timestamp
    "WARNING",                  # severity
    7.5,                        # current_dd
    8.0,                        # threshold
    "REDUCED_SIZING_50PCT",     # action_taken
    "DD at 7.5%, reduced position sizing to 50%"  # message
]
```

---

### **New Message: CORRELATION_UPDATE (Type 7)**

**Purpose:** Correlation matrix update from Client to Server

**Structure:**
```python
CorrelationUpdateMessage {
    type: 7
    timestamp: int64
    symbols: list[string]
    matrix: list[list[float]]   # NxN correlation matrix
    high_correlations: list[dict]  # Pairs with >0.7 correlation
}
```

**MessagePack:**
```python
[
    7,                          # type
    1703261815234,              # timestamp
    ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD"],  # symbols
    [                           # 4x4 matrix
        [1.0,  0.85, -0.45, 0.12],
        [0.85, 1.0,  -0.38, 0.15],
        [-0.45, -0.38, 1.0, -0.05],
        [0.12, 0.15, -0.05, 1.0]
    ],
    [                           # high_correlations
        {"pair": ["EURUSD", "GBPUSD"], "correlation": 0.85},
    ]
]
```

---

### **New Message: HEDGE_SIGNAL (Type 8)**

**Purpose:** Hedging instructions from Server to Client

**Structure:**
```python
HedgeSignalMessage {
    type: 8
    timestamp: int64
    action: string      # ACTIVATE, DEACTIVATE, UPDATE
    reason: string      # DD_HIGH, MARKET_CRASH, MANUAL
    
    hedge_params: {
        hedge_symbol: string
        hedge_size: float
        hedge_type: string    # LONG/SHORT
        target_exposure: float  # Target % to hedge
    }
}
```

**MessagePack:**
```python
[
    8,                          # type
    1703261815234,              # timestamp
    "ACTIVATE",                 # action
    "DD_HIGH",                  # reason
    {                           # hedge_params
        "hedge_symbol": "XAUUSD",
        "hedge_size": 0.50,
        "hedge_type": "LONG",
        "target_exposure": 50.0
    }
]
```

---

## 🔌 **Protocol Implementation**

### **Python Server - Message Handling:**

```python
# 02_Brain/core/protocol/message_handler.py

class EnhancedMessageHandler:
    """Handle new message types"""
    
    def __init__(self):
        self.handlers = {
            1: self.handle_tick,
            2: self.handle_policy,
            3: self.handle_trade_result,
            4: self.handle_heartbeat,
            5: self.handle_risk_status,      # NEW
            6: self.handle_dd_warning,       # NEW
            7: self.handle_correlation,      # NEW
            8: self.handle_hedge_signal      # NEW
        }
        
    def handle_message(self, msg_data):
        """Route message to appropriate handler"""
        msg = msgpack.unpackb(msg_data)
        msg_type = msg[0]
        
        if msg_type in self.handlers:
            return self.handlers[msg_type](msg)
        else:
            print(f"Unknown message type: {msg_type}")
            
    def handle_risk_status(self, msg):
        """Handle risk status update"""
        risk_status = {
            'timestamp': msg[1],
            'balance': msg[2],
            'equity': msg[3],
            'margin': msg[4],
            'margin_level': msg[5],
            'peak_balance': msg[6],
            'current_dd': msg[7],
            'max_dd_today': msg[8],
            'daily_pnl': msg[9],
            'daily_trades': msg[10],
            'daily_wins': msg[11],
            'daily_losses': msg[12],
            'daily_limit_remaining': msg[13],
            'open_positions': msg[14],
            'total_exposure': msg[15],
            'exposure_remaining': msg[16],
            'risk_multiplier': msg[17],
            'is_hedged': msg[18],
            'is_critical': msg[19],
            'is_stopped': msg[20],
            'max_correlation': msg[21],
            'correlated_pairs': msg[22]
        }
        
        # Update risk monitoring dashboard
        self.update_risk_dashboard(risk_status)
        
        # Check if action needed
        if risk_status['current_dd'] > 8.0:
            self.consider_hedge_activation(risk_status)
            
        return risk_status
        
    def handle_dd_warning(self, msg):
        """Handle DD warning"""
        warning = {
            'timestamp': msg[1],
            'severity': msg[2],
            'current_dd': msg[3],
            'threshold': msg[4],
            'action_taken': msg[5],
            'message': msg[6]
        }
        
        # Log warning
        print(f"⚠️ DD WARNING: {warning['message']}")
        
        # Send alert if critical
        if warning['severity'] == 'CRITICAL':
            self.send_alert(warning)
            
        return warning
        
    def handle_correlation(self, msg):
        """Handle correlation update"""
        correlation = {
            'timestamp': msg[1],
            'symbols': msg[2],
            'matrix': msg[3],
            'high_correlations': msg[4]
        }
        
        # Update correlation monitoring
        self.update_correlation_dashboard(correlation)
        
        # Adjust strategy if needed
        if len(correlation['high_correlations']) > 2:
            print("⚠️ High correlation risk detected")
            
        return correlation
        
    def handle_hedge_signal(self, msg):
        """Handle hedge signal (from server to client)"""
        # This is typically sent FROM server, not received
        pass
```

---

### **MQL5 Client - Message Sending:**

```cpp
// Include/Network/Protocol/EnhancedProtocol.mqh

class CEnhancedProtocol : public CProtocol
{
public:
    // Send Risk Status
    bool SendRiskStatus(
        double balance, double equity, double margin,
        double peak, double current_dd,
        double daily_pnl, int daily_trades,
        int open_pos, double exposure
    )
    {
        m_msgpack.Reset();
        m_msgpack.PackArray(23);
        
        m_msgpack.PackInt(5);                    // type
        m_msgpack.PackInt(TimeGMT());            // timestamp
        m_msgpack.PackDouble(balance);
        m_msgpack.PackDouble(equity);
        m_msgpack.PackDouble(margin);
        m_msgpack.PackDouble(GetMarginLevel());
        m_msgpack.PackDouble(peak);
        m_msgpack.PackDouble(current_dd);
        m_msgpack.PackDouble(GetMaxDDToday());
        m_msgpack.PackDouble(daily_pnl);
        m_msgpack.PackInt(daily_trades);
        m_msgpack.PackInt(GetDailyWins());
        m_msgpack.PackInt(GetDailyLosses());
        m_msgpack.PackDouble(GetDailyLimitRemaining());
        m_msgpack.PackInt(open_pos);
        m_msgpack.PackDouble(exposure);
        m_msgpack.PackDouble(GetExposureRemaining());
        m_msgpack.PackDouble(GetRiskMultiplier());
        m_msgpack.PackBool(IsHedged());
        m_msgpack.PackBool(current_dd >= 10.0);
        m_msgpack.PackBool(IsTradingStopped());
        m_msgpack.PackDouble(GetMaxCorrelation());
        m_msgpack.PackInt(GetCorrelatedPairsCount());
        
        uchar data[];
        m_msgpack.GetData(data);
        
        return m_zmq_pub.send_bin(data, true);
    }
    
    // Send DD Warning
    bool SendDDWarning(string severity, double dd, string action)
    {
        m_msgpack.Reset();
        m_msgpack.PackArray(7);
        
        m_msgpack.PackInt(6);                    // type
        m_msgpack.PackInt(TimeGMT());            // timestamp
        m_msgpack.PackString(severity);
        m_msgpack.PackDouble(dd);
        m_msgpack.PackDouble(GetDDThreshold(severity));
        m_msgpack.PackString(action);
        m_msgpack.PackString(BuildWarningMessage(severity, dd));
        
        uchar data[];
        m_msgpack.GetData(data);
        
        return m_zmq_pub.send_bin(data, true);
    }
    
    // Send Correlation Update
    bool SendCorrelationUpdate(string &symbols[], double &matrix[][])
    {
        m_msgpack.Reset();
        m_msgpack.PackArray(5);
        
        m_msgpack.PackInt(7);                    // type
        m_msgpack.PackInt(TimeGMT());            // timestamp
        
        // Pack symbols
        m_msgpack.PackArray(ArraySize(symbols));
        for(int i = 0; i < ArraySize(symbols); i++)
            m_msgpack.PackString(symbols[i]);
        
        // Pack matrix
        int n = ArraySize(symbols);
        m_msgpack.PackArray(n);
        for(int i = 0; i < n; i++)
        {
            m_msgpack.PackArray(n);
            for(int j = 0; j < n; j++)
                m_msgpack.PackDouble(matrix[i][j]);
        }
        
        // Pack high correlations
        PackHighCorrelations(symbols, matrix);
        
        uchar data[];
        m_msgpack.GetData(data);
        
        return m_zmq_pub.send_bin(data, true);
    }
};
```

---

## 🔄 **Message Flow**

### **Normal Operation Flow:**

```
1. Client → Server: RISK_STATUS (every 60s)
   Purpose: Update server on current risk state
   
2. Server → Client: POLICY (when signal generated)
   Purpose: Send enhanced policy with risk params
   
3. Client → Server: TRADE_RESULT (after execution)
   Purpose: Report trade outcome
   
4. Client → Server: CORRELATION_UPDATE (every 5 min)
   Purpose: Keep server informed of correlations
```

### **High Drawdown Flow:**

```
1. Client detects DD > 5%
   │
2. Client → Server: DD_WARNING (severity=INFO)
   │
3. Client → Server: RISK_STATUS (updated)
   │
4. Server adjusts risk_multiplier
   │
5. Server → Client: POLICY (with reduced lot)
   │
6. If DD > 8%:
   │
7. Client → Server: DD_WARNING (severity=WARNING)
   │
8. Server → Client: HEDGE_SIGNAL (consider hedging)
   │
9. If DD > 10%:
   │
10. Client → Server: DD_WARNING (severity=EMERGENCY)
    │
11. Client stops trading
    │
12. Client → Server: RISK_STATUS (is_stopped=true)
```

---

## 📝 **Implementation Checklist**

### **Python Server:**
```
☐ Create EnhancedMessageHandler class
☐ Implement handle_risk_status()
☐ Implement handle_dd_warning()
☐ Implement handle_correlation()
☐ Implement handle_hedge_signal()
☐ Create risk dashboard
☐ Create correlation dashboard
☐ Add alert system
☐ Unit tests
```

### **MQL5 Client:**
```
☐ Create CEnhancedProtocol class
☐ Implement SendRiskStatus()
☐ Implement SendDDWarning()
☐ Implement SendCorrelationUpdate()
☐ Implement ReceiveHedgeSignal()
☐ Integrate with RiskGuardian
☐ Add periodic status updates
☐ Unit tests
```

---

## ✅ **Testing Protocol**

### **Test Cases:**

```
Test 1: Risk Status Message
  ☐ Pack message correctly
  ☐ Send via ZMQ
  ☐ Receive and unpack
  ☐ Verify all fields
  
Test 2: DD Warning Message
  ☐ Test each severity level
  ☐ Verify action taken
  ☐ Check alert triggering
  
Test 3: Correlation Update
  ☐ Test matrix packing
  ☐ Test high correlation detection
  ☐ Verify dashboard update
  
Test 4: Hedge Signal
  ☐ Test activation
  ☐ Test deactivation
  ☐ Verify execution
  
Test 5: Message Flow
  ☐ Test normal operation
  ☐ Test high DD scenario
  ☐ Test emergency stop
```

---

**Status:** 📋 Protocol Enhanced  
**Version:** 2.1  
**Ready for:** Week 1 Development
