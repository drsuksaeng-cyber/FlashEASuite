# 📋 Task 2: Quick Reference - Code Snippets

เอกสารนี้มี **Code Snippets** สำเร็จรูปให้คุณ Copy/Paste ลงไฟล์ได้เลย

---

## 📄 File 1: ProgramC_Trader.mq5 Updates

### **Location:** `03_ProgramC_Trader_MQL_Src/ProgramC_Trader.mq5`

---

### **Update 1: Add Include (หลัง line 31)**

```cpp
#include "../Include/Logic/StrategyManager.mqh"
#include "../Include/Logic/Strategy_Spike.mqh"
#include "../Include/Logic/Strategy_Grid.mqh"  // ← ADD THIS LINE
```

---

### **Update 2: Add Grid Inputs (หลัง line 44)**

```cpp
//--- Grid Strategy Configuration
input group "=== Grid Strategy Settings ==="
input int    InpGridMaxOrders  = 5;        // Grid: Maximum Orders
input double InpGridBaseStep   = 200.0;    // Grid: Base Step (points)
input double InpGridLotMult    = 1.5;      // Grid: Lot Multiplier
input double InpGridBaseLot    = 0.01;     // Grid: Base Lot Size
input int    InpGridATRPeriod  = 14;       // Grid: ATR Period
input double InpGridATRRef     = 30.0;     // Grid: Reference ATR Value
input double InpGridSL         = 500.0;    // Grid: Stop Loss (points)
input double InpGridTP         = 300.0;    // Grid: Take Profit (points)
```

---

### **Update 3: Modify OnInit() (แทนที่ section ที่มี AddStrategy)**

**Find this (around line 93-96):**
```cpp
   // 3. Init Council & Strategies
   g_council.Initialize();
   g_council.AddStrategy(new CStrategySpike()); // Add Spike Hunter
   
   Print("✅ System Ready: Waiting for Brain Policy...");
```

**Replace with:**
```cpp
   // 3. Init Council & Strategies
   g_council.Initialize();
   
   // Add Spike Hunter
   g_council.AddStrategy(new CStrategySpike());
   Print("✅ Added: Spike Hunter Strategy");
   
   // Add Grid Strategy (NEW!)
   CStrategyGrid* grid = new CStrategyGrid();
   grid.UpdateConfig(InpGridMaxOrders, InpGridBaseStep, InpGridLotMult);
   g_council.AddStrategy(grid);
   Print("✅ Added: Elastic Grid Strategy");
   Print("   → Max Orders: ", InpGridMaxOrders);
   Print("   → Base Step: ", InpGridBaseStep, " points");
   Print("   → Lot Mult: ", InpGridLotMult, "x");
   
   Print("✅ System Ready: Waiting for Brain Policy...");
```

---

## 📄 File 2: StrategyManager.mqh Updates

### **Location:** `Include/Logic/StrategyManager.mqh`

---

### **Update 1: Add Grid Execution Method (หลัง ExecuteTrade method)**

**Find ExecuteTrade() method (around line 77-82):**
```cpp
   void ExecuteTrade(ENUM_ORDER_TYPE type)
     {
      double lot = 0.01;
      double price = (type == ORDER_TYPE_BUY) ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);
      m_trade.PositionOpen(_Symbol, type, lot, price, 0, 0, "Council_Action");
     }
  };
```

**Add this NEW method BEFORE the closing `};`:**

```cpp
   void ExecuteTrade(ENUM_ORDER_TYPE type)
     {
      double lot = 0.01;
      double price = (type == ORDER_TYPE_BUY) ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);
      m_trade.PositionOpen(_Symbol, type, lot, price, 0, 0, "Council_Action");
     }
   
   //+------------------------------------------------------------------+
   //| Execute Trade with Grid Strategy Support (NEW!)                 |
   //+------------------------------------------------------------------+
   void ExecuteTradeWithGrid(ENUM_ORDER_TYPE type)
     {
      // First, execute regular strategies
      ExecuteTrade(type);
      
      // Then, check if Grid strategy needs to execute
      for(int i=0; i<ArraySize(m_strategies); i++)
        {
         // Check if this is the Grid strategy
         if(m_strategies[i].GetName() == "ElasticGrid")
           {
            // Cast to Grid and execute grid-specific logic
            CStrategyGrid* grid = dynamic_cast<CStrategyGrid*>(m_strategies[i]);
            if(grid != NULL)
              {
               grid.ExecuteGridOrder(type);
               Print("[Manager] Grid strategy executed for ", EnumToString(type));
              }
           }
        }
     }
  };
```

---

### **Update 2: Replace ExecuteTrade Calls (in OnTickLogic method)**

**Find these lines (around line 67 and 72):**
```cpp
      if(total_buy_score > m_vote_threshold && total_buy_score > total_sell_score)
        {
         Print(">> COUNCIL VOTE BUY! Score: ", total_buy_score);
         ExecuteTrade(ORDER_TYPE_BUY);  // ← CHANGE THIS
        }
      else if(total_sell_score > m_vote_threshold && total_sell_score > total_buy_score)
        {
         Print(">> COUNCIL VOTE SELL! Score: ", total_sell_score);
         ExecuteTrade(ORDER_TYPE_SELL);  // ← CHANGE THIS
        }
```

**Replace with:**
```cpp
      if(total_buy_score > m_vote_threshold && total_buy_score > total_sell_score)
        {
         Print(">> COUNCIL VOTE BUY! Score: ", total_buy_score);
         ExecuteTradeWithGrid(ORDER_TYPE_BUY);  // ← CHANGED
        }
      else if(total_sell_score > m_vote_threshold && total_sell_score > total_buy_score)
        {
         Print(">> COUNCIL VOTE SELL! Score: ", total_sell_score);
         ExecuteTradeWithGrid(ORDER_TYPE_SELL);  // ← CHANGED
        }
```

---

## 📄 File 3: PolicyManager.mqh Updates (Optional)

### **Location:** `Include/Logic/PolicyManager.mqh`

---

### **Update: Add Grid Policy Parsing**

**Add this method to CPolicyManager class:**

```cpp
//+------------------------------------------------------------------+
//| Update Grid Strategy with Policy Data                            |
//+------------------------------------------------------------------+
void UpdateGridWithPolicy(double risk_mult, bool cooldown, double confidence,
                          double csm_usd, double csm_eur)
  {
   // This requires access to g_council from ProgramC_Trader
   // You may need to pass g_council as parameter or make it global
   
   // Example implementation:
   extern CStrategyManager g_council; // Declare external
   
   CStrategyBase* strategies[] = g_council.GetStrategies(); // If available
   
   for(int i=0; i<ArraySize(strategies); i++)
     {
      if(strategies[i].GetName() == "ElasticGrid")
        {
         CStrategyGrid* grid = dynamic_cast<CStrategyGrid*>(strategies[i]);
         if(grid != NULL)
           {
            grid.UpdatePolicyData(risk_mult, cooldown, confidence);
            grid.UpdateCSMData(csm_usd, csm_eur);
            
            Print("[Policy] ✅ Grid Updated:");
            Print("  → Risk Multiplier: ", risk_mult, "x");
            Print("  → Cooldown: ", (cooldown ? "YES" : "NO"));
            Print("  → Confidence: ", DoubleToString(confidence, 2));
            Print("  → CSM USD: ", csm_usd, " | EUR: ", csm_eur);
           }
        }
     }
  }
```

**Or simpler approach - Call from ProgramC_Trader OnTick():**

```cpp
// In ProgramC_Trader.mq5 OnTick():

void OnTick()
{
   // ... existing code ...
   
   // After receiving policy, update Grid
   if(g_policy.HasNewPolicy())
     {
      // Parse policy data
      double risk = g_policy.GetRiskMultiplier();
      bool cool = g_policy.GetCooldown();
      double conf = g_policy.GetConfidence();
      double usd = g_policy.GetCSM_USD();
      double eur = g_policy.GetCSM_EUR();
      
      // Update Grid directly
      UpdateGridStrategy(risk, cool, conf, usd, eur);
     }
   
   // ... existing code ...
}

void UpdateGridStrategy(double risk, bool cool, double conf, double usd, double eur)
{
   // Find Grid in council
   for(int i=0; i<g_council.GetStrategyCount(); i++)
     {
      CStrategyBase* strat = g_council.GetStrategy(i);
      if(strat.GetName() == "ElasticGrid")
        {
         CStrategyGrid* grid = dynamic_cast<CStrategyGrid*>(strat);
         if(grid != NULL)
           {
            grid.UpdatePolicyData(risk, cool, conf);
            grid.UpdateCSMData(usd, eur);
           }
        }
     }
}
```

---

## 📄 File 4: Python Strategy Updates

### **Location:** `02_ProgramB_Brain_Py/core/strategy.py`

---

### **Update: Add Grid Policy Data to ZMQ Message**

**Find the `publish_policy()` method and update:**

```python
def publish_policy(self, tick_data):
    """Publish policy with Grid-specific data"""
    
    # Basic policy structure
    policy = {
        'symbol': 'XAUUSD',
        'action': 'hold',
        'weight': 1.0,
        'timestamp': int(time.time() * 1000),
        
        # Grid-specific additions (NEW!)
        'risk_multiplier': self.risk_multiplier,      # From feedback loop
        'is_in_cooldown': self.is_in_cooldown,        # From feedback loop
        'confidence': self.calculate_confidence(),     # Based on performance
        
        # CSM data (if available)
        'csm': {
            'USD': self.get_csm_strength('USD'),
            'EUR': self.get_csm_strength('EUR'),
            'GBP': self.get_csm_strength('GBP'),
            'JPY': self.get_csm_strength('JPY')
        }
    }
    
    # Serialize and publish
    packed = msgpack.packb(policy)
    self.zmq_pub_socket.send(packed)
    
    # Log
    logger.info(f"📤 POLICY: Risk={self.risk_multiplier:.2f}x, "
                f"Cool={self.is_in_cooldown}, Conf={policy['confidence']:.2f}")

def calculate_confidence(self):
    """Calculate trading confidence based on recent performance"""
    if self.total_trades == 0:
        return 0.5  # Medium confidence (no data yet)
    
    # Calculate win rate
    win_rate = self.total_wins / self.total_trades if self.total_trades > 0 else 0.5
    
    # Map win rate to confidence
    # 0% win rate → 0.1 confidence (very low)
    # 50% win rate → 0.5 confidence (medium)
    # 70%+ win rate → 0.8 confidence (high)
    
    if win_rate >= 0.7:
        confidence = 0.8
    elif win_rate >= 0.5:
        confidence = 0.5
    elif win_rate >= 0.3:
        confidence = 0.3
    else:
        confidence = 0.1  # Very low, likely pause grid
    
    # Adjust for consecutive losses (emergency)
    if self.consecutive_losses >= 3:
        confidence = 0.0  # Force pause
    
    return confidence

def get_csm_strength(self, currency):
    """Get currency strength from CSM module"""
    try:
        if hasattr(self, 'csm') and self.csm is not None:
            return self.csm.get_strength(currency)
    except:
        pass
    
    return 0.0  # Neutral if CSM not available
```

---

## 🧪 Testing Checklist:

### **Phase 1: Compilation**
- [ ] Copy Strategy_Grid.mqh to Include/Logic/
- [ ] Update ProgramC_Trader.mq5
- [ ] Update StrategyManager.mqh
- [ ] Compile (F7) - should have 0 errors

---

### **Phase 2: Basic Functionality**
- [ ] Attach EA to chart
- [ ] Check Expert log for "✅ Added: Elastic Grid Strategy"
- [ ] Verify inputs visible in EA settings
- [ ] Check ATR indicator loads (no error)

---

### **Phase 3: Grid Behavior**
- [ ] Run Python Brain
- [ ] Send test policy with CSM data
- [ ] Check Grid receives: "[Grid] CSM Direction: ..."
- [ ] Check Grid respects cooldown
- [ ] Check Grid pauses on low confidence

---

### **Phase 4: Position Management**
- [ ] Verify first grid opens
- [ ] Check lot size = base_lot * risk_multiplier
- [ ] Wait for price movement
- [ ] Verify second grid opens at elastic step distance
- [ ] Check lot progression (level 1 = base * mult)

---

## 🎯 Quick Debug Commands:

**In MQL5 (add to Strategy_Grid.mqh OnTick or GetScore):**
```cpp
Print("[Grid] Status:");
Print("  Active: ", m_is_active);
Print("  Direction: ", m_grid_direction);
Print("  Cooldown: ", m_is_in_cooldown);
Print("  Confidence: ", m_confidence_score);
Print("  Current ATR: ", m_current_atr);
Print("  Elastic Step: ", m_elastic_step);
Print("  Active Grids: ", m_active_grid_count);
Print("  Risk Mult: ", m_risk_multiplier);
```

**In Python (add to publish_policy):**
```python
print(f"[Strategy] Publishing Policy:")
print(f"  Risk: {self.risk_multiplier:.2f}x")
print(f"  Cooldown: {self.is_in_cooldown}")
print(f"  Confidence: {policy['confidence']:.2f}")
print(f"  CSM USD: {policy['csm']['USD']:.2f}")
print(f"  CSM EUR: {policy['csm']['EUR']:.2f}")
```

---

## 📝 Summary:

**Files to Update:**
1. ✅ ProgramC_Trader.mq5 (3 changes)
2. ✅ StrategyManager.mqh (2 changes)
3. ✅ PolicyManager.mqh (1 optional change)
4. ✅ strategy.py (2 changes)

**Total Changes:** ~50 lines of code

**Estimated Time:** 15-20 minutes

**Difficulty:** ⭐⭐⭐ Medium

---

**พร้อมแล้วครับ! Copy code จากเอกสารนี้ไปใช้ได้เลย!** 🚀
