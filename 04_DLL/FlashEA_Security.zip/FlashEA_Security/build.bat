@echo off
REM ═══════════════════════════════════════════════════════════
REM  FlashEA Security DLL - Automated Build Script
REM  Version: 1.0
REM  For: FlashEASuite V2 - Phase 3
REM ═══════════════════════════════════════════════════════════

echo.
echo ═══════════════════════════════════════════════════════════
echo   FlashEA Security DLL Builder
echo   Phase 3 - DLL Protection Layer
echo ═══════════════════════════════════════════════════════════
echo.

REM Check if running in Developer Command Prompt
where cl >nul 2>nul
if errorlevel 1 (
    echo ❌ ERROR: cl compiler not found!
    echo.
    echo You must run this script from:
    echo    "Developer Command Prompt for VS 2022"
    echo.
    echo How to open:
    echo    1. Press Windows key
    echo    2. Search "Developer Command Prompt"
    echo    3. Run "Developer Command Prompt for VS 2022"
    echo    4. Navigate to this folder
    echo    5. Run build.bat again
    echo.
    pause
    exit /b 1
)

echo ✅ Compiler found
echo.

REM Clean old files
echo 🧹 Cleaning old files...
if exist *.obj del /Q *.obj
if exist *.lib del /Q *.lib
if exist *.exp del /Q *.exp
if exist *.pdb del /Q *.pdb
if exist FlashEA_Security.dll del /Q FlashEA_Security.dll
echo    Cleaned: *.obj, *.lib, *.exp, *.pdb, *.dll
echo.

REM Compile
echo 🔨 Compiling DLL...
echo.
echo Command:
echo    cl /LD /O2 /DFLASHEA_SECURITY_EXPORTS Security.cpp SecurityHelpers.cpp
echo    /link wbemuuid.lib ole32.lib oleaut32.lib /OUT:FlashEA_Security.dll
echo.
echo ─────────────────────────────────────────────────────────

cl /LD /O2 /DFLASHEA_SECURITY_EXPORTS Security.cpp SecurityHelpers.cpp /link wbemuuid.lib ole32.lib oleaut32.lib /OUT:FlashEA_Security.dll

echo ─────────────────────────────────────────────────────────
echo.

if errorlevel 1 (
    echo.
    echo ❌ COMPILATION FAILED!
    echo.
    echo Common issues:
    echo    1. Missing source files (Security.cpp, SecurityHelpers.cpp)
    echo    2. Syntax errors in code
    echo    3. Missing libraries
    echo.
    echo Check the errors above and fix them.
    echo.
    pause
    exit /b 1
)

REM Check if DLL was created
if not exist FlashEA_Security.dll (
    echo.
    echo ❌ DLL file not created!
    echo.
    pause
    exit /b 1
)

echo ✅ COMPILATION SUCCESS!
echo.

REM Show DLL info
echo 📊 DLL Information:
echo.
for %%F in (FlashEA_Security.dll) do (
    echo    File:      %%~nxF
    echo    Size:      %%~zF bytes
    echo    Date:      %%~tF
)
echo.

REM Copy to MT5
echo 📦 Copying to MT5...
echo.

set MT5_PATH=%APPDATA%\MetaQuotes\Terminal
set COPIED=0

if not exist "%MT5_PATH%" (
    echo ⚠️  MT5 Terminal folder not found at:
    echo    %MT5_PATH%
    echo.
    echo    Manual copy required.
    goto :MANUAL_COPY
)

REM Find all terminal folders and copy
for /d %%D in ("%MT5_PATH%\*") do (
    if exist "%%D\MQL5\Libraries" (
        echo    Found terminal: %%~nD
        copy /Y FlashEA_Security.dll "%%D\MQL5\Libraries\" >nul 2>&1
        if not errorlevel 1 (
            echo    ✅ Copied to: %%D\MQL5\Libraries\
            set COPIED=1
        )
    )
)

if "%COPIED%"=="0" (
    echo.
    echo ⚠️  No MT5 terminal folders found with MQL5\Libraries\
    goto :MANUAL_COPY
)

echo.
echo ✅ DLL copied to MT5 successfully!
goto :SUCCESS

:MANUAL_COPY
echo.
echo ═══════════════════════════════════════════════════════════
echo   Manual Copy Required
echo ═══════════════════════════════════════════════════════════
echo.
echo Copy this file:
echo    %CD%\FlashEA_Security.dll
echo.
echo To:
echo    C:\Users\[YOUR_USER]\AppData\Roaming\MetaQuotes\Terminal\[TERMINAL_ID]\MQL5\Libraries\
echo.
echo How to find your terminal folder:
echo    1. Press Win+R
echo    2. Type: %%appdata%%\MetaQuotes\Terminal
echo    3. Find folder with lots of files (not "Common")
echo    4. Copy DLL to: [THAT_FOLDER]\MQL5\Libraries\
echo.
goto :SUCCESS

:SUCCESS
echo.
echo ═══════════════════════════════════════════════════════════
echo   Build Complete!
echo ═══════════════════════════════════════════════════════════
echo.
echo Next steps:
echo    1. Open MetaEditor
echo    2. Compile: 03_Trader\TestDLLWrapper.mq5
echo    3. Run test EA on any chart
echo    4. Check "Allow DLL imports"
echo    5. Verify tests pass
echo.
echo ✅ Ready to test!
echo.
pause
