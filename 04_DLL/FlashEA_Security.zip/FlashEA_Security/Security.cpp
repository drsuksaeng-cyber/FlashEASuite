//+------------------------------------------------------------------+
//|                                         Security.cpp              |
//|                          FlashEASuite V2 - Phase 3               |
//|                          DLL Protection Layer                    |
//+------------------------------------------------------------------+
//| Main Implementation                                               |
//+------------------------------------------------------------------+

#define FLASHEA_SECURITY_EXPORTS
#include "Security.h"
#include <Windows.h>
#include <wbemidl.h>
#include <comdef.h>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <vector>

// Link with these libraries
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")

// NOTE: For production, add OpenSSL libraries:
// #include <openssl/sha.h>
// #include <openssl/rsa.h>
// #include <openssl/pem.h>
// #pragma comment(lib, "libcrypto.lib")

//+------------------------------------------------------------------+
//| DLL Entry Point                                                   |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        // Initialize COM for WMI
        CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        break;
    case DLL_PROCESS_DETACH:
        CoUninitialize();
        break;
    }
    return TRUE;
}

//+------------------------------------------------------------------+
//| 1. CheckLicense - Verify license file                            |
//+------------------------------------------------------------------+
FLASHEA_API int __stdcall CheckLicense(const wchar_t* license_path)
{
    try {
        // Read license file
        std::ifstream file(license_path);
        if (!file.is_open()) {
            return LICENSE_INVALID;
        }
        
        std::string license_content((std::istreambuf_iterator<char>(file)),
                                     std::istreambuf_iterator<char>());
        file.close();
        
        if (license_content.empty()) {
            return LICENSE_INVALID;
        }
        
        // Parse license JSON
        std::string license_id, hwid, expiry_date;
        if (!FlashEASecurity::ParseLicenseJSON(license_content, license_id, hwid, expiry_date)) {
            return LICENSE_INVALID;
        }
        
        // Get current HWID
        wchar_t current_hwid[256] = {0};
        GetHWID(current_hwid, 256);
        
        // Convert to string for comparison
        std::wstring current_hwid_ws(current_hwid);
        std::string current_hwid_str(current_hwid_ws.begin(), current_hwid_ws.end());
        
        // Check HWID match
        if (current_hwid_str != hwid) {
            return LICENSE_HWID_MISMATCH;
        }
        
        // TODO: Check expiry date (requires date parsing)
        // For now, assume not expired
        
        // TODO: Verify RSA signature
        // For Phase 3, we'll add this with OpenSSL
        
        return LICENSE_VALID;
        
    } catch (...) {
        return LICENSE_INVALID;
    }
}

//+------------------------------------------------------------------+
//| 2. GetHWID - Generate Hardware ID                                |
//+------------------------------------------------------------------+
FLASHEA_API void __stdcall GetHWID(wchar_t* output, int max_len)
{
    try {
        std::string components;
        
        // Component 1: CPU Serial
        components += FlashEASecurity::GetCPUSerial();
        
        // Component 2: Disk Volume Serial
        components += FlashEASecurity::GetDiskVolumeSerial();
        
        // Component 3: Machine GUID
        components += FlashEASecurity::GetMachineGUID();
        
        // Component 4: MT5 Path Hash (optional, will be empty if MT5 not found)
        components += FlashEASecurity::GetMT5PathHash();
        
        // Generate SHA256 hash
        std::string hwid = FlashEASecurity::SHA256(components);
        
        // Convert to wide string
        std::wstring hwid_ws(hwid.begin(), hwid.end());
        
        // Copy to output
        wcsncpy_s(output, max_len, hwid_ws.c_str(), _TRUNCATE);
        
    } catch (...) {
        if (max_len > 0) {
            output[0] = L'\0';
        }
    }
}

//+------------------------------------------------------------------+
//| 3. CalculateTradingParams - CRITICAL FUNCTION                    |
//+------------------------------------------------------------------+
FLASHEA_API int __stdcall CalculateTradingParams(
    const wchar_t* license_path,
    const char* symbol,
    double account_balance,
    TradingParams* output)
{
    try {
        // Verify license first
        int license_status = CheckLicense(license_path);
        if (license_status != LICENSE_VALID) {
            return 0; // Invalid license
        }
        
        // Calculate parameters based on symbol and balance
        std::string symbol_str(symbol);
        
        output->lot_size = FlashEASecurity::CalculateLotSize(symbol_str, account_balance);
        output->grid_step = FlashEASecurity::CalculateGridStep(symbol_str, account_balance);
        output->max_orders = FlashEASecurity::CalculateMaxOrders(account_balance);
        
        // TP/SL based on symbol type
        if (symbol_str.find("USD") != std::string::npos) {
            // Forex pairs
            output->tp_points = 200.0;
            output->sl_points = 100.0;
        } else if (symbol_str == "XAUUSD") {
            // Gold
            output->tp_points = 50.0;
            output->sl_points = 30.0;
        } else {
            // Default
            output->tp_points = 100.0;
            output->sl_points = 50.0;
        }
        
        // Calculate checksum for validation
        output->checksum = FlashEASecurity::CRC32(
            reinterpret_cast<const unsigned char*>(output),
            sizeof(TradingParams) - sizeof(uint32_t)
        );
        
        return 1; // Success
        
    } catch (...) {
        return 0; // Error
    }
}

//+------------------------------------------------------------------+
//| 4. VerifyPolicy - Verify policy signature                        |
//+------------------------------------------------------------------+
FLASHEA_API int __stdcall VerifyPolicy(const char* policy_json, const char* public_key)
{
    try {
        std::string policy_str(policy_json);
        std::string pubkey_str(public_key);
        
        // TODO: Parse JSON to extract signature
        // TODO: Verify RSA signature with OpenSSL
        
        // For Phase 3 initial implementation, use stub
        // This will be replaced with real RSA verification
        
        // Temporary: Always return valid (for integration testing)
        // WARNING: This must be replaced with real verification!
        return 1;
        
    } catch (...) {
        return 0;
    }
}

//+------------------------------------------------------------------+
//| 5. VerifyChallenge - Anti-Mock protection                        |
//+------------------------------------------------------------------+
FLASHEA_API int __stdcall VerifyChallenge(Challenge* challenge, Response* response)
{
    try {
        // Get license secret (hardcoded in DLL)
        const char* secret = FlashEASecurity::GetLicenseSecret();
        
        // Combine: random + license_id + timestamp + secret
        std::stringstream ss;
        ss << challenge->random_value 
           << challenge->license_id 
           << challenge->timestamp 
           << secret;
        
        std::string data = ss.str();
        
        // Calculate hash
        uint32_t computed_hash = FlashEASecurity::CRC32(
            reinterpret_cast<const unsigned char*>(data.c_str()),
            data.length()
        );
        
        // Compare with expected response
        return (computed_hash == response->computed_hash) ? 1 : 0;
        
    } catch (...) {
        return 0;
    }
}

//+------------------------------------------------------------------+
//| 6. VerifyDLLIntegrity - Self-checksum verification               |
//+------------------------------------------------------------------+
FLASHEA_API int __stdcall VerifyDLLIntegrity()
{
    try {
        // Get DLL file path
        HMODULE hModule = GetModuleHandleW(L"FlashEA_Security.dll");
        if (!hModule) return 0;
        
        wchar_t dll_path[MAX_PATH];
        GetModuleFileNameW(hModule, dll_path, MAX_PATH);
        
        // Read DLL file
        std::ifstream file(dll_path, std::ios::binary);
        if (!file.is_open()) return 0;
        
        // Read entire file
        std::vector<unsigned char> file_data(
            (std::istreambuf_iterator<char>(file)),
            std::istreambuf_iterator<char>()
        );
        file.close();
        
        // Calculate checksum
        uint32_t current_checksum = FlashEASecurity::CRC32(
            file_data.data(),
            file_data.size()
        );
        
        // Hardcoded expected checksum (set after compilation)
        // TODO: Replace with actual checksum after first build
        const uint32_t EXPECTED_CHECKSUM = 0x12345678;
        
        // For initial testing, skip checksum verification
        // WARNING: Enable this in production!
        return 1; // Always pass for now
        
        // Production code:
        // return (current_checksum == EXPECTED_CHECKSUM) ? 1 : 0;
        
    } catch (...) {
        return 0;
    }
}

//+------------------------------------------------------------------+
//| End of main exports                                               |
//+------------------------------------------------------------------+
