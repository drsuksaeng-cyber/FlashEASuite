//+------------------------------------------------------------------+
//|                                         TradingParams.h          |
//|                          FlashEASuite V2 - Phase 3               |
//|                          DLL Protection Layer                    |
//+------------------------------------------------------------------+
//| Trading Parameters Structure - Shared between DLL and MQL5      |
//+------------------------------------------------------------------+

#ifndef TRADING_PARAMS_H
#define TRADING_PARAMS_H

#include <cstdint>

//+------------------------------------------------------------------+
//| Trading Parameters Structure                                      |
//| CRITICAL: Must match MQL5 struct exactly!                        |
//+------------------------------------------------------------------+
struct TradingParams {
    double lot_size;        // Base lot size
    double grid_step;       // Grid step in points
    int max_orders;         // Maximum orders allowed
    double tp_points;       // Take profit in points
    double sl_points;       // Stop loss in points
    uint32_t checksum;      // Encrypted checksum for validation
};

//+------------------------------------------------------------------+
//| Challenge-Response Structures (Anti-Mock Protection)             |
//+------------------------------------------------------------------+
struct Challenge {
    uint32_t random_value;   // Random number from EA
    uint64_t timestamp;      // Current timestamp
    char license_id[64];     // License ID
};

struct Response {
    uint32_t computed_hash;  // Expected hash value
};

//+------------------------------------------------------------------+
//| License Status Enumeration                                        |
//+------------------------------------------------------------------+
enum LicenseStatus {
    LICENSE_VALID = 1,
    LICENSE_INVALID = 0,
    LICENSE_EXPIRED = -1,
    LICENSE_REVOKED = -2,
    LICENSE_HWID_MISMATCH = -3
};

#endif // TRADING_PARAMS_H
