//+------------------------------------------------------------------+
//|                                         Security.h                |
//|                          FlashEASuite V2 - Phase 3               |
//|                          DLL Protection Layer                    |
//+------------------------------------------------------------------+
//| Security Functions - DLL Exports                                 |
//+------------------------------------------------------------------+

#ifndef SECURITY_H
#define SECURITY_H

#include "TradingParams.h"
#include <string>
#include <Windows.h>

//+------------------------------------------------------------------+
//| DLL Export Macro                                                  |
//+------------------------------------------------------------------+
#ifdef FLASHEA_SECURITY_EXPORTS
#define FLASHEA_API __declspec(dllexport)
#else
#define FLASHEA_API __declspec(dllimport)
#endif

//+------------------------------------------------------------------+
//| Exported Functions                                                |
//+------------------------------------------------------------------+

extern "C" {
    
    // 1. License Verification
    // Returns: 1 (valid), 0 (invalid), -1 (expired), -2 (revoked), -3 (HWID mismatch)
    FLASHEA_API int __stdcall CheckLicense(const wchar_t* license_path);
    
    // 2. HWID Generation
    // Generates unique hardware ID (SHA256 hash)
    FLASHEA_API void __stdcall GetHWID(wchar_t* output, int max_len);
    
    // 3. Trading Parameters Calculation (CRITICAL!)
    // Returns: 1 (success), 0 (invalid license)
    FLASHEA_API int __stdcall CalculateTradingParams(
        const wchar_t* license_path,
        const char* symbol,
        double account_balance,
        TradingParams* output
    );
    
    // 4. Policy Signature Verification
    // Returns: 1 (valid signature), 0 (invalid)
    FLASHEA_API int __stdcall VerifyPolicy(
        const char* policy_json,
        const char* public_key
    );
    
    // 5. Challenge-Response (Anti-Mock DLL)
    // Returns: 1 (authentic DLL), 0 (fake/mock)
    FLASHEA_API int __stdcall VerifyChallenge(
        Challenge* challenge,
        Response* response
    );
    
    // 6. DLL Integrity Check
    // Returns: 1 (intact), 0 (modified)
    FLASHEA_API int __stdcall VerifyDLLIntegrity();
    
} // extern "C"

//+------------------------------------------------------------------+
//| Internal Helper Functions (not exported)                         |
//+------------------------------------------------------------------+

namespace FlashEASecurity {
    
    // HWID Components
    std::string GetCPUSerial();
    std::string GetDiskVolumeSerial();
    std::string GetMachineGUID();
    std::string GetMT5PathHash();
    
    // Hash Functions
    std::string SHA256(const std::string& data);
    uint32_t CRC32(const unsigned char* data, size_t length);
    
    // License Parsing
    bool ParseLicenseJSON(const std::string& json_content, std::string& license_id, 
                          std::string& hwid, std::string& expiry_date);
    
    // RSA Verification
    bool VerifyRSASignature(const std::string& data, const std::string& signature, 
                            const std::string& public_key);
    
    // Trading Params Calculation
    double CalculateLotSize(const std::string& symbol, double balance);
    double CalculateGridStep(const std::string& symbol, double balance);
    int CalculateMaxOrders(double balance);
    
    // Challenge Secret
    const char* GetLicenseSecret();
    
} // namespace FlashEASecurity

#endif // SECURITY_H
