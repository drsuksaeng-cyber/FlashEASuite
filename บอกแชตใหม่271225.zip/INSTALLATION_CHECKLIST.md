# ✅ Installation Checklist - December 26, 2025

## 📦 ไฟล์ที่ต้อง Copy

### **1. Code Files (4 ไฟล์)**

#### **ProgramC_Trader_FINAL.mq5**
```
Copy to: FlashEASuite_V2/03_Trader/ProgramC_Trader.mq5
Replace: Yes (ทับไฟล์เดิม)
```

#### **MqlMsgPack.mqh**
```
Copy to: FlashEASuite_V2/Include/MqlMsgPack.mqh
Replace: Yes (ถ้ามีอยู่แล้ว)
```

#### **TEST_MqlMsgPack.mq5**
```
Copy to: FlashEASuite_V2/Tester/TEST_MqlMsgPack.mq5
Replace: Yes
```

#### **MINIMAL_TEST.mq5**
```
Copy to: FlashEASuite_V2/Tester/MINIMAL_TEST.mq5
Replace: Yes
```

---

### **2. Documentation Files (3 ไฟล์สำคัญ)**

#### **⚠️ CLAUDE_INCLUDE_WARNING.md** ⭐⭐⭐⭐⭐
```
Copy to: FlashEASuite_V2/⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
Purpose: สำหรับ Claude รุ่นต่อไปอ่านก่อนแก้ include
```

#### **DAILY_LOG_20251226.md**
```
Copy to: FlashEASuite_V2/DAILY_LOG_20251226.md
Purpose: บันทึกงานวันนี้
```

#### **README_20251226.md**
```
Copy to: FlashEASuite_V2/README_20251226.md
Purpose: สรุปสั้นๆ
```

---

## 🎯 ขั้นตอนการติดตั้ง

### **Step 1: Copy Code Files**
```
☐ ProgramC_Trader_FINAL.mq5 → 03_Trader/
☐ MqlMsgPack.mqh → Include/
☐ TEST_MqlMsgPack.mq5 → Tester/
☐ MINIMAL_TEST.mq5 → Tester/
```

### **Step 2: Copy Documentation**
```
☐ ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md → Root
☐ DAILY_LOG_20251226.md → Root
☐ README_20251226.md → Root
```

### **Step 3: Compile**
```
☐ เปิด MetaEditor
☐ เปิด 03_Trader/ProgramC_Trader.mq5
☐ กด F7 (Compile)
☐ คาดหวัง: 0 errors, 0 warnings
```

### **Step 4: Test (ถ้า compile สำเร็จ)**
```
☐ Compile Tester/TEST_MqlMsgPack.mq5
☐ Compile Tester/MINIMAL_TEST.mq5
☐ ทั้งสองต้อง compile สำเร็จ
```

---

## 📋 โครงสร้างไฟล์หลังติดตั้ง

```
FlashEASuite_V2/
├── ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md  ← ใหม่!
├── DAILY_LOG_20251226.md            ← ใหม่!
├── README_20251226.md               ← ใหม่!
│
├── Include/
│   └── MqlMsgPack.mqh               ← Updated!
│
├── 03_Trader/
│   └── ProgramC_Trader.mq5          ← Updated!
│
└── Tester/
    ├── TEST_MqlMsgPack.mq5          ← ใหม่!
    └── MINIMAL_TEST.mq5             ← ใหม่!
```

---

## ⚠️ สิ่งที่ต้องระวัง

### **1. Include Paths**
```
ต้องใช้:
#include "../Include/MqlMsgPack.mqh"
#include "../Include/Zmq/ZmqHub.mqh"
... (ทั้งหมดใช้ "")

ห้ามใช้:
#include <MqlMsgPack.mqh>  ❌
#include <Zmq/ZmqHub.mqh>  ❌
```

### **2. File Locations**
```
ProgramC_Trader.mq5 ต้องอยู่ใน: 03_Trader/
Include files ต้องอยู่ใน:       FlashEASuite_V2/Include/
Test files ต้องอยู่ใน:          Tester/
```

### **3. Compilation**
```
ถ้า compile error:
1. เช็ค include paths
2. เช็คว่าไฟล์อยู่ที่ถูกต้อง
3. อ่าน ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
4. ถามคำถามใหม่
```

---

## 🎯 Expected Results

### **After Installation:**
```
✅ ProgramC_Trader.mq5 compiles successfully
✅ 0 errors
✅ 0 warnings
✅ ProgramC_Trader.ex5 created
```

### **Test Files:**
```
✅ TEST_MqlMsgPack.mq5 compiles
✅ MINIMAL_TEST.mq5 compiles
✅ Both create .ex5 files
```

---

## 📞 Troubleshooting

### **ถ้า compile error:**

**Error: "file not found"**
```
→ เช็คว่าไฟล์อยู่ใน Include/ หรือไม่
→ เช็คว่าใช้ "" ไม่ใช่ <>
→ เช็ค relative path ว่าถูกต้อง
```

**Error: "undeclared identifier"**
```
→ Include path อาจผิด
→ ไฟล์อาจไม่ถูก include
→ ลองใช้ "../Include/..." แทน
```

**Error: "unexpected token"**
```
→ Syntax อาจผิด
→ เช็ค ; ท้ายบรรทัด
→ เช็ค {} matching
```

---

## 💾 Backup

**ก่อนติดตั้ง:**
```
☐ Backup 03_Trader/ProgramC_Trader.mq5 เดิม
☐ Backup Include/MqlMsgPack.mqh เดิม (ถ้ามี)
```

**วิธี Backup:**
```
เปลี่ยนชื่อไฟล์เดิม:
ProgramC_Trader.mq5 → ProgramC_Trader_BACKUP_20251226.mq5
MqlMsgPack.mqh → MqlMsgPack_BACKUP_20251226.mqh
```

---

## ✅ Final Checklist

```
Installation:
☐ All 4 code files copied
☐ All 3 documentation files copied
☐ File locations verified
☐ Backup created

Compilation:
☐ ProgramC_Trader.mq5 compiled
☐ 0 errors, 0 warnings
☐ .ex5 file created

Testing:
☐ TEST_MqlMsgPack.mq5 compiled
☐ MINIMAL_TEST.mq5 compiled
☐ Both working

Documentation:
☐ Read ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md
☐ Read DAILY_LOG_20251226.md
☐ Understand what happened today
```

---

**Status:** Ready for installation  
**Date:** December 26, 2025  
**Critical:** Read ⚠️_CLAUDE_INCLUDE_WARNING_⚠️.md first!
