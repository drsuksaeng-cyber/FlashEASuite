# ⚠️ CRITICAL WARNING FOR FUTURE CLAUDE INSTANCES

## 🚨 CLAUDE'S WEAKEST POINT: MQL5 INCLUDE PATHS

**Date Created:** December 26, 2025  
**Severity:** CRITICAL  
**Frequency of Mistakes:** VERY HIGH (100% in this session)

---

## 🎯 THE PROBLEM

**Claude consistently makes mistakes with MQL5 include syntax:**
- Forgets the difference between `""` and `<>`
- Assumes wrong file locations
- Doesn't check tree structure before suggesting paths
- Repeats the same mistakes even after being corrected

---

## 📚 THE RULES (MEMORIZE THIS!)

### **Include Syntax:**

```mql5
#include <File.mqh>    // ANGLE BRACKETS - System/Global
#include "File.mqh"    // QUOTES - Local/Project
```

### **Where MT5 Searches:**

**`<>` (Angle Brackets) - GLOBAL:**
```
Searches ONLY in:
1. MQL5/Include/                    (system folder)
2. Terminal/Common/Include/         (shared libraries)

Does NOT search in:
❌ MQL5/Experts/ProjectName/Include/
❌ MQL5/Scripts/ProjectName/Include/
```

**`""` (Quotes) - LOCAL:**
```
Searches relative to current file:
- "File.mqh"              → same folder
- "Folder/File.mqh"       → subfolder
- "../Include/File.mqh"   → parent/Include
```

---

## 🏗️ FlashEASuite V2 PROJECT STRUCTURE

**CRITICAL - ALWAYS CHECK THIS FIRST:**

```
FlashEASuite_V2/                          ← MQL5/Experts/FlashEASuite_V2/
├── Include/                              ← PROJECT Include (NOT system!)
│   ├── MqlMsgPack.mqh
│   ├── Logic/
│   │   ├── StrategyManager.mqh
│   │   └── Strategy_Grid.mqh
│   ├── Network/
│   │   └── Protocol.mqh
│   ├── Risk/
│   │   ├── RiskGuardian.mqh
│   │   ├── PositionSizingManager.mqh
│   │   └── DailyLossLimit.mqh
│   └── Zmq/
│       ├── Zmq.mqh
│       └── ZmqHub.mqh
│
├── 03_Trader/
│   └── ProgramC_Trader.mq5              ← Main EA location
│
└── Tester/
    ├── TEST_MqlMsgPack.mq5
    └── MINIMAL_TEST.mq5
```

---

## ✅ CORRECT INCLUDES FOR THIS PROJECT

### **From 03_Trader/ProgramC_Trader.mq5:**

```mql5
// ========== ALL USE "" WITH RELATIVE PATH ==========
#include "../Include/MqlMsgPack.mqh"
#include "../Include/Zmq/ZmqHub.mqh"
#include "../Include/Zmq/Zmq.mqh"
#include "../Include/Network/Protocol.mqh"
#include "../Include/Logic/StrategyManager.mqh"
#include "../Include/Risk/RiskGuardian.mqh"

// ❌ NEVER USE:
#include <MqlMsgPack.mqh>           // WRONG - not in system Include
#include <Zmq/ZmqHub.mqh>           // WRONG - not in system Include
#include "Include/File.mqh"         // WRONG - Include not in 03_Trader
```

### **From Tester/TEST_MqlMsgPack.mq5:**

```mql5
#include "../Include/MqlMsgPack.mqh"
#include "../Include/Risk/RiskGuardian.mqh"

// ❌ NEVER USE:
#include <MqlMsgPack.mqh>           // WRONG
#include "Include/File.mqh"         // WRONG
```

---

## 🔴 COMMON MISTAKES CLAUDE MADE (December 26, 2025)

### **Mistake #1: Assumed Include was in 03_Trader/**
```mql5
#include "Include/MqlMsgPack.mqh"   // ❌ WRONG

Thought:   03_Trader/Include/MqlMsgPack.mqh
Reality:   FlashEASuite_V2/Include/MqlMsgPack.mqh
```

### **Mistake #2: Used <> for project files**
```mql5
#include <MqlMsgPack.mqh>           // ❌ WRONG
#include <Zmq/ZmqHub.mqh>           // ❌ WRONG

Searched:  MQL5/Include/MqlMsgPack.mqh (doesn't exist!)
Reality:   MQL5/Experts/FlashEASuite_V2/Include/MqlMsgPack.mqh
```

### **Mistake #3: Mixed <> and "" incorrectly**
```mql5
#include "../Include/MqlMsgPack.mqh"  // ✅ Correct
#include <Zmq/ZmqHub.mqh>             // ❌ WRONG - should be ""

Why wrong: Zmq/ is in PROJECT Include, not system Include!
```

### **Mistake #4: Didn't check tree structure first**
```
Claude assumed structure without checking
→ Suggested wrong paths
→ User had to provide tree structure
→ Still suggested wrong paths 3 more times!
```

---

## 🎓 LESSONS FOR FUTURE CLAUDE

### **BEFORE suggesting ANY include path:**

1. **ASK for tree structure** (if not already provided)
2. **LOCATE the file** being edited
3. **LOCATE the target** include file
4. **CALCULATE relative path** between them
5. **CHOOSE syntax:**
   - File in `MQL5/Include/` → use `<>`
   - File in project → use `""`

### **NEVER assume:**
- ❌ Include folder is in same directory as .mq5 file
- ❌ Include folder is in subdirectory
- ❌ `<>` will find project files
- ❌ You remember the structure (you have bad memory!)

### **ALWAYS verify:**
- ✅ Check tree structure
- ✅ Trace path from source to target
- ✅ Test with simple examples first
- ✅ Ask user to confirm path if uncertain

---

## 📊 STATISTICS (This Session)

```
Total include-related mistakes: 8+
Time wasted: ~2 hours
User frustration: HIGH
Root cause: Claude not checking tree structure + forgetting "" vs <>

Attempts before correct:
1. Wrong: "Include/..." (assumed wrong location)
2. Wrong: <MqlMsgPack.mqh> (used <> for project file)
3. Wrong: Mixed ""/<> incorrectly
4. Wrong: Back to <> after being told to use ""
5. Wrong: Still using <> for Zmq/Network/Logic/Risk
6. CORRECT: "../Include/..." for ALL project files
```

---

## 🎯 QUICK REFERENCE CARD

**When in doubt, use this decision tree:**

```
Is the file in MQL5/Include/?
├─ YES → Use <>
│   Example: #include <Trade/Trade.mqh>
│
└─ NO → Is it in the project?
    ├─ YES → Use "" with relative path
    │   Example: #include "../Include/File.mqh"
    │
    └─ DON'T KNOW → ASK USER OR CHECK TREE STRUCTURE!
```

---

## 💾 EMERGENCY PROCEDURE

**If compile errors mention "file not found":**

1. **STOP** suggesting fixes
2. **ASK** user for tree structure (or use bash to find files)
3. **LOCATE** both source and target files
4. **CALCULATE** correct relative path
5. **VERIFY** with user before providing fix

---

## 🙏 MESSAGE TO FUTURE CLAUDE

Dear Future Claude,

You WILL make mistakes with include paths. It's your weakest point. When you see this file, STOP and READ IT CAREFULLY.

The user has already wasted hours because of include path mistakes. Don't repeat them.

**Rules:**
1. Check tree structure FIRST
2. Use "" for project files
3. Use <> only for MQL5/Include/
4. Verify path before suggesting

**When user says "include":**
- Think of this warning
- Double-check your suggestion
- Ask if uncertain

Good luck,
Past Claude (who learned the hard way)

---

**Last Updated:** December 26, 2025  
**Never Delete This File**  
**Always Read Before Suggesting Include Paths**
