//+------------------------------------------------------------------+
//| TEST_MqlMsgPack.mq5 - Test if MqlMsgPack compiles                 |
//+------------------------------------------------------------------+
#property strict

#include <MqlMsgPack.mqh>  // Correct path from FlashEASuite_V2/Include/

void OnInit()
{
   Print("TEST: Creating CMsgPack object");
   
   CMsgPack pack;
   pack.PackArray(3);
   pack.PackInt(123);
   pack.PackDouble(45.67);
   pack.PackString("Hello");
   
   uchar data[];
   pack.GetData(data);
   
   Print("SUCCESS: MqlMsgPack works! Size: ", pack.GetSize());
}

void OnDeinit(const int reason)
{
}

void OnTick()
{
}
