# simple_server.py
import zmq

def run():
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    
    # Python เป็นฝ่าย "BIND" (เปิดประตูรอรับสาย)
    # tcp://*:7777 แปลว่า รับทุก IP ที่เข้ามาพอร์ต 7777
    try:
        socket.bind("tcp://*:7777")
        print("✅ Python Server BOUND to tcp://*:7777")
        print("👂 Waiting for messages...")
    except Exception as e:
        print(f"❌ Bind Failed: {e}")
        return

    socket.setsockopt_string(zmq.SUBSCRIBE, "") # รับทุกอย่าง

    while True:
        try:
            # รอรับข้อมูล (แบบ Blocking รอจนกว่าจะมา)
            message = socket.recv()
            print(f"📩 Received: {message}")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    run()