"""
FlashEASuite V2 - Research Tool
Spike Simulation & Ratio Analysis
"""
import pandas as pd
import numpy as np
import os

# --- [ส่วนที่ 1: Logic คำนวณ Ratio] ---
class TickAnalyzer:
    def __init__(self, window_short=1.0, window_long=900.0):
        self.window_short = window_short
        self.window_long = window_long
        
    def calculate_ratio_from_dataframe(self, df):
        """
        คำนวณ Ratio ย้อนหลังทั้งหมดจากข้อมูล DataFrame
        """
        # แปลง TimeMSC เป็น datetime เพื่อใช้คำนวณ
        df['datetime'] = pd.to_datetime(df['TimeMSC'], unit='ms')
        df = df.set_index('datetime')
        
        # 1. นับจำนวน Tick ในช่วง Short (1s) และ Long (15m)
        # ใช้ rolling count
        freq_1s = df['Bid'].rolling(f'{int(self.window_short)}s').count()
        freq_15m = df['Bid'].rolling(f'{int(self.window_long)}s').count()
        
        # 2. ปรับ 15m ให้เป็น Average per second
        # (หารด้วยระยะเวลาหน้าต่าง หรือเวลาที่ผ่านไปจริงถ้ายังไม่ครบหน้าต่าง)
        seconds_passed = (df.index - df.index[0]).total_seconds()
        divisor = np.minimum(seconds_passed, self.window_long)
        divisor = np.maximum(divisor, 1.0) # กันหาร 0
        
        avg_density_15m = freq_15m / divisor
        
        # 3. คำนวณ Ratio
        df['Density_1s'] = freq_1s
        df['Avg_Density_15m'] = avg_density_15m
        df['Ratio'] = np.where(avg_density_15m > 0, freq_1s / avg_density_15m, 0)
        
        return df

# --- [ส่วนที่ 2: วิเคราะห์หาค่า Threshold ที่เหมาะสม] ---
def analyze_threshold(df):
    print("\n--- 📊 Statistical Analysis ---")
    ratios = df['Ratio']
    
    mean = ratios.mean()
    std = ratios.std()
    max_val = ratios.max()
    
    print(f"Mean Ratio: {mean:.4f}")
    print(f"Std Dev:    {std:.4f}")
    print(f"Max Ratio:  {max_val:.4f}")
    
    # คำนวณค่า Sigma (ความผิดปกติ)
    sigma_3 = mean + (3 * std)
    sigma_5 = mean + (5 * std)
    
    print(f"\n[Recommendation Based on Data]")
    print(f"Safe Threshold (3 Sigma): {sigma_3:.2f}")
    print(f"Hard Threshold (5 Sigma): {sigma_5:.2f}")
    
    return sigma_3

# --- [Main Execution] ---
if __name__ == "__main__":
    # 1. ระบุไฟล์ CSV (อาจารย์ต้องแก้ Path นี้ให้ตรงกับไฟล์จริงที่ได้จาก MT5)
    # ตัวอย่าง: csv_path = r"C:\Users\...\MQL5\Files\FlashEA\SpikeData_....csv"
    csv_path = "test_data_capture.csv" # (ไฟล์สมมติ)
    
    if os.path.exists(csv_path):
        print(f"Loading data from {csv_path}...")
        try:
            df = pd.read_csv(csv_path)
            
            # เรียกใช้ Logic
            analyzer = TickAnalyzer()
            df_analyzed = analyzer.calculate_ratio_from_dataframe(df)
            
            # วิเคราะห์สถิติ
            analyze_threshold(df_analyzed)
            
            print("\n✅ Analysis Complete.")
            
        except Exception as e:
            print(f"Error reading/processing file: {e}")
    else:
        print(f"❌ File not found: {csv_path}")
        print("Please export CSV from MT5 first and update the path in this script.")