# 🔧 แก้ไข Magic Number Issue - Manual Trades

## ❌ ปัญหาที่พบ

**MT5 Log แสดง:**
```
⚠️ Skipping: Wrong Magic Number (0 != 999000)
🔔 Trade Transaction Detected! Ticket: 16373028
⚠️ Skipping: Wrong Magic Number (0 != 999000)
```

**สาเหตุ:**
- **Manual position** (เปิดจาก MT5 UI) มี **Magic Number = 0** เสมอ
- EA ตั้ง `InpMagicNumber = 999000`
- EA จึง **skip** ไม่ส่งข้อมูลกลับ Python เพราะ magic ไม่ตรง

---

## ✅ วิธีแก้ไข (2 ทางเลือก)

### **วิธีที่ 1: เปลี่ยน Input Parameter (ง่ายสุด - ทดสอบเฉพาะ)**

**ใน MT5:**
1. คลิกขวาที่ EA → **Properties**
2. แท็บ **Inputs**
3. เปลี่ยน `InpMagicNumber` จาก `999000` → `0`
4. กด **OK**

**ข้อดี:**
- ✅ แก้ไขง่าย ไม่ต้องแก้โค้ด
- ✅ ทดสอบกับ manual trades ได้ทันที

**ข้อเสี้ย:**
- ❌ เมื่อ EA เทรดเอง (magic = 999000) จะไม่ส่งข้อมูล
- ❌ ไม่เหมาะสำหรับใช้งานจริง

---

### **วิธีที่ 2: เพิ่ม Option ส่งทุก Trade (แนะนำ - แก้แล้ว!)**

**เพิ่ม Input Parameter ใหม่:**
```cpp
input bool InpSendAllTrades = true;  // ส่งทุก trade หรือเฉพาะ magic ที่ตรง?
```

**Logic:**
```cpp
// ✅ เช็ค Magic Number (ถ้า InpSendAllTrades = false)
if(!InpSendAllTrades && magic != InpMagicNumber) {
   Print("⚠️ Skipping: Wrong Magic Number (", magic, " != ", InpMagicNumber, ")");
   return;
}
```

**ตัวเลือก:**
- **`InpSendAllTrades = true`** (default) → ส่ง**ทุก trade** (รวม manual, magic = 0)
- **`InpSendAllTrades = false`** → ส่ง**เฉพาะ trade** ที่มี magic = InpMagicNumber

**ข้อดี:**
- ✅ ยืดหยุ่น - เลือกได้ว่าจะส่งทุก trade หรือเฉพาะ EA trades
- ✅ ทดสอบกับ manual trades ได้ (ตั้ง = true)
- ✅ Production ใช้ได้ (ตั้ง = false เพื่อส่งเฉพาะ EA trades)

---

## 🚀 การใช้งาน (หลังแก้โค้ด)

### **สถานการณ์ที่ 1: ทดสอบกับ Manual Trades**

**ตั้งค่า:**
```
InpSendAllTrades = true   ✅ ส่งทุก trade
InpMagicNumber = 999000   (ค่าใดก็ได้)
```

**ผลลัพธ์:**
- Manual position (magic = 0) → ✅ **ส่งข้อมูลไป Python**
- EA position (magic = 999000) → ✅ **ส่งข้อมูลไป Python**
- Position อื่นๆ → ✅ **ส่งทุกตัว**

---

### **สถานการณ์ที่ 2: Production (ส่งเฉพาะ EA Trades)**

**ตั้งค่า:**
```
InpSendAllTrades = false  ✅ ส่งเฉพาะ magic ที่ตรง
InpMagicNumber = 999000   ✅ Magic ของ EA
```

**ผลลัพธ์:**
- Manual position (magic = 0) → ❌ **ไม่ส่ง** (skip)
- EA position (magic = 999000) → ✅ **ส่งข้อมูลไป Python**
- Position อื่นๆ → ❌ **ไม่ส่ง** (skip)

---

### **สถานการณ์ที่ 3: Multiple EAs**

หากมีหลาย EA รันพร้อมกัน แต่ละตัวมี magic ต่างกัน:

**EA #1:**
```
InpSendAllTrades = false
InpMagicNumber = 999000   → ส่งเฉพาะ trades ที่มี magic = 999000
```

**EA #2:**
```
InpSendAllTrades = false
InpMagicNumber = 999001   → ส่งเฉพาะ trades ที่มี magic = 999001
```

---

## 📝 การเปลี่ยนแปลง

### **1. เพิ่ม Input Parameter (บรรทัด 25)**
```cpp
input bool InpSendAllTrades = true;  // ✅ เพิ่ม
```

### **2. แก้ Logic ใน SendTradeResult() (บรรทัด 154-158)**

**เดิม:**
```cpp
// เช็ค Magic Number
if(magic != InpMagicNumber) {
   Print("⚠️ Skipping: Wrong Magic Number (", magic, " != ", InpMagicNumber, ")");
   return;
}
```

**ใหม่:**
```cpp
// ✅ เช็ค Magic Number (ถ้า InpSendAllTrades = false)
if(!InpSendAllTrades && magic != InpMagicNumber) {
   Print("⚠️ Skipping: Wrong Magic Number (", magic, " != ", InpMagicNumber, ")");
   return;
}
```

**Logic Breakdown:**
```cpp
!InpSendAllTrades              // ถ้า = false (ส่งเฉพาะ magic ที่ตรง)
&&                             // AND
magic != InpMagicNumber       // magic ไม่ตรง

→ Skip (ไม่ส่ง)
```

**Truth Table:**
| InpSendAllTrades | magic == InpMagicNumber | ผลลัพธ์ |
|------------------|-------------------------|---------|
| true | ไม่สำคัญ | ✅ ส่ง |
| false | true | ✅ ส่ง |
| false | false | ❌ ไม่ส่ง |

---

## ✅ Compile และทดสอบ

### **Step 1: Compile**
```
F7 → ✅ 0 errors
```

### **Step 2: ตั้งค่า Input**

**ใน MT5:**
1. คลิกขวาที่ EA → **Properties**
2. แท็บ **Inputs**
3. ตั้ง `InpSendAllTrades = true` (เพื่อทดสอบกับ manual)
4. กด **OK**

### **Step 3: ทดสอบ**

**1. รัน Python Receiver:**
```bash
python test_trade_receiver.py
```

**2. เปิด Position Manual:**
- ซื้อ/ขาย symbol ใดก็ได้
- ดูใน Python ว่าได้รับข้อมูลหรือไม่

**3. คาดหวัง:**

**MT5 Log:**
```
🔔 Trade Transaction Detected! Ticket: 16373028
✅ Sent Trade Result to Python: 145 bytes
   📊 Ticket: 16373028, Symbol: XAUUSD, Type: BUY, Profit: 0.00
```

**Python Output:**
```
============================================================
📥 [Message #1] Trade Result Received!
============================================================
   🎫 Ticket:     16373028
   📊 Symbol:     XAUUSD
   📈 Type:       BUY
   💵 Profit:     0.00
   🔮 Magic:      0          ← Manual position
============================================================
```

---

## 🎯 Use Cases

### **Development & Testing:**
```
InpSendAllTrades = true   ← ทดสอบกับ manual trades
```

### **Production:**
```
InpSendAllTrades = false  ← ส่งเฉพาะ EA trades
```

### **Monitoring All Trades:**
```
InpSendAllTrades = true   ← รับข้อมูลทุก trade (manual + EA)
```

---

## 🔍 Troubleshooting

### **ถ้ายังไม่ส่งข้อมูล:**

1. **เช็ค Input Setting:**
   - Properties → Inputs → `InpSendAllTrades = true`

2. **เช็ค Log:**
   - ต้องเห็น "Trade Transaction Detected!"
   - ถ้าเห็น "Skipping: Wrong Magic Number" = ตั้งค่าผิด

3. **Restart EA:**
   - ลบ EA ออกจาก chart
   - ลาก EA กลับเข้าไปใหม่
   - เช็ค settings อีกครั้ง

---

## 📦 Files

[**ProgramC_Trader.mq5**](computer:///mnt/user-data/outputs/ProgramC_Trader.mq5) - ✅ แก้ไขแล้ว

---

## 💡 Tips

### **Magic Number คืออะไร?**
- **Magic Number** = ตัวเลขเฉพาะที่ EA ใช้ระบุว่า position ไหนเป็นของ EA
- **Manual position** = magic = 0 เสมอ
- **EA position** = magic = ค่าที่กำหนดใน EA (เช่น 999000)

### **ทำไมต้องใช้ Magic Number?**
- แยกระหว่าง manual trades และ EA trades
- หลาย EA รันพร้อมกัน แต่ละตัวมี magic ต่างกัน
- ป้องกัน EA ปิด position ของคนอื่น

### **Best Practice:**
- **Development:** `InpSendAllTrades = true` (รับข้อมูลทุก trade)
- **Production:** `InpSendAllTrades = false` (รับเฉพาะ EA trades)

---

**ตอนนี้ทดสอบกับ manual trades ได้แล้วครับ!** 🎉
