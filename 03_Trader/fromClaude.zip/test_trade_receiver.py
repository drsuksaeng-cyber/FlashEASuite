#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test Trade Result Receiver (Python)
รับข้อมูล trade result จาก MT5 ผ่าน ZMQ PULL socket
"""

import zmq
import msgpack
import time
from datetime import datetime

def main():
    print("🔵 [Python] Trade Result Receiver Starting...")
    
    # 1. Create ZMQ Context
    context = zmq.Context()
    
    # 2. Create PULL Socket (รับข้อมูลจาก MT5 PUSH)
    pull_socket = context.socket(zmq.PULL)
    pull_socket.bind("tcp://127.0.0.1:7779")  # ต้องตรงกับ MT5 PUSH address
    
    # 3. Set timeout
    pull_socket.setsockopt(zmq.RCVTIMEO, 1000)  # 1 second timeout
    
    print("✅ [Python] Listening on tcp://127.0.0.1:7779")
    print("⏳ [Python] Waiting for trade results from MT5...\n")
    
    msg_count = 0
    
    try:
        while True:
            try:
                # 4. รับข้อมูล
                raw_data = pull_socket.recv()
                msg_count += 1
                
                # 5. Unpack MessagePack
                data = msgpack.unpackb(raw_data, raw=False)
                
                # 6. Parse ข้อมูล
                if len(data) >= 12:
                    msg_type = data[0]
                    timestamp = data[1]
                    ticket = data[2]
                    symbol = data[3]
                    trade_type = data[4]
                    volume = data[5]
                    open_price = data[6]
                    sl = data[7]
                    tp = data[8]
                    profit = data[9]
                    magic = data[10]
                    comment = data[11]
                    
                    # Convert timestamp
                    dt = datetime.fromtimestamp(timestamp / 1000.0)
                    type_str = "BUY" if trade_type == 0 else "SELL"
                    
                    # 7. แสดงผล
                    print(f"{'='*60}")
                    print(f"📥 [Message #{msg_count}] Trade Result Received!")
                    print(f"{'='*60}")
                    print(f"   🕐 Time:       {dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
                    print(f"   🎫 Ticket:     {ticket}")
                    print(f"   📊 Symbol:     {symbol}")
                    print(f"   📈 Type:       {type_str}")
                    print(f"   📦 Volume:     {volume}")
                    print(f"   💰 Open Price: {open_price}")
                    print(f"   🛑 SL:         {sl}")
                    print(f"   🎯 TP:         {tp}")
                    print(f"   💵 Profit:     {profit:.2f}")
                    print(f"   🔮 Magic:      {magic}")
                    print(f"   💬 Comment:    {comment}")
                    print(f"{'='*60}\n")
                    
                else:
                    print(f"⚠️ [Warning] Invalid data format (length={len(data)})")
                    
            except zmq.Again:
                # Timeout - ไม่มีข้อมูล
                print(".", end="", flush=True)
                time.sleep(1)
                continue
                
            except Exception as e:
                print(f"❌ [Error] {e}")
                continue
                
    except KeyboardInterrupt:
        print("\n🛑 [Python] Stopped by user")
        
    finally:
        pull_socket.close()
        context.term()
        print("✅ [Python] Cleaned up")

if __name__ == "__main__":
    main()
