import zmq
import msgpack
import time
import config  # เรียกใช้ config เดียวกันเพื่อให้พอร์ตตรงกัน

def run_test():
    context = zmq.Context()
    socket = context.socket(zmq.PUB)
    
    # ต้อง Bind ที่อยู่เดียวกับที่ Brain ใช้ส่ง (7778)
    # แต่ถ้า Brain รันอยู่ มันจะชนกัน! 
    # **ดังนั้นพี่ต้องปิด main.py ตัวจริงก่อนรันตัวนี้นะคะ**
    try:
        socket.bind(config.ZMQ_EXECUTION_ADDRESS)
        print(f"🚀 TEST SENDER: Bound to {config.ZMQ_EXECUTION_ADDRESS}")
    except zmq.ZMQError:
        print(f"❌ Error: Port 7778 is busy! (Please stop main.py first)")
        return

    print("waiting for subscribers connection...")
    time.sleep(1) # รอให้ MT5 เชื่อมต่อเข้ามา

    # สร้างคำสั่งจำลอง (Fake Signal)
    policy = {
        "type": "POLICY",
        "symbol": "EURUSD",     # คู่เงินที่พี่เปิดกราฟอยู่
        "action": 1,            # 1 = BUY
        "confidence": 0.99,     # มั่นใจสุดๆ
        "entry_price": 1.0500,
        "timestamp": int(time.time() * 1000),
        "model_version": "TEST_SCRIPT",
        "debug_info": "TEST_SIGNAL_FROM_PYTHON"
    }

    packed_data = msgpack.packb(policy)

    counter = 0
    while True:
        # ส่งรัวๆ ทุก 2 วินาที
        socket.send(packed_data)
        print(f"📤 Sent Policy #{counter}: BUY EURUSD (Conf: 99%)")
        counter += 1
        time.sleep(2)

if __name__ == "__main__":
    run_test()