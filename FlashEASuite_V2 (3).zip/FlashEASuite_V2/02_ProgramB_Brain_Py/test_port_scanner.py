#!/usr/bin/env python3
"""
Debug Script - Try Multiple Ports
"""

import zmq
import msgpack
import time

def test_port(port):
    """Test a specific port"""
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    
    try:
        address = f"tcp://127.0.0.1:{port}"
        socket.connect(address)
        socket.subscribe(b"")
        socket.setsockopt(zmq.RCVTIMEO, 2000)  # 2 sec timeout
        
        print(f"Testing {address}... ", end="", flush=True)
        
        try:
            raw_data = socket.recv()
            print(f"✅ RECEIVED {len(raw_data)} bytes!")
            
            try:
                data = msgpack.unpackb(raw_data, raw=False)
                print(f"   Type: {data.get('type')}, Symbol: {data.get('symbol')}")
                return True
            except:
                print(f"   (decode failed but data received)")
                return True
                
        except zmq.Again:
            print("❌ Timeout")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    finally:
        socket.close()
        context.term()

def main():
    print("=" * 60)
    print("Port Scanner - Finding Feeder")
    print("=" * 60)
    print()
    
    # Test common ports
    ports = [7777, 7778, 7779, 5555, 5556, 5557, 6666, 8888]
    
    working_ports = []
    
    for port in ports:
        if test_port(port):
            working_ports.append(port)
        time.sleep(0.5)
    
    print()
    print("=" * 60)
    
    if working_ports:
        print(f"✅ Found Feeder on port(s): {working_ports}")
        print(f"Update Python to use: tcp://127.0.0.1:{working_ports[0]}")
    else:
        print("❌ No Feeder found on any common port")
        print("Possible issues:")
        print("  1. Feeder EA not running")
        print("  2. Feeder using different address")
        print("  3. Firewall blocking")
    
    print("=" * 60)

if __name__ == "__main__":
    main()
