#!/usr/bin/env python3
"""
FlashEASuite V2 - Test Brain Server
Simple Python server to test MQL5 Networking Layer

This script sends test PolicyMessages to the MQL5 Trader
and receives confirmations back.

Requirements:
    pip install pyzmq

Usage:
    python test_brain_server.py
"""

import zmq
import struct
import time
from typing import Dict, Any

class TestBrainServer:
    """Test server that mimics Python Brain (Program B)"""
    
    def __init__(self, pub_port=5556, pull_port=5557):
        """Initialize ZeroMQ sockets"""
        self.context = zmq.Context()
        
        # PUB socket for sending policies to Trader
        self.pub_socket = self.context.socket(zmq.PUB)
        self.pub_socket.bind(f"tcp://*:{pub_port}")
        print(f"✓ PUB socket bound to port {pub_port}")
        
        # PULL socket for receiving confirmations from Trader
        self.pull_socket = self.context.socket(zmq.PULL)
        self.pull_socket.bind(f"tcp://*:{pull_port}")
        print(f"✓ PULL socket bound to port {pull_port}")
        
        # Give sockets time to bind
        time.sleep(0.5)
        print("✓ Test Brain Server ready\n")
    
    def serialize_policy_message(self, policy: Dict[str, Any]) -> bytes:
        """
        Serialize PolicyMessage to binary format matching MQL5 Protocol.mqh
        
        Message structure:
        - int32: message_type (2 = MSG_TYPE_POLICY)
        - string: symbol (int32 length + UTF-8 bytes)
        - int32: action (0=HOLD, 1=BUY, 2=SELL)
        - double: confidence
        - double: entry_price
        - double: stop_loss
        - double: take_profit
        - double: position_size
        - int64: timestamp_ms
        - string: model_version (int32 length + UTF-8 bytes)
        """
        buffer = bytearray()
        
        # Message type (2 = POLICY)
        buffer.extend(struct.pack('>i', 2))
        
        # Symbol (length-prefixed string)
        symbol_bytes = policy['symbol'].encode('utf-8')
        buffer.extend(struct.pack('>i', len(symbol_bytes)))
        buffer.extend(symbol_bytes)
        
        # Action
        buffer.extend(struct.pack('>i', policy['action']))
        
        # Doubles (confidence, entry, SL, TP, size)
        buffer.extend(struct.pack('>d', policy['confidence']))
        buffer.extend(struct.pack('>d', policy['entry_price']))
        buffer.extend(struct.pack('>d', policy['stop_loss']))
        buffer.extend(struct.pack('>d', policy['take_profit']))
        buffer.extend(struct.pack('>d', policy['position_size']))
        
        # Timestamp
        buffer.extend(struct.pack('>q', policy['timestamp_ms']))
        
        # Model version (length-prefixed string)
        model_bytes = policy['model_version'].encode('utf-8')
        buffer.extend(struct.pack('>i', len(model_bytes)))
        buffer.extend(model_bytes)
        
        return bytes(buffer)
    
    def deserialize_confirmation(self, buffer: bytes) -> Dict[str, Any]:
        """
        Deserialize confirmation message from MQL5
        (Uses same PolicyMessage structure)
        """
        offset = 0
        
        # Message type
        msg_type, = struct.unpack_from('>i', buffer, offset)
        offset += 4
        
        # Symbol
        str_len, = struct.unpack_from('>i', buffer, offset)
        offset += 4
        symbol = buffer[offset:offset+str_len].decode('utf-8')
        offset += str_len
        
        # Action
        action, = struct.unpack_from('>i', buffer, offset)
        offset += 4
        
        # Doubles
        confidence, = struct.unpack_from('>d', buffer, offset)
        offset += 8
        entry_price, = struct.unpack_from('>d', buffer, offset)
        offset += 8
        stop_loss, = struct.unpack_from('>d', buffer, offset)
        offset += 8
        take_profit, = struct.unpack_from('>d', buffer, offset)
        offset += 8
        position_size, = struct.unpack_from('>d', buffer, offset)
        offset += 8
        
        # Timestamp
        timestamp_ms, = struct.unpack_from('>q', buffer, offset)
        offset += 8
        
        # Model version
        str_len, = struct.unpack_from('>i', buffer, offset)
        offset += 4
        model_version = buffer[offset:offset+str_len].decode('utf-8')
        
        return {
            'msg_type': msg_type,
            'symbol': symbol,
            'action': action,
            'confidence': confidence,
            'timestamp_ms': timestamp_ms,
            'model_version': model_version
        }
    
    def send_test_policy(self, symbol='EURUSD', action=1, confidence=0.85):
        """Send a test policy message"""
        policy = {
            'symbol': symbol,
            'action': action,  # 0=HOLD, 1=BUY, 2=SELL
            'confidence': confidence,
            'entry_price': 1.08500,
            'stop_loss': 1.08000,
            'take_profit': 1.09000,
            'position_size': 0.10,
            'timestamp_ms': int(time.time() * 1000),
            'model_version': 'TEST_BRAIN_V1.0'
        }
        
        msg = self.serialize_policy_message(policy)
        self.pub_socket.send(msg)
        
        action_str = ['HOLD', 'BUY', 'SELL'][action]
        print(f"📤 Sent: {symbol} {action_str} @ {policy['entry_price']:.5f} "
              f"(confidence: {confidence:.2f})")
        
        return policy
    
    def receive_confirmation(self, timeout_ms=1000):
        """Receive confirmation from Trader"""
        if self.pull_socket.poll(timeout_ms):
            msg = self.pull_socket.recv()
            try:
                confirmation = self.deserialize_confirmation(msg)
                action_str = ['HOLD', 'BUY', 'SELL'][confirmation['action']]
                print(f"📥 Received confirmation: {confirmation['symbol']} "
                      f"{action_str} - {confirmation['model_version']}")
                return confirmation
            except Exception as e:
                print(f"❌ Error deserializing confirmation: {e}")
                return None
        return None
    
    def run_test_sequence(self):
        """Run a sequence of test messages"""
        print("=" * 60)
        print("Starting test sequence...")
        print("=" * 60)
        
        test_policies = [
            ('EURUSD', 1, 0.85),  # BUY
            ('GBPUSD', 2, 0.78),  # SELL
            ('USDJPY', 1, 0.92),  # BUY
            ('AUDUSD', 0, 0.50),  # HOLD (low confidence)
        ]
        
        for symbol, action, confidence in test_policies:
            print()
            self.send_test_policy(symbol, action, confidence)
            
            # Wait for confirmation
            print("⏳ Waiting for confirmation...")
            confirmation = self.receive_confirmation(timeout_ms=2000)
            
            if confirmation:
                print("✓ Confirmation received")
            else:
                print("⚠ No confirmation received (timeout)")
            
            time.sleep(1)  # Pause between messages
        
        print()
        print("=" * 60)
        print("Test sequence complete")
        print("=" * 60)
    
    def interactive_mode(self):
        """Interactive mode for manual testing"""
        print("\n" + "=" * 60)
        print("Interactive Mode - Press Ctrl+C to exit")
        print("=" * 60)
        print("\nCommands:")
        print("  buy <symbol>   - Send BUY policy")
        print("  sell <symbol>  - Send SELL policy")
        print("  test           - Run test sequence")
        print("  quit           - Exit")
        print()
        
        while True:
            try:
                cmd = input(">>> ").strip().lower()
                
                if not cmd:
                    continue
                
                if cmd == 'quit' or cmd == 'exit':
                    break
                
                if cmd == 'test':
                    self.run_test_sequence()
                    continue
                
                parts = cmd.split()
                if len(parts) == 2:
                    action_cmd, symbol = parts
                    symbol = symbol.upper()
                    
                    if action_cmd == 'buy':
                        self.send_test_policy(symbol, 1, 0.85)
                    elif action_cmd == 'sell':
                        self.send_test_policy(symbol, 2, 0.85)
                    else:
                        print("Unknown command. Use: buy/sell <symbol>")
                        continue
                    
                    # Check for confirmation
                    print("⏳ Checking for confirmation...")
                    conf = self.receive_confirmation(timeout_ms=2000)
                    if conf:
                        print("✓ Confirmed")
                    else:
                        print("⚠ No confirmation")
                else:
                    print("Unknown command. Type 'test' or 'buy/sell <symbol>'")
                    
            except KeyboardInterrupt:
                print("\n\nExiting...")
                break
            except Exception as e:
                print(f"Error: {e}")
    
    def cleanup(self):
        """Cleanup sockets"""
        print("\nCleaning up...")
        self.pub_socket.close()
        self.pull_socket.close()
        self.context.term()
        print("✓ Cleanup complete")


def main():
    """Main entry point"""
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 10 + "FlashEASuite V2 - Test Brain Server" + " " * 13 + "║")
    print("╚" + "=" * 58 + "╝")
    print()
    
    # Check if pyzmq is installed
    try:
        import zmq
        print(f"✓ PyZMQ version: {zmq.pyzmq_version()}")
        print(f"✓ ZeroMQ version: {zmq.zmq_version()}")
    except ImportError:
        print("❌ PyZMQ not installed")
        print("   Install with: pip install pyzmq")
        return
    
    print()
    
    # Create server
    server = TestBrainServer()
    
    try:
        # Run test sequence
        server.run_test_sequence()
        
        # Enter interactive mode
        server.interactive_mode()
        
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        server.cleanup()


if __name__ == '__main__':
    main()
