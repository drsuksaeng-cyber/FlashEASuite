"""
Test Feeder (Fake MT5) - Standard Mode
ยิง Tick ปกติเข้าหา Brain เพื่อทดสอบการไหลของข้อมูล
"""
import zmq
import time
import msgpack
import random

def simulate_feeder():
    context = zmq.Context()
    socket = context.socket(zmq.PUB)
    
    # CONNECT ไปหา Brain
    target_address = "tcp://127.0.0.1:7777"
    socket.connect(target_address)
    print(f"✅ Fake Feeder connected to {target_address}")

    seq_id = 0
    print("🚀 Starting standard simulation (Random Walk)...")
    
    # ราคาเริ่มต้น
    price = 2000.0
    
    try:
        while True:
            seq_id += 1
            current_time = int(time.time() * 1000)
            
            # สุ่มราคาเดินหน้า/ถอยหลังเล็กน้อย (Random Walk)
            change = random.uniform(-0.5, 0.5)
            price += change
            
            # Spread ปกติ
            bid = price
            ask = price + 0.30 # Spread 30 points (Standard)
            
            # สร้าง Tick
            # [Type, SeqID, Time, Symbol, Bid, Ask, Flags]
            fake_tick = [1, seq_id, current_time, "XAUUSD", bid, ask, 6]
            
            socket.send(msgpack.packb(fake_tick))
            print(f"Sent Tick #{seq_id}: {bid:.2f}")
            
            # ส่งความเร็วปกติ (ไม่ต้องรัวมาก)
            time.sleep(0.1) 
            
    except KeyboardInterrupt:
        print("Stopping...")
    finally:
        socket.close()
        context.term()

if __name__ == "__main__":
    simulate_feeder()