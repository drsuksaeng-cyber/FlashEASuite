import zmq
import msgpack
import time
import os
import sys

# --- Configuration ---
ZMQ_ADDRESS = "tcp://127.0.0.1:7777" 
REPORT_INTERVAL = 600  # 10 นาที

stats = {
    "total_batches": 0,
    "total_ticks": 0,
    "valid_ticks": 0,
    "packet_loss": 0,
    "decode_errors": 0
}

last_seq_map = {}

def run_test():
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    
    # Tuning: เปิดถังพักใหญ่
    socket.setsockopt(zmq.RCVHWM, 100000)
    socket.setsockopt(zmq.RCVBUF, 10 * 1024 * 1024)
    
    print(f"📡 Binding Python Server at {ZMQ_ADDRESS}...")
    try:
        socket.bind(ZMQ_ADDRESS)
        socket.setsockopt_string(zmq.SUBSCRIBE, "") 
    except Exception as e:
        print(f"❌ Bind Error: {e}")
        return

    start_time_str = time.strftime('%H:%M:%S')
    print(f"✅ System Online! Waiting for Batched Data...")
    print(f"⏰ Start Time: {start_time_str}")
    print(f"⏳ Waiting 10 minutes for final report...")
    print(f"💓 (Dot '.' = Received 1 Batch)")
    print("-" * 60)

    last_report_time = time.time()
    unpacker = msgpack.Unpacker(raw=False) # ตัวแกะกล่องแบบต่อเนื่อง

    try:
        while True:
            try:
                # 1. รับกล่องใหญ่ (Batch)
                batch_data = socket.recv()
                stats["total_batches"] += 1
                
                # แสดงจุดไข่ปลา เพื่อบอกว่า "ฉันยังไม่ตายนะ"
                if stats["total_batches"] % 100 == 0:
                    sys.stdout.write(".")
                    sys.stdout.flush()

                # 2. ยัดเข้าเครื่องแกะ
                unpacker.feed(batch_data)

                # 3. วนลูปดึงข้อมูลย่อย
                for data in unpacker:
                    stats["total_ticks"] += 1
                    
                    seq_id = data[1]
                    symbol = data[3]
                    
                    # ตรวจสอบ Packet Loss
                    if symbol in last_seq_map:
                        expected_seq = last_seq_map[symbol] + 1
                        if seq_id > expected_seq:
                            loss = seq_id - expected_seq
                            stats["packet_loss"] += loss
                    
                    last_seq_map[symbol] = seq_id
                    stats["valid_ticks"] += 1

            except Exception as e:
                stats["decode_errors"] += 1
                # Reset Unpacker ถ้าเจอข้อมูลขยะ
                unpacker = msgpack.Unpacker(raw=False)

            # 4. ตรวจสอบเวลาครบ 10 นาที
            current_time = time.time()
            if current_time - last_report_time >= REPORT_INTERVAL:
                total_ops = stats["valid_ticks"] + stats["packet_loss"] + stats["decode_errors"]
                loss_rate = (stats["packet_loss"] / total_ops * 100) if total_ops > 0 else 0
                
                print(f"\n\n📊 REPORT AT {time.strftime('%H:%M:%S')}")
                print(f"==============================")
                print(f"Total Batches  : {stats['total_batches']:,}")
                print(f"Total Ticks    : {stats['total_ticks']:,}")
                print(f"✅ Valid Ticks  : {stats['valid_ticks']:,}")
                print(f"❌ Packet Loss  : {stats['packet_loss']} ({loss_rate:.6f}%)")
                print(f"⚠️ Decode Err   : {stats['decode_errors']}")
                print(f"==============================")
                print(f"⏳ Next report in 10 minutes...")
                
                # Reset
                stats["total_batches"] = 0
                stats["total_ticks"] = 0
                stats["valid_ticks"] = 0
                stats["packet_loss"] = 0
                stats["decode_errors"] = 0
                last_report_time = current_time

    except KeyboardInterrupt:
        print("\n🛑 Stopped.")

if __name__ == "__main__":
    run_test()