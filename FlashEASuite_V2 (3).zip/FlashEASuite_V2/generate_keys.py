import os
import zmq
import zmq.auth

def create_key_file(base_dir, name):
    # Generate Public/Private Key pair
    public_key, secret_key = zmq.curve_keypair()
    
    # Save Secret Key (เก็บเป็นความลับ)
    with open(os.path.join(base_dir, f"{name}.key_secret"), 'w') as f:
        f.write(secret_key.decode('utf-8'))
        
    # Save Public Key (แจกจ่ายได้)
    with open(os.path.join(base_dir, f"{name}.key"), 'w') as f:
        f.write(public_key.decode('utf-8'))
        
    print(f"✅ Generated keys for {name}")

def main():
    keys_dir = "00_Common/Keys"
    
    if not os.path.exists(keys_dir):
        os.makedirs(keys_dir)
        
    print("🔐 Generating CurveZMQ Keys...")
    
    # 1. Server Keys (สำหรับ Python Brain)
    create_key_file(keys_dir, "server")
    
    # 2. Client Keys (สำหรับ MQL5 Trader)
    create_key_file(keys_dir, "client")
    
    print("\n⚠️  IMPORTANT:")
    print("   - server.key_secret -> Keep on Python Server ONLY")
    print("   - client.key_secret -> Compile into MQL5 EA (Embed)")
    print("   - *.key -> Public keys, can be shared.")

if __name__ == "__main__":
    main()