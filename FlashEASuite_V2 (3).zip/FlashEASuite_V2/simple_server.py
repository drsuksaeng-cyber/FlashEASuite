import zmq
import time

def run_server():
    context = zmq.Context()
    socket = context.socket(zmq.PUB)
    
    # ลองจองพอร์ต 7777 แบบ Localhost
    address = "tcp://127.0.0.1:7777"
    
    print(f"🔵 กำลังพยายามจองพอร์ต: {address}")
    try:
        socket.bind(address)
        print("✅ เย้! จองพอร์ตสำเร็จ (Bind Success)")
    except Exception as e:
        print(f"❌ พัง! จองพอร์ตไม่ได้: {e}")
        return

    # ส่งข้อมูลรัวๆ เพื่อทดสอบ
    count = 0
    while True:
        try:
            msg = f"TEST_MESSAGE_{count}"
            socket.send_string(msg)
            print(f"   Sent: {msg}")
            time.sleep(1) # ส่งทุก 1 วินาที
            count += 1
        except KeyboardInterrupt:
            print("\n🛑 หยุดทำงาน")
            break

if __name__ == "__main__":
    run_server()