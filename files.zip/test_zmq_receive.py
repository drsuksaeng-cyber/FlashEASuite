#!/usr/bin/env python3
"""
Debug Script - Test ZMQ Tick Reception
"""

import zmq
import msgpack
import time

def test_zmq_receive():
    """Test if we can receive messages from Feeder"""
    
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect("tcp://127.0.0.1:7777")
    socket.subscribe(b"")  # Subscribe to all messages
    
    # Set timeout
    socket.setsockopt(zmq.RCVTIMEO, 5000)  # 5 seconds
    
    print("=" * 60)
    print("ZMQ Tick Reception Test")
    print("=" * 60)
    print(f"Connected to: tcp://127.0.0.1:7777")
    print("Waiting for messages...")
    print()
    
    message_count = 0
    
    try:
        while message_count < 10:  # Receive 10 messages then stop
            try:
                # Receive message
                raw_data = socket.recv()
                message_count += 1
                
                print(f"[{message_count}] Received {len(raw_data)} bytes")
                print(f"    Raw (first 50 bytes): {raw_data[:50]}")
                
                # Try to decode as MessagePack
                try:
                    data = msgpack.unpackb(raw_data, raw=False)
                    print(f"    ✅ MessagePack decoded successfully!")
                    print(f"    Type: {data.get('type', 'UNKNOWN')}")
                    print(f"    Symbol: {data.get('symbol', 'N/A')}")
                    
                    if data.get('type') == 'TICK':
                        print(f"    Bid: {data.get('bid', 0)}")
                        print(f"    Ask: {data.get('ask', 0)}")
                    
                except Exception as e:
                    print(f"    ❌ MessagePack decode error: {e}")
                
                print()
                time.sleep(0.1)
                
            except zmq.Again:
                print("⏱️ Timeout waiting for message (5 seconds)")
                break
                
    except KeyboardInterrupt:
        print("\n🛑 Stopped by user")
    
    finally:
        socket.close()
        context.term()
    
    print("=" * 60)
    print(f"Test complete. Received {message_count} messages.")
    print("=" * 60)

if __name__ == "__main__":
    test_zmq_receive()
