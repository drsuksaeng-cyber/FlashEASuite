#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FlashEASuite V2 - Program B (Python Brain) - Main Entry Point
Threading Version (Windows Compatible)
"""

import sys
import time
import queue
import threading
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# Import strategy engine
try:
    from core.strategy import StrategyEngineThreaded
    logger.info("✅ Strategy engine imported successfully")
except ImportError as e:
    logger.error(f"❌ Failed to import strategy engine: {e}")
    sys.exit(1)


class FlashEASuiteApp:
    """
    Main application controller for FlashEASuite V2 Python Brain.
    Uses threading for Windows compatibility.
    """
    
    def __init__(self):
        """Initialize the application"""
        logger.info("=" * 60)
        logger.info("FlashEASuite V2 - Program B (The Brain) 🧠")
        logger.info("MODE: Threading (Windows Safe Mode)")
        logger.info("CORE: 3 Threads (Ingestion + Strategy + Execution Listener)")
        logger.info("=" * 60)
        
        # Configuration
        self.ZMQ_FEEDER_ADDRESS = "tcp://127.0.0.1:7777"      # Subscribe to feeder
        self.ZMQ_POLICY_ADDRESS = "tcp://127.0.0.1:7778"      # Publish policies
        self.ZMQ_FEEDBACK_ADDRESS = "tcp://127.0.0.1:7779"    # Pull trade results
        
        # Thread communication
        self.ingestion_queue = queue.Queue(maxsize=10000)
        self.signal_queue = queue.Queue(maxsize=1000)
        self.feedback_queue = queue.Queue(maxsize=1000)
        
        # Shutdown event
        self.shutdown_event = threading.Event()
        
        # Threads
        self.strategy_thread = None
        
    def run(self):
        """Start the application"""
        try:
            # Start strategy engine thread
            logger.info("🔄 Starting FlashEA Brain with Feedback Loop...")
            
            self.strategy_thread = StrategyEngineThreaded(
                ingestion_queue=self.ingestion_queue,
                signal_queue=self.signal_queue,
                feedback_queue=self.feedback_queue,
                shutdown_event=self.shutdown_event,
                zmq_feeder_address=self.ZMQ_FEEDER_ADDRESS,
                zmq_pub_address=self.ZMQ_POLICY_ADDRESS,
                zmq_feedback_address=self.ZMQ_FEEDBACK_ADDRESS
            )
            
            self.strategy_thread.start()
            logger.info("✅ All workers started successfully (3 threads)")
            
            # Keep main thread alive
            logger.info("\n" + "=" * 60)
            logger.info("System is running with FEEDBACK LOOP enabled!")
            logger.info("🟢 Generating trading signals")
            logger.info("🔵 Sending policies to Trader")
            logger.info("🟡 Receiving feedback (Wins/Losses)")
            logger.info("=" * 60)
            logger.info("\nPress Ctrl+C to stop...")
            
            while not self.shutdown_event.is_set():
                time.sleep(1)
                
        except KeyboardInterrupt:
            logger.info("\n🛑 Keyboard interrupt received")
        except Exception as e:
            logger.error(f"❌ Fatal error: {e}", exc_info=True)
        finally:
            self.shutdown()
    
    def shutdown(self):
        """Graceful shutdown"""
        logger.info("\n" + "=" * 60)
        logger.info("🛑 Shutting Down...")
        logger.info("=" * 60)
        
        # Signal shutdown
        self.shutdown_event.set()
        
        # Wait for strategy thread
        if self.strategy_thread and self.strategy_thread.is_alive():
            logger.info("Waiting for strategy thread to finish...")
            self.strategy_thread.join(timeout=5)
        
        logger.info("✅ FlashEASuite V2 - Program_and_Brain_Py - Shutdown complete.")


def main():
    """Main entry point"""
    app = FlashEASuiteApp()
    app.run()


if __name__ == "__main__":
    main()
