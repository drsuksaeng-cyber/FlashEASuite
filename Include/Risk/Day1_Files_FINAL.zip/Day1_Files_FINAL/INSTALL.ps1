# FlashEASuite V2 - Day 1 Installation Script
# Automatically copy all Day 1 files to correct locations

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  FlashEASuite V2 - Day 1 Risk Management Installation" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Define paths
$CURRENT_DIR = Get-Location
$SOURCE = "$CURRENT_DIR"
$TARGET = "C:\Users\drsuk\AppData\Roaming\MetaQuotes\Terminal\B2C22A9C2EA0D03B7096C9AF7E852052\MQL5\Experts\FlashEASuite_V2"

Write-Host "Source: $SOURCE" -ForegroundColor Yellow
Write-Host "Target: $TARGET" -ForegroundColor Yellow
Write-Host ""

# Check if source files exist
if (-not (Test-Path "$SOURCE\Include\Risk")) {
    Write-Host "ERROR: Include\Risk folder not found!" -ForegroundColor Red
    Write-Host "Please run this script from Day1_Files_FINAL directory" -ForegroundColor Red
    Write-Host ""
    pause
    exit 1
}

# Check if target exists
if (-not (Test-Path $TARGET)) {
    Write-Host "ERROR: FlashEASuite_V2 folder not found!" -ForegroundColor Red
    Write-Host "Expected at: $TARGET" -ForegroundColor Red
    Write-Host ""
    pause
    exit 1
}

Write-Host "[1/3] Copying MQL5 Risk Modules..." -ForegroundColor Green
try {
    Copy-Item "$SOURCE\Include\Risk\*" "$TARGET\Include\Risk\" -Force
    Write-Host "      ✅ PositionSizingManager.mqh" -ForegroundColor White
    Write-Host "      ✅ DailyLossLimit.mqh" -ForegroundColor White
    Write-Host "      ✅ RiskGuardian.mqh" -ForegroundColor White
} catch {
    Write-Host "      ❌ Error copying Risk modules: $_" -ForegroundColor Red
    pause
    exit 1
}

Write-Host ""
Write-Host "[2/3] Copying Test Scripts..." -ForegroundColor Green
try {
    Copy-Item "$SOURCE\Tester\*" "$TARGET\Tester\" -Force
    Write-Host "      ✅ test_position_sizing.mq5" -ForegroundColor White
    Write-Host "      ✅ test_daily_loss_limit.mq5" -ForegroundColor White
    Write-Host "      ✅ test_integration_day1.mq5" -ForegroundColor White
} catch {
    Write-Host "      ❌ Error copying Test scripts: $_" -ForegroundColor Red
    pause
    exit 1
}

Write-Host ""
Write-Host "[3/3] Copying Python Modules..." -ForegroundColor Green
try {
    Copy-Item "$SOURCE\Python_Files\*" "$TARGET\02_Brain\core\risk_management\" -Force
    Write-Host "      ✅ __init__.py" -ForegroundColor White
    Write-Host "      ✅ position_sizing.py" -ForegroundColor White
    Write-Host "      ✅ daily_loss_limit.py" -ForegroundColor White
} catch {
    Write-Host "      ❌ Error copying Python modules: $_" -ForegroundColor Red
    pause
    exit 1
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  INSTALLATION COMPLETE!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

# Verify installation
Write-Host "Verification:" -ForegroundColor Yellow
Write-Host ""
Write-Host "MQL5 Risk Modules:" -ForegroundColor Cyan
Get-ChildItem "$TARGET\Include\Risk\*.mqh" | Select-Object Name, LastWriteTime | Format-Table -AutoSize

Write-Host "Test Scripts:" -ForegroundColor Cyan
Get-ChildItem "$TARGET\Tester\*.mq5" | Select-Object Name, LastWriteTime | Format-Table -AutoSize

Write-Host "Python Modules:" -ForegroundColor Cyan
Get-ChildItem "$TARGET\02_Brain\core\risk_management\*.py" | Select-Object Name, LastWriteTime | Format-Table -AutoSize

Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "  1. Open MetaEditor (F4)" -ForegroundColor White
Write-Host "  2. Open: Tester\test_integration_day1.mq5" -ForegroundColor White
Write-Host "  3. Press F7 (Compile)" -ForegroundColor White
Write-Host "  4. Expected: 0 error(s), 0 warning(s)" -ForegroundColor White
Write-Host "  5. Drag to chart and test!" -ForegroundColor White
Write-Host ""

pause
